# Tormach 15L Slant-PRO Operator Manual - UM10225 (0626A)

Source: [https://tormach.com/media/asset/u/m/um10225_15l_slant-pro_manual_0626a.pdf](https://tormach.com/media/asset/u/m/um10225_15l_slant-pro_manual_0626a.pdf)

Converted from official manufacturer PDF documentation. 199 PDF pages. Language: English. PDF page numbers below include cover and front matter.

Text extracted in PDF authored order to preserve the two-column paragraphs; diagrams and some table relationships require the source PDF. This is an extraction, not a verified substitute for the illustrated manual.


---

## PDF Page 1

Questions or comments? 
Please email us: info@tormach.com
All rights reserved.
UM10225_15L_Slant-PRO_Manual_0626A
Document Part Number: 34397
©2020 Tormach Inc.
Tormach® 15L Slant-PRO
Operator’s Manual
™
IMPORTANT! Read all safety precautions and instructions thoroughly before attempting
15L Slant-PRO installation, operation, or maintenance.


---

## PDF Page 2

Chapter 1
2
UM10225_15L_Slant-PRO_Manual_0626A
Preface
SAVE THESE INSTRUCTIONS!
This manual contains important safety warnings and operating instructions for the 15L Slant-PRO 
lathe. Refer to these instructions before attempting installation, operation or maintenance. Keep 
these instructions together with your 15L Slant-PRO lathe, so they are readily accessible. Any 
updated versions of this manual are available at www.tormach.com/documents
Safety Precautions
Failure to read and follow these safety warnings and operating instructions may result in voided 
warranty, property damage, serious injury or death.
Symbol
Description
Example
WARNING! Indicates a hazard which, if not 
avoided, could result in death or serious 
injury.
WARNING! Ejection Hazard: Tools and work 
pieces must be clamped properly. Failure to do so 
could result in death and/or serious injury.
CAUTION! Indicates a hazard which, if not 
avoided, could result in injury or machine 
damage.
CAUTION! Be sure to wear gloves when uncrating 
lathe. Failure to do so could result in serious injury.
IMPORTANT! 
Addresses practices not related to personal 
injury. 
IMPORTANT! Tighten the drawbar so the collet 
holds the tool holder securely in position. 
NOTE: 
Indicates additional information, 
clarification, or helpful hints.
NOTE: For further information on automatic oiler 
troubleshooting, refer to the operator manual.
Machine Safety
Any machine tool is potentially dangerous. Computer-controlled machines are potentially more 
dangerous than manual machines because, for example, a controller is quite prepared to plunge a 
turning tool at 60 inches per minute into a D1-4 chuck face spinning at 2500 RPM.
The Tormach lathe can deliver sufficient force to break tools, to crush bones, and to tear flesh. 
If loose hair, clothing, gloves, or jewelry gets caught by a rotating workpiece the results can be 
disastrous.
This manual tries to give you guidance on safety precautions and techniques, but because the 
details of each work area or other local conditions differ, we can accept no responsibility for the 
performance of the machine or any damage or injury caused by its use. It is your responsibility 
to ensure that you understand the implications of what you are doing and to comply with any 
legislation and codes of practice applicable to your country or state.


---

## PDF Page 3

Chapter 1
3
UM10225_15L_Slant-PRO_Manual_0626A
Preface
Machine Safety
Safe operation of the machine depends on its proper use and the precautions taken by the operator. 
Read and understand this manual prior to use. Only trained personnel – with a clear and thorough 
understanding of its operation and safety requirements – should operate this machine.
General Safety:
•	 Wear OSHA-approved safety glasses, safety shoes, and ear protection.
•	 Remove loose-fitting clothing, neckties, gloves, and jewelry.
•	 Tie up long hair or secure under a hat.
•	 Never operate a machine after consuming alcohol or taking medication.
•	 Keep work area well lit and deploy additional lighting, if needed.
Operational Safety
•	 Understand CNC lathes are automatically controlled and may start at any time.
•	 Do not leave machine unattended during operation.
•	 Always power off machine when not in use.
•	 Never operate with the door or chuck guard open; never bypass safety switches.
•	 Do not operate without knowing the function of every control key, button, knob or handle. 
Refer to the operator manual or contact Tormach if any function is not understood.
•	 Do not extend unsupported bar stock past the left end of the spindle bore.
•	 Do not operate with an unbalanced workpiece or spindle fixtures.
•	 Remove all tools (wrenches, chuck keys, etc.) from the spindle and machine surfaces before 
starting operations; loose items can become dangerous projectiles.
•	 Use adequate work clamping; loose workpieces can become projectiles.
•	 Be aware of workpiece cutoffs that could be cut free during operations and become dangerous 
projectiles.
•	 Protect your hands. Stop machine spindle and ensure lathe motion has stopped before:
	
	
- Reaching into any part of the machine motion envelope
	
	
- Changing tools or parts
	
	
- Clearing away chips, oil, or coolant; always use a chip scraper or brush
	
	
- Making an adjustment to the workpiece, fixture, or coolant nozzle
	
	
- Taking measurements
•	 Keep work area clear of clutter as machine motion can occur when keys are accidentally 
pressed or objects fall on keyboard, resulting in unexpected motion.


---

## PDF Page 4

Chapter 1
4
UM10225_15L_Slant-PRO_Manual_0626A
Preface
•	 Avoid getting pinched in places where the table, saddle, or spindle head create pinch points 
while in motion.
•	 Always use proper feeds, speeds, and depths of cut to prevent tool breakage. 
•	 Chips and dust from certain materials (e.g., magnesium) can be flammable. Fine dust from 
normally non-flammable materials can be flammable or even explosive. 
•	 Chips and dust from certain materials can be toxic. Vapors from certain overheated materials 
can be toxic. Always check a Material Safety Data Sheet (MSDS) of suspect materials. Refuse 
machining work requests of unknown materials.
•	 If in any doubt, seek guidance from a professionally qualified expert rather than risk injury to 
yourself or to others.
•	 Use adequate safeguarding around the operating envelope.
It is the responsibility of the operator/employer to provide and ensure point of operation safeguarding 
per the following:
•	 OSHA 1910.212 - General Requirements for All Machines
•	 ANSI B11.5-1984 (R1994) Lathes
•	 ANSI B11.22-2002 Safety Requirements for Turning Centers and Automatic Numerically 
Controlled Turning Machines
•	 ANSI B11.TR3-2000 Risk Assessment and Risk Reduction - A Guideline to Estimate, Evaluate, 
and Reduce Risks Associated with Machine Tools.
Electrical Safety
 WARNING! Electrical Shock Hazard: Be sure to power off machine before making any electrical 
modifications. Failure to do so may result in serious injury or death.
Never operate the machine tool with the cabinet door open. Never allow a coolant pump to operate 
with the cabinet door open. Do not allow the coolant system to flow coolant directly at the cabinet 
door seal or on the operator console controls. Neither the cabinet door seal nor the electrical 
controls are sealed against liquids.
Dual Power Input: The Tormach 15L Slant-PRO has two electrical power inputs. The primary supply is 
200 to 250 VAC single phase and is used for all axis and spindle motion. This should be on a dedicated 
circuit of at least 20A. Either of the 15L Slant-PRO’s two electrical power inputs can provide lethal 
electrical shocks. Both power inputs should be unplugged before working in the electrical cabinet.
Electrical Service: Certain service and troubleshooting operations require access to the electrical 
cabinet while the electrical power is on. Only qualified electrical technicians should perform such 
operations.
Retained Electrical Power: Electronic devices within the electrical cabinet may retain dangerous 
voltage levels after the power has been removed.


---

## PDF Page 5

Chapter 1
5
UM10225_15L_Slant-PRO_Manual_0626A
Preface
Warranty
Limited Warranty Coverage
Each Tormach (the “Manufacturer”) 15L Slant-PRO machine (“Machine”) and its components 
(“Components”) — except those listed below under limits and exclusions — is warranted against 
defects in material and workmanship for a period of 12 months from the date of delivery. The 
foregoing is a limited warranty and it is the only warranty by the manufacturer. Manufacturer 
disclaims all other warranties, express or implied, including but not limited to all warranties of 
merchantability and fitness for a particular purpose.
Repair or Replacement Only
Manufacturer’s liability under this agreement shall be limited to repairing or replacing, at the 
discretion of manufacturer, parts or components. Shipment for items replaced under warranty is 
free, but the shipment method is at the discretion of Tormach. In general delivery is via UPS ground 
service for domestic customers or the U.S. Postal Service (USPS) for international customers. If 
overnight or express delivery is requested, additional fees will apply.
Direct sales and phone support are part of the equation that allows us to provide high value at low 
cost. You must be comfortable with general electrical and mechanical repair concepts, including 
appropriate safety procedures, before working on your machine. If you do not have the required 
skills you need to find someone locally to assist you. We do not have factory technicians to send to 
your facility.
Limits and Exclusions of Warranty
Except as provided above, buyer agrees that all warranties express or implied, as to any matter 
whatsoever, including but not limited to warranties of merchantability and fitness for a particular 
purpose are excluded. Components subject to wear during normal use and over time such as paint, 
labels/decals, finish/condition, seals, flex cabling, spindle, etc., are excluded from this warranty. 
Tormach-specified maintenance procedures must be adhered to in order to maintain this warranty. 
This warranty is void if the machine is subjected to mishandling, misuse, neglect, accident, improper 
installation, improper maintenance, or improper operation or application, or if the machine was 
improperly repaired or serviced. Warranty of general machine tolerances is void if the machine is 
disassembled or altered by customer. Without limiting the generality of any of the exclusions or 
limitations described in other paragraphs, manufacturer’s warranty does not include any warranty 
that the machine or components will meet buyer’s production specifications or other requirements 
or that operation of the machine and/or components is uninterrupted or error-free. Manufacturer 
assumes no responsibility with respect to the use of the Machine and Components by Buyer, and 
manufacturer shall not incur any liability to Buyer for any failure in design, production, operation, 
performance or otherwise of the Machine or components other than repair or replacement of 
same as set forth in the Limited Warranty above. Manufacturer is not responsible for any damage 
to parts, machines, business premises or other property of Buyer, or for any other incidental or 
consequential damages that may be caused by a malfunction of the machine or components.


---

## PDF Page 6

Chapter 1
6
UM10225_15L_Slant-PRO_Manual_0626A
Preface
Limitation of Liability and Damages
Manufacturer is not liable to Buyer, or any customer of buyer for loss of profits, lost data, lost 
products, loss of revenue, loss of use, cost of down time, business good will, or any other incidental 
or consequential damage, whether in an action in contract or tort, arising out of or related to the 
machine or components, other products or services provided by manufacturer or seller, or the 
failure of parts or products made by using the machine or components, even if manufacturer or 
seller has been advised of the possibility of such damages. 
Manufacturer’s liability for damages for any cause whatsoever shall be limited to repair or 
replacement, at the discretion of manufacturer, of the defective parts, components or machine. 
Buyer has accepted this restriction on its right to recover incidental or consequential damages as part 
of its bargain with Seller. Buyer realizes and acknowledges that the price of the equipment would 
be higher if Seller or Manufacturer were required to be responsible for incidental or consequential 
damages, or punitive damages. This warranty supersedes any and all other agreements, either oral 
or in writing, between the parties hereto with respect to the warranties, limitations of liability and/or 
damages regarding the Machine or Components, and contains all of the covenants and agreements 
between the parties with respect to such warranties, liability limitations and/or damages. Each party 
to this warranty acknowledges that no representations, inducements, promises, or agreements, 
orally or otherwise, have been made by any party, or anyone acting on behalf of any party, which are 
not embodied herein regarding such warranties, liability limitations and/or damages, and that any 
agreement, statement, or promise not contained in this warranty shall be not be valid or binding 
regarding such warranties, liability limitations and damages.
Transferability
This warranty is transferable from the original end-user to another party if the machine is sold via 
private sale before the end of the warranty period. Should you have a problem with your machine, 
please consult your operator’s manual first. If this does not resolve the problem, contact Tormach 
through our Web site at www.tormach.com or call (608) 849-8381.
Extended Warranty
An extended warranty (PN 34381) is available for purchase at www.tormach.com or by calling (608) 
849-8381.


---

## PDF Page 7

Chapter 1
7
UM10225_15L_Slant-PRO_Manual_0626A
Preface
Intended Use
The Tormach 15L Slant-PRO is intended for use as a general purpose CNC lathe. The intended 
use includes cutting conventional non-abrasive materials such as mild or alloy steels, aluminum, 
plastics, and similar materials. Applications for the equipment or modifications of the equipment 
outside of the Intended Use Statement are supported through consulting engineering, not through 
our free support policy. There are no limits to the applications that Tormach products can be used 
for or to the modifications that can be applied to the Tormach machinery. Tormach designs use 
standard industrial components and incorporate the principles of Open Architecture specifically 
to allow and promote these variations. With Open Architecture controls, industrial engineers will 
find Tormach products cost effective to incorporate into larger manufacturing systems. All of the 
technical information and insight required to support these variations from the intended use cannot 
possibly be foreseen. If the extensive documentation provided does not supply all the information 
you need, we can provide additional information and engineering support required for your project 
on a consulting engineering basis. Consulting engineering is done by electrical and mechanical 
engineers and billed at current hourly rates.
As you might expect, all warranties for Tormach equipment are voided through modification to the 
equipment or use outside of the Intended Use. Individuals or companies involved with modifying 
the equipment or applying the products assume all consequent liability.
Nomenclature
This manual uses the following typographical nomenclature
Software Control 
Refers to a Software Control e.g., an on-screen button
Hardware Control
Refers to a button or switch on the lathe’s Operator Panel
G-code (e.g., G01X34.8)
Used to show G-code programs
Key name (e.g., Enter)
Tells you to press the indicated key
Button name (e.g., Stop)
Tells you to press the indicated button


---

## PDF Page 8

Chapter 1
8
UM10225_15L_Slant-PRO_Manual_0626A
Preface
Table of Contents
1. Overview
17
1.1 Specifications
18
2. Installation
19
2.1 Lathe Prep and Setup
19
2.1.1 Location
19
2.1.2 Electrical Requirements
19
2.1.2.1 Electrical Noise
20
2.1.2.2 Grounding
20
2.1.2.3 Ground Fault Interrupter (GFI) Use
20
2.2 Receiving, Uncrating, and Initial Inspection
20
2.2.1 Uncrating
20
2.2.2 Shipping Damage or Shortages
21
2.2.3 Remove Machine from Pallet
21
2.2.3.1 Lathe Lift Kit
21
2.3 Basic Installation Procedure
24
2.3.1 Attach Lathe Feet
24
2.3.2 Install the Controller Arm
25
2.3.3 Install the Monitor
27
2.3.4 Install the PathPilot Controller
27
2.4 Installation of Add-ons
29
2.4.1 Oiler
29
2.4.1.1 Manual Oiler
29
2.4.2 Turret
31
2.5 Controller Customization
31
3. Operation
32
3.1 Power Off/Power On Procedure
32


---

## PDF Page 9

Chapter 1
9
UM10225_15L_Slant-PRO_Manual_0626A
Preface
3.2 Confirm Spindle Direction
32
3.3 Lathe Axes Definition
34
3.4 Workholding
34
3.4.1 5C Collet Configuration (Maximum Speed Rating: 3500 RPM)
34
3.4.2 D1-4 Chuck Configuration (Maximum Speed Rating: 2500 RPM)
34
3.5 Tooling
35
3.5.1 Quick Change Tool Post (QCTP)
35
3.5.2 8-position Turret
35
3.5.3 Gang Tooling
35
3.6 Front Tool Post and Rear Tool Post Locations
36
3.7 Right-handed and Left-handed Tools
36
4. Intro to PathPilot
38
4.1 Making Your First Part
38
4.1.1 Reference the Lathe
38
4.1.2 Prepare the Workpiece
39
4.1.3 Prepare the Tools
39
4.1.4 Understand Machine Position, Work Offsets, and Tool Offsets
40
4.1.5 Set the Length Units
40
4.1.5.1 Programming in Inches
40
4.1.5.2 Programming in Millimeters
40
4.1.6 Touch Off the Workpiece to Set the Work Offsets
41
4.1.6.1 Setting the Z Work Offset
41
4.1.6.2 Setting the X Work Offset
42
4.1.7 Set the Tool Geometry Offsets
42
4.1.7.1 Setting Tool 1
42
4.1.7.2 Touching Off the Parting Tool
45
4.1.8 Write the G-code
46


---

## PDF Page 10

Chapter 1
10
UM10225_15L_Slant-PRO_Manual_0626A
Preface
4.1.8.1 Operation 1
47
4.1.8.2 Operation 2
49
4.1.8.3 Operation 3
50
4.1.8.4 Operation 4
51
4.1.8.5 Operation 5
52
4.1.8.6 Run the Completed G-code Program
53
5. PathPilot Interface
54
5.1 Overall Layout
54
5.2 Persistent Controls
55
5.2.1 Program Control Group
55
5.2.2 Position Status Group
57
5.2.3 Manual Control Group
59
5.2.3.1 Spindle Controls
60
5.2.3.2 Tool Label, Collet Open/Closed, G30 Controls, Ref Axes Buttons
60
5.3 Keyboard Shortcuts
61
5.4 Main Tab
61
5.4.1 Selecting a Recent G-code Program File
62
5.4.2 Working in the G-code Window
62
5.4.2.1 Setting a New Start Line
62
5.4.2.2 Expanding the G-code Window
63
5.4.3 Manually Entering Commands
63
5.4.3.1 Searching in the Code
63
5.4.4 Working in the Tool Path Window
64
5.4.4.1 Changing the View of the Tool Path Window
64
5.5 File Tab
65
5.5.1 Managing Files
65
5.5.1.1 Transferring Files or Folders from a USB Drive
65


---

## PDF Page 11

Chapter 1
11
UM10225_15L_Slant-PRO_Manual_0626A
Preface
5.5.2 Loading G-code
66
5.5.3 Editing G-code
66
5.5.3.1 Editing G-code with a Text Editor
66
5.5.3.2 Editing G-code with Conversational Programming
66
5.6 Settings Tab
68
5.6.1 Selecting the Tool Changer Type
68
5.6.2 Enabling Feeds and Speeds Suggestions in Conversational Programming
69
5.7 Offsets Tab
69
5.7.1 Tool Touch Tab
70
5.7.1.1 Touch X (Dia.)
70
5.7.1.2 Touch Z
71
5.7.2 Offsets Table Tab
72
5.7.2.1 Creating Tool Descriptions
72
5.7.3 Tool Offset Information Backup
75
5.8 Conversational Screens
76
5.8.1 Overview
76
5.8.2 Using Feeds and Speeds Suggestions
79
5.8.2.1 Adjusting DRO Values
80
5.8.2.2 Refreshing DRO Values
80
5.8.3 OD Turn Tab
81
5.8.4 ID Turn Tab
83
5.8.5 Profile Tab
85
5.8.6 Face Tab
91
5.8.7 Chamfer and Radius Tab
93
5.8.8 Groove and Part Tab
96
5.8.9 Drill and Tap Tab
99
5.8.10 Thread Tab
101


---

## PDF Page 12

Chapter 1
12
UM10225_15L_Slant-PRO_Manual_0626A
Preface
5.9 Status Tab
104
6. Programming
106
6.1 Definitions
106
6.2 Tool File
110
6.3 Part-programs Language
110
6.3.1 Overview
110
6.3.2 Parameters 
111
6.3.3  Coordinate Systems
111
6.3.4 Formatting G-code Lines (Block) 
111
6.3.5 Line Number
112
6.3.6 Subroutine Labels
112
6.3.7 Word
112
6.3.8 Number
112
6.3.9 Comments and Messages
113
6.3.10 Item Repeats
114
6.3.11 Item Order
116
6.3.12 Commands and Machine Modes 
116
6.4 Modal Groups
116
6.5 G-codes
117
6.5.1 Rapid Linear Motion – G00
119
6.5.2 Linear Motion at Feed Rate – G01
120
6.5.3 Arc at Feed Rate – G02, G03 
120
6.5.3.1 Radius Format Arc
120
6.5.3.2 Center Format Arc
120
6.5.4 Dwell – G04 
121
6.5.5 Lathe Diameter Mode – G07
121
6.5.6 Set Offsets – G10
121


---

## PDF Page 13

Chapter 1
13
UM10225_15L_Slant-PRO_Manual_0626A
Preface
6.5.7 Set Tool Table – G10 L1
121
6.5.8 Set Coordinate System – G10 L2
122
6.5.9 Set Tool Table – G10 L10
122
6.5.10 Set Tool Table – G10 L11
123
6.5.11 Set Coordinate System – G10 L20
123
6.5.12 Plane Selection – G17, G18, and G19 
123
6.5.13 Length Units – G20 and G21 
123
6.5.14 Return to Pre-defined Position – G28, G28.1 
124
6.5.15 Return to Pre-defined Position – G30, G30.1 
124
6.5.16 Spindle Synchronized Motion – G33
124
6.5.17 Rigid Tapping – G33.1
126
6.5.18 Compensation Off – G40
127
6.5.19 Cutter Compensation – G41, G42
127
6.5.20 Dynamic Cutter Compensation – G41.1, G42.1
127
6.5.21 Move in Absolute Coordinates – G53 
128
6.5.22 Select Work Offset Coordinate System – G54 to G59 and G59 P~ 
128
6.5.23 Set Path Control Mode – G61, G61.1 
129
6.5.24 Set Blended Path Control Mode – G64 
129
6.5.25 Threading Cycle – G76
129
6.5.25.1 Optional Settings
130
6.5.26 Tapping Cycle – G84
131
6.5.27 Distance Mode – G90, G91 
132
6.5.28 Arc Distance Mode – G90.1, G91.1
132
6.5.29 G92 Offsets – G92, G92.1, G92.2, and G92.3 
132
6.5.30 Feed Rate Mode – G93, G94, and G95
133
6.5.31 Spindle Control Mode – G96, G97
134
6.6 Built-in M-codes 
135


---

## PDF Page 14

Chapter 1
14
UM10225_15L_Slant-PRO_Manual_0626A
Preface
6.6.1 Program Stop and Program End – M00, M01, M02, and M30 
135
6.6.2 Spindle Control – M03, M04, and M05 
136
6.6.3 Coolant Control – M07, M08, and M09
136
6.6.4 Automatic Collet Closer Control – M10 and M11
136
6.6.5 Override Control – M48, M49 
136
6.6.6 Feed Override Control – M50
136
6.6.7 Spindle Speed Override Control – M51
136
6.6.8 Set Current Tool Number – M61
138
6.6.9 Call Subroutine – M98
138
6.6.10 Return from Subroutine – M99
138
6.7 Other Input Codes 
138
6.7.1 Feed Rate – F 
138
6.7.2 Spindle Speed – S 
139
6.7.3 Change Tool – T
139
6.8 Repeated Items
140
6.9 Order of Execution 
140
6.10 Error Handling 
141
6.11 Parameters and Expressions
142
6.11.1 Parameters 
142
6.11.2 Expressions
146
6.12 O-codes
147
7. Maintenance
153
7.1 Lathe Maintenance Schedule
153
7.2 Understanding Machine Design
154
7.2.1 Machine Stiffness
154
7.2.2 Backlash, Friction, and Lost Motion
154
7.2.3 Factors Combine
155


---

## PDF Page 15

Chapter 1
15
UM10225_15L_Slant-PRO_Manual_0626A
Preface
7.2.4 Adjusting Geometry
155
7.2.5 Achieving Accuracy in Machining
155
7.2.6 Rust Prevention
155
7.3 Gibs, Dovetail Slideways, and Lubrication
156
7.3.1 Gib Adjustment Procedure
157
8. Troubleshooting
159
8.1 Troubleshooting Basics
159
8.2 Tips and Tools for Troubleshooting (equipment and procedures)
159
8.2.1 Safety
159
8.2.2 Tips on Controller Diagnosis
160
8.2.3 Troubleshooting Tools
160
8.2.4 Using Digital Multimeter for Electrical Tests
160
8.2.4.1 Measuring DC Voltage
161
8.2.4.2 Measuring AC Voltage
161
8.2.4.3 Measuring Resistance
161
8.2.5 Contacting Technical Support
161
8.3 Frequently Found Problems
162
8.3.1 Loose Wires
162
8.3.2 Wire Hairs
162
8.3.3 Poor Cable Connections
162
8.3.4 Controller Restart Required
163
8.4 Review of Subsystems
163
8.4.1 Power Distribution Subsystem
163
8.4.1.1 Overview
163
8.4.1.2 Details of the Power Distribution Subsystem
163
8.4.2 Control Power Subsystem
165
8.4.2.1 Overview
165


---

## PDF Page 16

Chapter 1
16
UM10225_15L_Slant-PRO_Manual_0626A
Preface
8.4.2.2 Details of the Control Power Subsystem
165
8.4.3 Controller Communication Subsystem
167
8.4.3.1 Overview
167
8.4.3.2 Details of the Controller Communication Subsystem
167
8.4.4 Axis Drive Subsystem
167
8.4.4.1 Overview
167
8.4.4.2 Details of the Axis Drive Subsystem
168
8.4.5 Spindle Drive Subsystem
170
8.4.5.1 Overview
170
8.4.5.2 Details of the Spindle Drive Subsystem
170
8.4.5.3 Spindle Direction
172
8.4.6 Home Switches
173
8.5 Troubleshooting Subsystems
174
8.5.1 Power Distribution Subsystem
175
8.5.2 Controller Communications Subsystem
176
8.5.3 Axis Drivers Subsystem
176
8.5.4 Spindle Drive Subsystem
179
9. Diagrams and Parts Lists
182
9.1 Base Assembly (exploded view)
182
9.2 Lathe Bed Z-axis Assembly (exploded view)
184
9.3 Lathe Cross Slide Assembly (exploded view)
186
9.4 Lathe Headstock Assembly (exploded view)
188
9.5 Lathe Cabinet Hardware (exploded view)
190
9.6 Electrical Cabinet
192
9.7 Connections
194
9.8 Operator Panel
195
9.9 Ribbon Cable and Miscellaneous
196
9.10 Lubrication System
198


---

## PDF Page 17

Chapter 1
17
UM10225_15L_Slant-PRO_Manual_0626A
Overview
1.  Overview
The 15L Slant-PRO lathe is a general purpose CNC lathe. Pictured below is a typical 15L Slant-PRO 
lathe set up.
Item #
Component Name
Item #
Component Name
1
Electrical Cabinet
6
Operator Panel 
2
Serial Number Plate
7
Controller Cabinet
3
Main Disconnect
8
Coolant Tank Door
4
Emergency Stop Button
9
Coolant Tank
5
Start Button
10
Full Enclosure
Figure 1.1 
3
4
5
7
8
9
10
6
1
2


---

## PDF Page 18

Chapter 1
18
UM10225_15L_Slant-PRO_Manual_0626A
Overview
1.1  Specifications
Mechanical
Travels
X-axis
10”
Z-axis
12”
Feed Rates
Rapid Speeds
60 IPM
Key
Dimensions
Table Length
26”
Table Width
6”
Tool Holding
Gang tooling plate with three T-slots 0.625” (5/8”) 
Center Slot: 0.00 + 0.004” – Outer Slots: 0.000 + 0.008”
Manual quick change tool post.
8-position turret
Swing Over Bed
15”
Swing Over Carriage
6.2” (turret or manual tool post); 1.88” (gang plate)
Footprint
55” W x 66” H x 29” D
Spindle
Speed Range
250 to 3500 RPM (5C), 180 to 2500 RPM (6”chuck)
Horsepower
3 hp continuous
Drive System
Cartridge style spindle with double V-belt transmission
Design
D1-4 spindle w/ removable 5C taper insert
Temperature
Operating Range
55°F-100°F (13°C-38°C)
Electrical
Power 
Requirements
Primary (machine tool)
200 to 250 VAC1 single phase
Secondary (control/coolant 
systems)
115 VAC single phase
Recommended 
Circuit Amperage2
Primary 
20 AMP
Secondary
15 AMP (GFI protected)
1 230 VAC recommended; For voltages under 230 VAC, use of a Buck-Boost Transformer (PN 32554) is recommended.
2 Dedicated circuits recommended; do not use ground-fault interrupter (GFI) with primary circuit.


---

## PDF Page 19

Chapter 2
19
UM10225_15L_Slant-PRO_Manual_0626A
Installation
2.  Installation
2.1  Lathe Prep and Setup
2.1.1  Location
The area should be well lit, dry, have proper ventilation, provide for unobstructed machine motion 
and operation, and ensure unrestricted access to all lathe controls and the electrical cabinet. 
2.1.2  Electrical Requirements
 WARNING! Electrical Shock Hazard: Be sure to power off machine before making any electrical 
modifications. Failure to do so could result in serious injury or death.
•	 Primary: 200-250 VAC, 50/60 Hz at 20 Amps
NOTE: Continuous current is below 15 Amps, but requires a 20 Amp breaker or slow blow fuse 
to prevent nuisance trips of the circuit breaker on spindle start.
Either use a NEMA L6-20 plug, or hard wire the machine. A certified electrician must make all 
electrical connections, and it’s your responsibility to verify that the electrical installation of 
the machine meets all local regulations and electrical codes.
•	 Secondary: Separate wall outlet of 115 VAC, 50/60 Hz at 15 Amps
A separate wall outlet of 115 VAC at 15 Amps is required to act as power source for the 
controller, monitor, and coolant pump. This connection is made to the IEC power inlet at the 
rear of the electrical cabinet.


---

## PDF Page 20

Chapter 2
20
UM10225_15L_Slant-PRO_Manual_0626A
Installation
For non-conforming sites:
1.	 Replace the stock coolant pump with a 230 VAC compatible pump (Coolant Pump, Dual 
Voltage, 1/8 hp, PN 33128), and change the Voltage Setting Switch on the controller to 
230 VAC.
2.	 Use a step down transformer to convert 230 VAC to 110 VAC (Step-Up/Step-Down 
Transformer, PN 32009).
2.1.2.1  Electrical Noise
Both primary and secondary power should be provided by dedicated circuits. At the minimum, circuits 
should be isolated from electrically-noisy devices. In particular, high-inductive loads from units like 
vacuum cleaners or air compressors can be troublesome and/or cause controller malfunction. For 
non-conforming sites, refer to electrical requirement table earlier in this section.
2.1.2.2  Grounding
All power inputs to the lathe must be properly grounded. Check continuity between bare metal on 
machine frame and true earth ground (water pipe or similar) to ensure proper grounding.
2.1.2.3  Ground Fault Interrupter (GFI) Use
Primary power should not be protected by a ground fault interrupter (GFI) or residual current circuit 
breaker (RCCB), as this interferes with proper operation of the lathe’s variable frequency drive (VFD) 
spindle controller.
A GFI or RCCB must be used to supply power to the secondary 115 VAC power supply. The controller, 
monitor, and coolant system are not bolted to the machine frame so proper grounding cannot 
be assumed. The combination of electrical power and water-based coolant systems makes GFI 
protection for the 115 VAC circuit very important.
2.2  Receiving, Uncrating, and Initial Inspection
2.2.1  Uncrating
 WARNING! Transport and Lift Hazard: The transport, lifting, and moving of lathe should be done by 
trained professionals. Failure to do so could result in machine damage, serious injury, or death.
1.	 The 15L Slant-PRO is shipped on a standard pallet and can be off-loaded from a truck with a 
tailgate lift and moved  to the desired install location with a hydraulic pallet jack.
 CAUTION! Sharp Objects: Wear gloves when uncrating the machine. Failure to do so could result 
in serious injury.
2.	 Use strap snips and a small pry bar to open and disassemble shipping crate. Remove top of 
crate first, followed by four sides.


---

## PDF Page 21

Chapter 2
21
UM10225_15L_Slant-PRO_Manual_0626A
Installation
3.	 Remove and discard the plastic packaging from the machine.
2.2.2  Shipping Damage or Shortages
Once received, inspect and note any shipping damage that may have occurred during transit. Also 
check received goods against packing list. Any damage claims or shortages must be addressed within 
30 days of receipt.
2.2.3  Remove Machine from Pallet
 WARNING! Transport and Lift Hazard: The transport, lifting, and moving of the machine should be 
done by trained professionals. Failure to do so could result in machine damage, serious injury, or death.
2.2.3.1  Lathe Lift Kit
The preferred method of lifting the lathe is using the Lathe Lift Kit (PN 33269) to raise the machine 
with four temporary legs and jack screws.
NOTE: Before separating the lathe from the pallet, ensure there is enough space on the sides of the lathe to 
slide the pallet out from underneath it. If walls or immoveable objects are in the way, a different location 
may be required.
1.	 Cut a strip of wood down the entire length of the pallet, on both the front and the back side, 
to provide clearance for the lifting feet. A skill saw works well for this (see Figure 2.1).
Figure 2.1


---

## PDF Page 22

Chapter 2
22
UM10225_15L_Slant-PRO_Manual_0626A
Installation
2.	 Tape the electrical cabinet door shut 
to prevent it from swinging open 
during the lift procedure.
3.	 Open the coolant tank door on the 
front of the lathe and temporarily 
slide it off of the shipping pallet.
NOTE: Do not remove the pallet out before 
removing the Coolant Tank. Failure to do so could 
result in machine damage.
4.	 Cut the shipping straps the secure the 
emergency stop box and power cable 
to the pallet.
5.	 Four pallet bolts are used to 
temporarily attach the pallet to the 
lathe; identify two right-hand bolts 
located inside the controller cabinet 
(see Figure 2.3).
6.	 Loosen and remove nuts and 
washers from two bolts inside the 
controller cabinet.
7.	 Identify two small Access Panels on 
left side of lathe (see Figure 2.2).
8.	 Using a Phillips screwdriver, remove 
Access Panels; set aside.
9.	 Loosen and remove nuts and 
washers from two bolts inside the 
Access Panels.
10.	Using four M8 x 20 mm Socket 
Head Cap Screws and four M8 Flat 
Washers, attach one Lifting Foot to 
each of the four corner attachment 
sites (see Figure 2.4); securely 
tighten.
Figure 2.2 
Access 
Panel
Figure 2.3 
Figure 2.4


---

## PDF Page 23

Chapter 2
23
UM10225_15L_Slant-PRO_Manual_0626A
Installation
11.	Slide a Lifting Pad underneath each 
of the four installed Lifting Feet; 
align hole on Lifting Pad with Lifting 
Foot’s bolt hole (see Figure 2.5).
12.	Attach one M20 x 250 mm Threaded 
Rod through each Lifting Foot and 
into its Lifting Pad (see Figure 2.6).
13.	Using a socket wrench, gradually 
adjust each Lifting Foot to raise the 
lathe evenly until lathe is clear of 
the floor (see Figure 2.7).
14.	Slide the pallet from underneath 
the lathe.
15.	Depending on the accessories that 
you’re going to install on your lathe, 
do one of the following:
a.	 Installing a Turret: Keep the 
lifting feet on the lathe for the 
turret installation procedure. 
When finished installing the 
turret, go to Attach Lathe Feet.
b.	 No 
Turret: 
Go 
to 
Basic 
Installation 
Procedure 
and 
follow the instructions to attach 
the lathe feet onto the machine.
Figure 2.6 
Figure 2.7 
Figure 2.5


---

## PDF Page 24

Chapter 2
24
UM10225_15L_Slant-PRO_Manual_0626A
Installation
2.3  Basic Installation Procedure
This section covers basic installation of a 15L Slant-PRO lathe.
2.3.1  Attach Lathe Feet
1.	 Unscrew Leveling Screw on each Lathe Foot until close to full height (see Figure 2.8); apply a 
dab of grease on threads.
2.	 Screw one 4” Threaded Stud into each Lathe Foot (see Figure 2.9); slide a Spacer onto each 
stud.
3.	 Insert each lathe foot assembly into 
base of lathe via a lag bolt hole (see 
Figure 2.10). Slip a Washer onto 
each Threaded Stud and secure feet 
tightly with nuts.
NOTE: Lifting Feet are not intended to support 
the lathe during operation.
4.	 Reattach two Access Panels set 
aside earlier (see Figure 2.2).
5.	 When the lathe is completely 
supported by four lathe feet, lower 
four M20 x 250 mm Threaded Rods 
in stages until the lathe rests on its 
feet; remove rods.
6.	 Unscrew and remove four M8 x 20 
Socket Head Cap Screws and M8 
Washers securing each Lifting Foot 
to the lathe; remove four Lifting 
Feet from lathe.
Figure 2.8 
Leveling 
Screw
Lathe 
Foot
Figure 2.9 
Spacer
4” Threaded 
Stud
Figure 2.10 
Leveling 
Screw
Washer
4” Threaded 
Stud
Spacer


---

## PDF Page 25

Chapter 2
25
UM10225_15L_Slant-PRO_Manual_0626A
Installation
2.3.2  Install the Controller Arm
The Controller Arm mounts to the right-hand side of the lathe stand. One of the two red Emergency 
Stop buttons mounts to the underside of the keyboard tray and should protrude past the edge of 
the tray far enough to be easily accessible.
IMPORTANT! If you set up the controller in a different configuration, you must make sure that the lathe’s 
remote Emergency Stop button is installed so that it is easily accessible to you.
To install the Controller Arm:
1.	 Identify 
the 
correct 
mounting 
position for the controller arm on 
the machine stand.
2.	 Make sure that there are no 
obstructions inside of the machine 
stand.
3.	 Use two sets of M8 x 30 mm socket 
head cap screws, M8 hex nuts, M8 
flat washers, and M8 lock washers 
to attach the mounting clevis to the 
machine stand (see Figure 2.11). 
Make sure that the cable slots on 
the square tube arm are facing as 
shown in Figure 2.11.
4.	 Insert the round monitor post into the square tube arm and tighten the cross bolt (see Figure 
2.12). Make sure that the holes are along the inside of the round monitor post as shown in 
Figure 2.12. 
NOTE: You can adjust the working height of the post the keyboard table and the monitor are attached.
5.	 Use a dead-blow hammer (or similar) to tap the end plug into the square tube arm (see Figure 
2.13).
Figure 2.11 
Cable Slots
2-Hole 
Clevis
Figure 2.12 
Figure 2.13 
End Plug


---

## PDF Page 26

Chapter 2
26
UM10225_15L_Slant-PRO_Manual_0626A
Installation
6.	 Position the round monitor post to mount the keyboard table as shown in Figure 2.14. Tighten 
the applicable screws to maintain the desired position.
7.	 Use four M5 x 25 mm socket head screws, four M5 flat washers, and four M5 lock washers to 
attach the keyboard table to the round monitor post (see Figure 2.15).
8.	 Use four M4 x 12 mm wood screws to attach the Emergency Stop box below the keyboard 
table (see Figure 2.16).
9.	 Use four M4 x 8 mm flat head screws to attach four 
wire tie mounts to the round monitor post (see 
Figure 2.17).
10.	Use two M4 x 8 mm flat head screws to attach two 
Emergency Stop cable clips to the bottom of the 
square tube arm.
11.	Use four M4 x 10 mm Phillips round head screws 
to attach the monitor, and then route the cables 
through the controller arm.
NOTE: We recommend wrapping all cable connections in electrical 
tape.
12.	Adjust the monitor height and keyboard angle as 
needed.
Figure 2.14 
Figure 2.15 
Figure 2.16 
Figure 2.17


---

## PDF Page 27

Chapter 2
27
UM10225_15L_Slant-PRO_Manual_0626A
Installation
2.3.3  Install the Monitor
The PathPilot controller mount allows 
you to install the PathPilot controller 
behind the monitor (which is attached 
to the Controller Arm).
Note: If you’re using a Touch Screen Kit (PN 
35575), you must first remove the stock 
mounting bracket from the back of the 
monitor.
1.	 Put the PathPilot controller 
mount 
against 
the 
monitor 
mounting plate. Then, put the monitor on the other side of the PathPilot controller mount, 
and align the holes on the three components.
2.	 Attach the monitor, PathPilot controller mount, and monitor mounting plate together with 
four M4 × 12 mm socket head cap screws (provided with the PathPilot controller mount).
3.	 Adjust the position of the monitor and the keyboard tray with an 8 mm hex wrench and a 16 
mm wrench. Once complete, securely tighten the pivot screws.
2.3.4  Install the PathPilot Controller
The PathPilot controller attaches to the top of the PathPilot controller mount and behind the 
monitor.
1.	 Put four standoffs into the controller and tighten them by hand (see Figure 2.19).
2.	 Find the four M4 screws and the VESA plate included with the controller. Then, mount the 
VESA plate to the PathPilot Controller VESA Mount (PN 50382). Make sure to put it flat side 
down with the keyholes toward the monitor (see Figure 2.20).
Figure 2.18 
PathPilot Controller Mount
Monitor
Monitor 
Mounting 
Plate
Figure 2.19 
Figure 2.20


---

## PDF Page 28

Chapter 2
28
UM10225_15L_Slant-PRO_Manual_0626A
Installation
3.	 Attach the controller to its mount 
by sliding the standoffs through the 
key slots (see Figure 2.21).
4.	 Find the PathPilot Controller for 
15L Lathe/PCNC Mills (PN 50848) 
provided. Then, remove the film 
from the double-sided tape on the 
case.
5.	 Put the case below the PathPilot 
Controller VESA Mount. Press down 
firmly to attach it in place.
6.	 Connect all USB accessories to the 
controller (or USB hub, if you’re 
using one):
•	 Jog Shuttle (PN 30616)
•	 Keyboard
•	 Mouse
•	 Monitor
7.	 Connect the monitor’s video cable to the PathPilot controller.
8.	 Route the loose end of the video cable toward the monitor, and then connect it to the monitor.
9.	 Connect the power supply to the PathPilot controller.
10.	Route the loose end of the power cords (from the USB hub and both PathPilot controller 
units) to a power strip, and then connect them.
11.	Connect the DB-25 interface cable into the DB-25 outlet on the side of the electrical cabinet.
12.	Route the loose end of the DB-25 interface cable to the PathPilot Controller for 15L Lathe/
PCNC Mills case, and then connect it to the mill interface port.
13.	Find the Ethernet cable and connect it to the Ethernet outlet on the PathPilot controller for 
15L Lathe/PCNC Mills case.
14.	Route the loose end of the Ethernet cable toward the PathPilot controller, and then connect 
it to the PathPilot controller.
15.	Secure the wire loom, Ethernet cable, and power supply cables to the Controller Arm with six 
wire tie mounts and six cable ties.
Figure 2.21


---

## PDF Page 29

Chapter 2
29
UM10225_15L_Slant-PRO_Manual_0626A
Installation
2.4  Installation of Add-ons
2.4.1  Oiler
There are two oilers available for the 15L Slant-PRO lathe: the Automatic Oiler (PN 31374) and the 
Manual Oiler (PN 31302). 
For information on installation and use of the Automatic Oiler (PN 31374), go to tormach.com/docs.
2.4.1.1  Manual Oiler
1.	 Remove four bracket screws 
shown in Figure 2.22. 
2.	 Reverse plunger as shown 
in Figure 2.23 and  reinstall 
screws.
3.	 Using two M6 x 15 mm 
socket head cap screws, 
mount oiler to pre-drilled 
holes on side of lathe (see 
Figure 2.24).
4.	 Identify the access panel on the right 
side of the machine’s enclosure. 
Remove the 16 screws securing the 
panel to the enclosure, and set the 
screws and the panel aside.
5.	 Find the oil line inside the machine’s 
enclosure.
Figure 2.22 
Figure 2.23 
Figure 2.24


---

## PDF Page 30

Chapter 2
30
UM10225_15L_Slant-PRO_Manual_0626A
Installation
6.	 Route the oil line to the manual oiler:
a.	 Following the X-axis motor conduit toward 
the lathe bed (see Figure 2.25)
b.	 Through the access hole in the lathe bed 
casting toward the spindle (see Figure 2.26) 
c.	 Through the opposite access hole in the 
lathe bed casting  toward the back of the 
lathe (see Figure 2.27)
d.	 Toward the manual oiler installed on the 
stand along the back of the lathe
7.	 Connect oil line to manual oiler.
8.	 Using four M5 x 10 mm screws, mount Tubing 
Clips to pre-drilled holes and insert oil line; 
discard two surplus M5 x 10 mm screws.
9.	 Fill manual oiler reservoir with ISO VG68 Machine Oil (PN 31386) or similar.
Retract and release plunger until oil is pushed through system. After that, pull plunger:
•	 Each time lathe is powered on
•	 Every four hours of operation
10.	Reinstall the access panel to the right side of the machine’s enclosure using the 16 screws that 
you set aside earlier.
Figure 2.25 
Oil Line
X-axis Motor Conduit
Figure 2.26 
Figure 2.27


---

## PDF Page 31

Chapter 2
31
UM10225_15L_Slant-PRO_Manual_0626A
Installation
2.4.2  Turret
For information on installation and use of the Turret (PN 33273), go to tormach.com/docs.
2.5  Controller Customization
Date and Time
To set or edit controller’s date and time, 
type ADMIN DATE in the MDI line and click 
Enter on keyboard (see Figure 2.28). This 
opens a dialog box to enter or edit date, 
time, and time zone. Click Close when 
finished.
Keyboard Language
If you do not have a USA keyboard 
(QWERTY) layout, type ADMIN KEYBOARD 
in the MDI line and click Enter on your 
keyboard (see Figure 2.29).
Next, click on the Layouts tab to change 
the layout of the keyboard to a different 
language (see Figure 2.30). Select a layout 
and click Close when finished.
Touch Screen (optional)
For information on setup and calibration of the 17” Touch Screen Kit (PN 35575), go to tormach.
com/docs.
Figure 2.28 
Figure 2.29 
Figure 2.30


---

## PDF Page 32

Chapter 3
32
UM10225_15L_Slant-PRO_Manual_0626A
Operation
3.  Operation
This chapter provides an overview of the basic operation of the lathe.
 WARNING! Unattended Operation: Machine is not designed to operate unattended. Do not leave 
machine unattended during operation. When machine is not in use, turn the main disconnect off. Failure 
to do so could result in death, serious injury, and/or machine damage.
3.1  Power Off/Power On Procedure
IMPORTANT! Do not power on motors and drives via the green Start button before powering on the 
controller that oversees their operation. Ensure the controller is on and the PathPilot® interface is loaded 
before powering on the lathe. Likewise, make sure to depress the red E-stop before powering off the 
controller using the Exit button in the PathPilot interface.
Power Off/On Procedure
Power Off 
1. Push red E-stop in
2. Click Exit on screen; when prompted click OK to power off
3. Turn Main Disconnect Off (see image at right)
Power On
1. Turn Main Disconnect On (see image at right)
2. After software loads, turn red E-stop clockwise to release
3. Press green Start button
4. Click Reset on screen
3.2  Confirm Spindle Direction
Upon initial lathe setup, confirm the lathe’s spindle is rotating in the correct direction.
 WARNING! Entanglement Hazard: Keep hands, hair, jewelry, and clothing away from moving parts. 
Failure to do so could result in serious injury or death.
1.	 Power on the lathe and controller according to the Power Off/On Procedure detailed earlier in 
this chapter; close the chuck guard.


---

## PDF Page 33

Chapter 3
33
UM10225_15L_Slant-PRO_Manual_0626A
Operation
2.	 On the Main screen in the PathPilot interface, set chuck speed by entering 180 in the RPM 
field (see Figure 3.1). Then, press the Enter key on the keyboard.
3.	 Click Spindle FWD to start spindle rotation (see Figure 3.1).
4.	 Observe spindle direction to confirm forward is correct (see Figure 3.2); repeat to confirm 
reverse is correct by clicking Spindle REV and observing spindle direction (see Figure 3.3). If 
not rotating as shown, refer to Spindle Direction section in chapter 8, Troubleshooting.
Figure 3.1 
Figure 3.3 
Correct Reverse Spindle Direction
Figure 3.2 
Correct Forward Spindle Direction


---

## PDF Page 34

Chapter 3
34
UM10225_15L_Slant-PRO_Manual_0626A
Operation
3.3  Lathe Axes Definition
The lathe has two axes of motion, 
denoted as the X-axis and the Z-axis. The 
Z-axis is parallel to rotational axis of the 
spindle. The X-axis is perpendicular to the 
Z-axis and nominally parallel to the long 
dimension of the carriage (see Figure 3.4). 
The –X direction is toward the front and 
+X direction is toward the rear. The –Z 
direction is toward the headstock and the 
+Z direction is opposite the headstock.
3.4  Workholding
 WARNING! Unsupported Workpiece Hazard: Unsupported bar stock can bend and whip with 
deadly force. Properly support any bar stock extended out back of spindle bore. Failure to do so could 
result in serious injury or death.
The 15L Slant-PRO comes with a D1-4 spindle that includes a 5C taper insert for precision turning of 
stock less than 1.125” in diameter. Because this spindle has both D1-4 mounting and a 5C insert, you 
may configure lathe for use with either 6” D1-4 chuck or a 5C collet closer. A different motor pulley 
is included for use with the 5C configuration that allows you to run the lathe with a higher maximum 
spindle RPM when using 5C. For example, 3500 RPM for the 5C configuration and 2500 RPM with 
the 6” chuck configuration.
3.4.1  5C Collet Configuration (Maximum Speed Rating: 3500 RPM)
An optional lever-action 5C Collet Closer (PN 33283) must be purchased to use a 5C collet with a lathe. 
This lever-style closer can be refitted with an air cylinder for automatic control of closer operation 
via M-code. For more information and setup and adjustment procedures, refer to documentation 
that ships with the product.
3.4.2  D1-4 Chuck Configuration (Maximum Speed Rating: 2500 RPM)
For larger work pieces, 3-jaw 6” Chucks (PN 33156) and 4-jaw 6” Chucks (PN 33336) are available 
that fit the D1-4 cam lock spindle nose. Because larger work pieces require lower spindle RPMs and 
higher torque, the 6” chuck accessories necessitate the use of a smaller motor pulley. This pulley 
must be installed along with the chuck. This reduces the maximum spindle speed from 3500 RPMs 
to 2500 RPMs, but greatly increases the low-speed torque available for turning at lower RPMs.
Figure 3.4 
-Z
+Z
-X
+X


---

## PDF Page 35

Chapter 3
35
UM10225_15L_Slant-PRO_Manual_0626A
Operation
3.5  Tooling
The three tooling styles available for the Tormach 15L Slant-PRO are detailed below. All three options 
may be mixed – for example, a gang plate mounted tool could be used in conjunction with tooling 
mounted in a turret (for more information, refer to chapter 4, Intro to PathPilot).
3.5.1  Quick Change Tool Post (QCTP)
A manual Quick Change Tool Post Kit (PN 33272) can be 
mounted to the carriage to allow fast, repeatable manual 
tool changes (see Figure 3.5). The QCTP uses a dovetail and 
tapered gib to hold tool holders to the post at adjustable, 
repeatable distances from the lathe bed so that individual 
tools can be brought up to centerline height of the spindle. 
Available QCTP tool holders include standard 3/4” OD, ID 
(boring), and parting tool holders.
3.5.2  8-position Turret
The 8-position Turret (PN 33273) allows automatic tool 
changing of both turning and boring tools as well as through-
turret flood coolant. When equipped with a turret (see Figure 
3.6), the lathe automatically changes tools, numbers 1-8. Gang 
tooling or quick change tooling may be used in conjunction 
with a turret on lower portion of carriage.
3.5.3  Gang Tooling
A gang tooling plate with three T-slots and a riser block can be 
mounted to the carriage to facilitate mounting tool holders in 
industry-standard, gang-tool holding blocks (see Figure 3.7). 
Risers are available for both 1/2” and 3/4” centerline heights. 
This option offers higher precision and 
faster tool change times than a manual 
tool post or turret, but requires vigilance 
to ensure appropriate clearance between 
tool, workpiece, and chuck/spindle nose. 
Gang setups are ideal for small diameter, 
short parts. Additionally, gang blocks 
can be swapped out as a single unit, 
dramatically reducing part setup time.
Figure 3.7 
Figure 3.5 
Figure 3.6


---

## PDF Page 36

Chapter 3
36
UM10225_15L_Slant-PRO_Manual_0626A
Operation
3.6  Front Tool Post and Rear Tool Post Locations
Tools are mounted on the carriage in either a front tool post or rear tool post position. Front tool post 
tools address the workpiece by moving in +X direction; rear tool post tools address the workpiece 
by moving in –X direction (see Figure 3.8 and Figure 3.9).
The three tooling configurations for the 15L Slant-PRO have different tool post locations, detailed in 
the following table:
Tooling Configuration
Tool Post Locations
Quick change tool post
Front tool post
Gang tooling
Front or rear tool post
Turret
Rear tool post
3.7  Right-handed and Left-handed Tools
Tools have either a right-handed or left-handed orientation; right- or left-handed tools can be 
mounted on the carriage in either the front tool post or rear tool post position (see Figure 3.8 and 
Figure 3.9). The tool can be mounted either with the cutter facing toward the operator or turned 
with the cutter facing away from the operator, as shown in Figure 3.8 and Figure 3.9. Four cutting 
configurations are available for both a right- and left-handed tool (see Figure 3.8 and Figure 3.9).
+X
–X
+Z
–Z
Figure 3.8 
Right-handed Tool
Front Tool Post 
Location
Rear Tool Post 
Location
+X
–X
+Z
–Z
Figure 3.9 
Left-handed Tool
Front Tool Post 
Location
Rear Tool Post 
Location


---

## PDF Page 37

Chapter 3
37
UM10225_15L_Slant-PRO_Manual_0626A
Operation
Right- and left-handed tools cut in different directions depending on the spindle rotation direction, 
detailed in the following table:
Tool
Spindle Direction
Cutting Direction
Right-handed
Forward
–Z
Reverse
+Z
Left-handed
Forward
+Z
Reverse
–Z
Right-handed tools are commonly used for general purpose turning. Left-handed tools are sometimes 
used for back chamfering or grooving.


---

## PDF Page 38

Chapter 4
38
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.  Intro to PathPilot
4.1  Making Your First Part
This chapter shows you how to make your first 
part with the 15L Slant-PRO and assumes you have 
no prior experience running a part program on a 
CNC (computer numerically controlled) machine. 
If you have prior CNC experience, following this 
tutorial offers an introduction to the controls of 
the machine. After reading through this chapter, 
read chapters 5 and 6 for details on the PathPilot® 
operating system. This chapter is only intended to 
be an introduction to the PathPilot interface and 
several basic tasks. The first part program uses 
two tools (a right-hand turning tool and a parting 
tool) to turn a 1” aluminum work piece down 
to a 0.750” diameter bushing blank with flange 
(see Figure 4.1). For machine operators with the 
optional 8-position turret, this bushing can be used in the ID tool holders to hold drill bits. The 
following instructions will give you a quick start introduction to the lathe controls.
4.1.1  Reference the Lathe
Follow the power on procedure 
in chapter 3, Operation, to turn 
the controller and lathe on. After 
clicking the flashing Reset button, 
you can reference the X- and 
Z-axes by clicking the Ref X and 
Ref Z buttons. You may reference 
the axes in any order, but it is 
common to reference the Z-axis 
first to move the tooling as far 
as possible from any workpiece 
or chuck to avoid a crash. Both 
axes must be referenced before 
operating the lathe to establish soft limits, protecting the lathe from over travel and to giving 
meaning to work offset values. After referencing the axes you will notice that the LEDs on the Ref X 
and Ref Z buttons turn green, indicating that the machine tool has been referenced. While you can 
jog the machine before referencing, you cannot run parts until the machine has been referenced. 
Should one of your home/limit switches fail to work, manually reference the machine as discussed 
in chapter 8, Troubleshooting.
Figure 4.1 
Figure 4.2 
Right-hand Turning Tool 
(PN 33131) shown in 
QCTP holder (PN 33123)
Parting Tool (PN 33134) 
shown in QCTP holder 
(PN 33123)


---

## PDF Page 39

Chapter 4
39
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.1.2  Prepare the Workpiece
Using a 1” dia. x 3.5” long aluminium bar 
(or using PN 34718), insert the bar into 
the collet or chuck so that 2” protrudes 
from the face (see Figure 4.3). You will be 
machining the first 1.5” of this bar, and if 
you don’t leave a bit more sticking out, 
you risk crashing a tool into the chuck or 
spindle.
4.1.3  Prepare the Tools
Regardless of whether your lathe is set up for quick change, turret, or gang-mounted tooling (see 
Figure 4.4, Figure 4.5, and Figure 4.6), you need both a right-handed turning tool (PN 33131 or 
similar) and a parting tool (PN 33123 or similar) as shown in Figure 4.2. If using gang tooling, make 
sure there is at least 2” between tools. Also, ensure the Z position of the tools is within 1”-2” of each 
other. For example, a long drill bit may stick out much further in Z than other gang-mounted tools 
and collide with chuck or spindle when one of the shorter tools is brought in to machine workpiece. 
If using a turret, insert the turning tool in position 1 and the parting tool in position 2.
Figure 4.3 
Figure 4.4 
Figure 4.5 
Figure 4.6


---

## PDF Page 40

Chapter 4
40
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.1.4  Understand Machine Position, Work Offsets, and Tool Offsets
Work offsets are a concept that allows the operator to think in terms of X/Z coordinates with respect 
to the part instead of thinking of them with respect to the machine position.
Tool offsets allow the operator to use tools of different length or, in the case of gang tooling, different 
X/Z positions on the carriage. Tool offsets are broken down into two components: geometry offsets 
and wear offsets. Geometry offsets represent the distance from the work offset zero location to the 
tool’s control point. Unlike on a milling machine (where G43 must be called out to apply an offset), 
tool geometry offsets are automatically applied with the Txx tool change command.
Lastly, and very importantly, is the sign convention for a rear tool post slant bed CNC lathe like the 
15L Slant-PRO: Z negative is toward the spindle, and X negative is toward the operator. This becomes 
important when operators choose the manual tool change option or the gang tooling option.
IMPORTANT! All tools mounted for use on the operator side of the workpiece are touched off using negative 
X (diameter) values, and most X words in part programming for these tools will have negative values. 
In many cases, PathPilot warns the operator of a violation of this rule, but it has no way of preventing 
bad code from running.
4.1.5  Set the Length Units
You can program your machine in either inches or in millimeters. The machine uses the defined 
setting until you program a different command (G20 or G21). The settings are also retained after a 
power cycle, once the machine is out of reset.
4.1.5.1  Programming in Inches
Depending on your workflow, do one of the following:
•	 Type G20 in the MDI line and press Enter on your keyboard
•	 Program G20 in your G-code program
4.1.5.2  Programming in Millimeters
Depending on your workflow, do one of the following:
•	 Type G21 in the MDI line and press Enter on your keyboard
•	 Program G21 in your G-code program


---

## PDF Page 41

Chapter 4
41
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.1.6  Touch Off the Workpiece to Set the Work Offsets
There are many ways of conceptualizing tool and work offsets, but we use the idea of a true positive 
tool length to demonstrate this first part program. When using this method we must select a 
reference surface to use when establishing the work offset zero position. If you select the faces of 
a quick change tool holder or turret pocket as the reference surface, then the geometry offsets are 
equal in value to the stick out of the tool, hence the name, true positive tool length. 
The actual method differs depending on whether you have a gang, turret, or quick change tooling 
setup. For the purposes of this instruction, we assume you have the quick change setup and that 
you have adjusted your quick change tool holders to centerline height. Make sure that there are 
no tool geometry offsets currently applied by clicking Reset Tool on the Offsets screen (see Figure 
4.12), which clears the geometry offsets for the currently loaded tool. If the Offsets screen displays 
a selection of tools (see Figure 4.11), this indicates no tool offsets have been applied.
4.1.6.1  Setting the Z Work Offset
1.	 Insert an empty toolholder in your 
quick change tool post and jog 
the machine until the tool holder 
touches the end of the workpiece 
(see Figure 4.7). You may use a sheet 
of paper as a feeler gauge to tell you 
when you’re making contact.
2.	 When the tool holder has just 
touched the end of the work, click 
the Zero button next to the Z digital 
read out (DRO) to set the current 
work offset Z position to zero (see 
Figure 4.8).
Figure 4.8 
Figure 4.7


---

## PDF Page 42

Chapter 4
42
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.1.6.2  Setting the X Work Offset
1.	 Jog the tool holder down in X, over 
in Z, and approach the workpiece 
in X until the face of the holder just 
barely contacts the workpiece in X 
(see Figure 4.9).
2.	 Because this is a one inch diameter 
workpiece, and all positions on 
the operator side of the spindle 
centerline are negative, you need 
to enter -1.0 in the diameter DRO to 
touch off at 1” in X. Press Enter after 
typing in the DRO to apply the value 
(see Figure 4.10).
NOTE: This technique is used for setting any DRO. 
Remember to press Enter after any DRO change. 
If you forget and just click on another DRO, any 
value you have just entered is discarded. The 
purpose of this is to avoid accidental changes. 
3.	 Jog the machine back a safe distance 
away from the part.
4.1.7  Set the Tool Geometry Offsets
4.1.7.1  Setting Tool 1
Next we measure the tool geometry offsets for tool 1, a right-hand turning tool. If you are using a 
quick change tool post, manually insert tool 1 (a right-hand turning tool) into the tool post.
 WARNING! Entanglement Hazard: If using the (optional) turret tool changer, typing T01 in the MDI 
line causes the turret to index to the pocket 1 position. Keep hands, hair, jewelry, and clothing away from 
moving parts. Failure to do so could result in serious injury or death.
1.	 Select tool one in the PathPilot interface. This can be done either by typing T01 in the MDI line 
or by clicking the Offsets tab and typing 1 in the Tool DRO; click Enter.
Figure 4.9 
Figure 4.10


---

## PDF Page 43

Chapter 4
43
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
2.	 Click on the Tool Touch tab on the Offsets screen and select the front tool post, right-hand 
turning tool (see Figure 4.11). 
NOTE: Select the rear tool post right-hand turning tool for use with a turret; the next touch off screen is 
shown in Figure 4.12.
3.	 Click the Main tab and jog the machine (using either the jog shuttle or the keyboard arrow keys) 
until the tool is near the part (if using the keyboard arrow keys, left and right arrow correspond 
to -/+ Z, respectively,  and up and down arrow keys correspond to +/- X, respectively). To switch 
from step jogging to continuous mode, click the jog speed slider or the Jog 100% button. To 
switch from continuous mode to step jogging, click any step increment button.
4.	 Close the chuck guard or enclosure door.
Figure 4.11 
Figure 4.12


---

## PDF Page 44

Chapter 4
44
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
5.	 Adjust spindle speed to 500 RPMs – either by entering 500 in the RPM DRO and clicking FWD 
or by typing G97 M03 S500 in the MDI line (see Figure 4.13).
6.	 Using the jog controls, take a skim cut off of the diameter of the workpiece. This cut need only 
be long enough to measure the cut diameter with a micrometer. 
7.	 Jog the tool away from the workpiece in Z.
IMPORTANT! Do not jog the machine in X.
8.	 Stop the spindle by clicking either Stop or Spindle Stop, or by typing M05 in the MDI line (see 
Figure 4.13).
9.	 Measure the diameter of the skim-cut workpiece with a micrometer, then enter the negative 
of that value in the Touch X DRO on the Offsets screen Tool Touch tab and click the Touch X 
button. If using a turret or a rear-mounted gang tool, enter the positive value. Note that the 
LED on that button illuminates, indicating that a tool offset has been set for that tool.
10.	With the spindle off, jog the machine toward the face of the workpiece in the Z direction. 
You may touch off Z by using a piece of paper placed between the tool and the workpiece. 
Move the piece of paper back and forth while jogging the machine slowing in steps of 0.001” 
towards the face. When the paper binds up, enter the thickness of the paper in the DRO next 
to the Touch Z button (typically 0.003”); click Touch Z.
11.	Jog away from the workpiece. Look at both DROs: X (Dia.) and Z. Verify that they look 
appropriate for the current position of the tool. 
NOTE: The X (Dia.) DRO always displays diameter values, not radius. Therefore, when front tool post tool 
is 2” away from spindle centerline, X (Dia.) DRO should read 4.0”.
Figure 4.13


---

## PDF Page 45

Chapter 4
45
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.1.7.2  Touching Off the Parting Tool
1.	 Jog far enough away from the part that any tool change to another tool can be completed 
safely without crashing into the workpiece or chuck. This is especially important for gang 
tooling and turret operation, as the control completes these tool changes automatically.
2.	 Set the tool change position by clicking Set G30 on the Main tab. An illuminated LED in the 
corner of this button indicates that the G30 position has been set.
3.	 Go to the Tool Touch screen by clicking on the Offsets tab, and making sure the Tool Touch tab 
is active.
4.	 Change tools to tool 2 (the parting tool) by typing 2 in the T DRO on the Tool Touch tab; click 
Enter (see Figure 4.14).
5.	 You should see the tool type selection screen again (see Figure 4.11). Select the front tool 
post parting tool (unless using a rear tool post parting tool, in which case you should select 
the rear tool post parting tool).
6.	 If you make a mistake selecting the tool type, click Reset Tool to reset the tool type and bring 
you back to the tool selection screen.
NOTE: The control point for this tool is 4 (see Figure 4.14). This may seem unintuitive at first but when 
you consider that the length of the part (not the remaining stock in the spindle) is the critical dimension, it 
becomes clear that a parting tool’s control point should be 4. The control point diagram shown in Figure 
4.14 illustrates the control point, but does not necessarily match the insert shape.
7.	 Turn the spindle on and jog the machine to take a skim cut off of the diameter of the workpiece. 
8.	 Jog away from the workpiece in Z.
IMPORTANT! Do not move the tool in X.
Figure 4.14


---

## PDF Page 46

Chapter 4
46
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
9.	 Turn the spindle off and measure the diameter of the workpiece with a micrometer. Enter the 
negative of this diameter value in the DRO to the left of the Touch X button, then click Touch X.
10.	Touch Z using the same procedure described for tool 1. When the paper binds up, enter the 
thickness of the paper plus the width of the parting tool insert in the DRO next to the Touch Z 
button (typically 0.003” + 0.120”) and click Touch Z. 
NOTE: You must enter width of the insert because the control point of a parting tool is the right edge, not 
the left edge. 
11.	To double-check your work, you can go to the Offsets Table tab on the Offsets screen and look 
at the geometry offsets for each tool: the values in the X and Z columns represent the stick 
out of your tool past the faces of the tool holder. 
NOTE: X values are expressed in diameters so the actual stick out is half the number shown in the column, 
and is negative for front tool post tools (see Figure 4.15).
Congratulations, you’ve just successfully measured your tool offsets. If you don’t remove these 
tools from their holders (or pockets, for turret changers) you don’t need to go through the tool 
offset setting process again until you replace an insert.
4.1.8  Write the G-code
Now use the conversational programming capabilities of the PathPilot interface to generate G-code 
to produce our part. We’ll break this down into five steps:
1.	 Face the part.
2.	 Turn the 1” stock down to 0.9375” along the entire length of the part (1.5”).
3.	 Turn the first 1.25” of part down to .750”.
Figure 4.15


---

## PDF Page 47

Chapter 4
47
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.	 Chamfer the edge with a 0.050” break.
5.	 Part off.
The conversational screens are divided into two sections: parameters common to most operations 
are displayed on the left and parameters (including part geometry) that are operation-specific are 
displayed on the right.
The entry fields should be self-explanatory and are covered in detail in following chapters. For now, 
enter the values shown in each operation. Make note of a few things: 
•	 The initial X value is -1.000, not +1.000. This is because we’re using a front tool post tool, and 
all diameters on the operator side of the spindle centerline are expressed as negative values. 
If you have a turret or a rear-mounted gang tool, this would be a positive value.
•	 The spindle speed (both roughing and finishing) is expressed as SFM, not RPM. On a CNC 
lathe it is advantageous to use constant surface speed (which varies the RPM as the diameter 
changes) to increase part production rates and tool life and maintain a better cut throughout 
the program.
•	 The feed rates (roughing and finishing) are shown in inch/rev, not in inch/min. Like constant 
surface speed, programming in inch/rev allows for optimal tooling performance.
4.1.8.1  Operation 1
1.	 To write the code for the first operation, click the Conversational tab to bring up the 
conversational screens. Click the Face tab to bring up the facing screen (see Figure 4.16) to 
generate code to face the part back to Z of -0.100”.
2.	 Enter the values as shown in Figure 4.16.
3.	 Click Post to File on the Face tab to save the G-code (see Figure 4.16).
Figure 4.16


---

## PDF Page 48

Chapter 4
48
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.	 In the dialog window, click Save (see 
Figure 4.17); the file is saved and 
automatically loads into the control 
and displays the tool path.
To run the program:
1.	 Click and drag the MAXVEL slider 
(see Figure 4.18) to bring it down to 
zero percent.
2.	 Click Cycle Start (see Figure 4.18). 
If the current tool is not tool 1 
and the machine is configured for 
manual tool changes, the Cycle 
Start LED may blink requesting a 
tool change. Change the tool in your 
quick change tool post and confirm 
by clicking Cycle Start again.
NOTE: Turret and gang tool changes happen 
automatically without operator intervention.
3.	 Grab the MAXVEL slider again and 
slowly increase the allowed velocity. 
Bring the velocity back down to 
zero when you get close to the part 
and double check the values in the 
DROs. If everything looks correct, go 
ahead and move the MAXVEL slider 
back up to resume running the part 
program.
Figure 4.17 
Figure 4.18


---

## PDF Page 49

Chapter 4
49
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.1.8.2  Operation 2
1.	 On the Conversational tab, click on the OD Turn tab. Enter the values as shown in Figure 4.19. 
NOTE: If you are using front tool post tooling, all X (diameter) values must be written as negative numbers.
2.	 After you have entered the values, click Append to File (see Figure 4.19).
3.	 In the dialog window, select the file created when completing Operation 1 to add the OD Turn 
G-code and confirm Append to File (see Figure 4.20).
4.	 The changes to your file are loaded into the control, and you should see a tool path that looks 
something like Figure 4.21. 
IMPORTANT! Do not run this code until remainder of operations are written, then proceed to actually 
making the part.
Figure 4.20 
Figure 4.21 
Figure 4.19


---

## PDF Page 50

Chapter 4
50
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.1.8.3  Operation 3
1.	 The third operation uses another OD turn routine to turn the first 1.125” of the part down to 
0.750”. Enter the values as shown in Figure 4.22 on the OD Turn tab of the Conversational screen. 
2.	 Append this code to the file as you 
did at the end of the Operation 2 
section earlier in this chapter. The 
tool path should now resemble 
Figure 4.23.
Figure 4.22 
Figure 4.23


---

## PDF Page 51

Chapter 4
51
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.1.8.4  Operation 4
1.	 Put a small chamfer on the part using the Chamfer tab of the Conversational screen. Enter the 
values as shown in Figure 4.24.
NOTE: If you are using front tool post tooling, all X (diameter) values must be written as negative numbers.
2.	 Click Append to File on the Chamfer 
tab to add this code to the program. 
The tool path should now look like 
Figure 4.25.
Figure 4.24 
Figure 4.25


---

## PDF Page 52

Chapter 4
52
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.1.8.5  Operation 5
The final operation uses tool 2 (a parting tool) to part off the workpiece. 
1.	 Click the Groove/Part tab, then toggle the Groove/Part button to illuminate the Part LED. On 
the parting screen, enter the following values as shown in Figure 4.26.
2.	 Make sure to enter tool 2 in the tool 
DRO. If you try to use tool 1 you get 
an error message letting you know 
that a right-hand turning tool is not 
a valid tool for a parting routine. 
3.	 Finally, click on Append to File and 
choose the file you generated in 
the Operation 1 section earlier in 
this chapter. Your screen should 
now look like the screen shown in 
Figure 4.27. The finished workpiece 
is shown in Figure 4.28.
Figure 4.26 
Figure 4.27


---

## PDF Page 53

Chapter 4
53
UM10225_15L_Slant-PRO_Manual_0626A
Intro to PathPilot
4.1.8.6  Run the Completed G-code Program
Figure 4.27 shows a tool path representing 
the first, second, third, fourth and fifth. Run 
the program using the steps described in the 
Operation 1 section earlier in this chapter.
The techniques used to program the first part form 
the basis of most of the operations performed 
on the lathe. The big concept to remember is 
that front tool post tools use negative diameter 
values. This includes using negative diameters 
when setting work and tool offsets, as well as 
when using the conversational screens.
Figure 4.28


---

## PDF Page 54

Chapter 5
54
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.  PathPilot Interface
5.1  Overall Layout
The PathPilot® interface is divided into two main sections, the Notebook and the Persistent Controls 
(see Figure 5.1). The Persistent Controls make up the bottom half of the screen and include three 
groups: Program Control Group, Position Status Group, and Manual Control Group. These controls 
are present regardless of what task the operator is doing. The top half of the screen is a Notebook, 
which includes six tabs (Main, File, Settings, Offsets, Conversational, and Status) that can be used 
to select different Notebook pages, each of which display buttons, digital read outs (DROs), and 
information pertinent to different functions of the PathPilot interface. For example, the buttons and 
information on the File tab are used for such tasks as transferring a G-code file from a USB drive to 
controller hard drive, loading a G-code file into memory, or editing a G-code file.
Figure 5.1 
Persistent Controls
Program Control Group
Position Status Group
Manual Control Group
Notebook


---

## PDF Page 55

Chapter 5
55
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
While the Notebook allows you to perform a variety of tasks (loading G-code file, writing G-code with 
the conversational interface, touching off tools, etc.), the Persistent Controls contains the controls 
used to set up a job and execute G-code. Operators familiar with Tormach milling machines (or most 
other CNC machines) are familiar with many of the buttons on the bottom half of the screen.
5.2  Persistent Controls
The controls on the lower half of the 
screen are always present – they don’t 
move or disappear while paging through 
the notebook. Persistent controls are 
divided into three logical families: Program 
Control Group (see Figure 5.2), Position 
Status Group (see Figure 5.3), and Manual 
Control Group (see Figure 5.6).
5.2.1  Program Control Group
The buttons, sliders, and DROs on the 
Program Control Group are all functions 
that relate to tasks the operator might 
perform while running a G-code program. 
They may be used at any time while 
running a program, or before running a 
program to set modes like Single Block or 
M01 Break.
Cycle Start – Starts a program. Clicking this button triggers an alarm unless the chuck guard or 
enclosure door is closed and a valid G-code program is loaded. While running a program, the Cycle 
Start LED illuminates green.
If Single Block is active, the lathe executes one line of G-code per Cycle Start click. When running a 
program, if lathe motion is paused due to Feedhold, M01 Break, Single Block, or because the lathe 
is waiting on a manual tool change, the Cycle Start LED flashes until clicked again.
Single Block – Turns Single Block on (LED illuminated) or off (LED off). When single block mode is 
active, the machine executes one block of G-code, then pauses and flashes the Cycle Start LED, 
inviting the operator to click Cycle Start to execute the next line of G-code. This feature may be 
turned on or off before running a program or during program execution.
NOTE: Non-motion lines are ignored by single block mode. This means that the interface will skip comment 
lines and preparatory (non-motion G-codes) commands.
Figure 5.2


---

## PDF Page 56

Chapter 5
56
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
M01 Break – Turns M01 Break on (LED illuminated) or off (LED off). When M01 break is active, and 
an M01 (optional stop) is programmed in the G-code file, the machine stops when it reaches the 
M01 line and the Cycle Start LED flashes. The lathe continues to execute the program lines after the 
M01 when Cycle Start is clicked. This feature may be turned on or off before running a program or 
during program execution.
Feedhold – Turns Feedhold on (LED illuminated). Turning feedhold on pauses machine motion and 
the Cycle Start LED flashes. Turning feedhold on leaves the spindle running if it is already on. To 
turn feedhold off, click Cycle Start. The Feedhold button works during program execution or during 
manual data input (MDI) moves. Feedhold has no effect when the machine is not moving. Also, 
application of Feedhold is delayed if clicked during a G76 threading or G33.1 rigid tapping move until 
that spindle-synchronized move is complete.
Stop – Stops all machine motion, including spindle motion. If clicked while running a program or 
during an MDI move, the machine stops. If clicked while running a G-code program, it rewinds the 
G-code program (see Reset later in this section). Stop doesn’t change the current modal state of the 
machine (G54, G01, etc.).
Coolant – Turns Coolant on (LED illuminated) or off (LED off). Clicking this button powers on or off 
the coolant accessory port on the side of the electrical cabinet. This is the equivalent to M08 or M09 
G-code commands. It may be clicked before, after, or during program execution or an MDI move.
Reset – Brings the machine out of an E-stop condition, resets G-code modalities, clears alarm 
messages, and rewinds the G-code program. When the machine is first powered on, or after an 
emergency stop, the Reset LED flashes. When flashing and after the machine has been powered 
on again, clicking Reset starts and verifies communication between the machine and the controller.
Reset may be clicked at any time subsequent to powering on the machine. It has these effects:
•	 Resets all modal G-codes to their normal state including work offset to G54 default
•	 Rewinds a G-code program
•	 Stops a program or MDI move if one is currently in progress
•	 Clears alarms (for more information, refer to chapter 4, Intro to PathPilot)
•	 Clears the tool path backplot
Spindle Override – The Spindle Override slider and 100 Percent button allow overriding of the 
commanded spindle speed by percentages ranging from 1-150 percent. The 100 Percent button 
returns the override to 100 percent of the commanded value (in effect, no override). The spindle 
must be running for these controls to have a noticeable effect. If overriding the spindle when 
the spindle is stopped, the speed is overridden the next time the spindle is started. The override 
doesn’t drive the spindle past its maximum speed of 3500 RPM (5C configuration) or 2500 (6” chuck 
configuration). It does affect the speed of a spindle command limited by a D word.


---

## PDF Page 57

Chapter 5
57
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
For instance, G96 S300 D1000 prevents the spindle from going faster than 1000 RPM in constant 
surface speed mode, but commanding an override of 150 percent causes the spindle to turn at 1500 
RPM when the surface speed requirements and the diameter value demand it.
Feedrate Override – The Feedrate Override slider and 100 Percent button work similarly to the 
spindle override controls. They affect the commanded feedrate by a percentage from 1-150 percent. 
The feedrate override works for both MDI, jogging, and G-code program G01/G02/G03 moves. The 
override has no effect on G00 (rapid) moves.
MAXVEL Override – The Maxvel Override slider and 100 Percent button work similarly to the 
federate override controls, except that these controls affect both G00 and G01 moves. They clamp 
the machine velocity to a percentage of the maximum velocity. The Maxvel slider can be very useful 
when running new code for the first time. It can be used to stop the machine by sliding it down to 0 
percent and verifying that the Distance To Go and Dia./Z DROs look appropriate before continuing.
5.2.2  Position Status Group
The buttons and DROs of the Position 
Status Group pertain to machine position, 
active G-code modalities, and feed and 
speed settings (see Figure 5.3). These 
controls may be used at any time before 
or after running a G-code program or MDI 
move. They are unavailable for operator 
input while the machine is moving.
X (Diameter) and Z work offset DROs – 
next to the labels X (DIA) and Z – are DROs 
that display the current machine position 
expressed in the currently active work 
offset coordinate system (G54, G55, etc.). 
In the case of the X DRO , all values are 
expressed in terms of the diameter of the 
workpiece, not the radius. For instance, if 
the active tool is 2” away from the spindle 
centerline, the X DRO reads 4.000.
When the machine is at rest these 
readouts are also user entry fields. You 
can change the current work offset 
position by clicking the mouse in the DRO. 
It becomes highlighted (see Figure 5.4). 
Type a number, for example 4.0, and press 
Enter on the keyboard. The Esc key returns 
to the original value.
Figure 5.3 
Figure 5.4


---

## PDF Page 58

Chapter 5
58
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
IMPORTANT! This action does not move the machine, but does change the work offset setting.
This technique is used for setting any DRO. Remember to click Enter after any DRO change. Clicking 
on another DRO before clicking Enter discards any value just entered. This is designed to avoid 
accidental changes. For convenience, the Zero button to the left of the Z DRO can be used to set the 
Z work offset to 0.000.
X (Diameter) and Z Distance-to-Go Labels – Just to the right of the X and Z DROs are read-only 
distance-to-go labels in light blue. They display the distance remaining in any single move.
If you feedhold the machine in the middle of a move, or turn the MAXVEL or Feedrate overrides 
to zero percent, these labels display the distance left in the commanded move. These can be very 
helpful in proving out a part.
Status Line – The status line displays the currently active G-code modalities and the active tool. A 
more detailed description of these active G-codes is provided on the Settings screen.
F/REV, F/min DROs – As described in 
the G-codes section, the 15L Slant-PRO 
recognizes two feed rate modes: units per 
minute (G94) and units per revolution (or 
REV) of spindle (G95) as shown in Figure 
5.5. In units per minute feed rate mode, 
a G-code F word is interpreted to mean 
the controlled point should move at a 
certain number of inches or millimeters 
per minute, depending upon what length 
units are being used and which axis or 
axes are moving.
In units per REV feed rate mode, an F word is interpreted to mean the controlled point should move 
at a certain number of inches or millimeters per spindle revolution depending upon what length 
units are being used and which axis or axes are moving. 
NOTE: For almost all machining on a lathe, programming in units per revolution is more desirable.
These settings are mutually exclusive. In other words, you cannot simultaneously be in both F/Rev 
and F/Min modes. The F/Min and F/Rev DROs display the current F word in both units/revolution 
and units/minute. The active mode is indicated by both the F/Rev LED and the /REV and /MIN labels 
next to the DROs. When F/REV is active, its LED illuminates, the F/REV label is white, and the F/MIN 
label is gray. You can turn on F/REV mode using any of the following methods (see Figure 5.5):
•	 Click in the F/REV DRO, enter a value, and press Enter on the keyboard
•	 Click the F/REV button when the button LED is dark
•	 Type G95 into the MDI field and press Enter
•	 Run a G-code program that contains a G95 command
Figure 5.5


---

## PDF Page 59

Chapter 5
59
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
F/REV mode can be turned off by any of the following:
•	 Click in the F/MIN DRO, enter a value, and press Enter on the keyboard
•	 Click the F/REV button when the button LED is yellow
•	 Type G94 into the MDI field and press Enter on the keyboard
•	 Run a G-code program that contains a G94 command
SFM/RPM DROs - The 15L Slant-PRO recognizes two spindle speed command modes: constant RPM 
(G97) and constant surface speed (G96). For more information, refer to chapter 6, Programming.
In constant RPM mode (G97), the spindle turns at an RPM equal to the S word. For instance, G97 
S500 M03 starts the spindle at 500 RPMs. In constant surface speed mode (G96) the spindle RPM 
varies to maintain a constant speed in terms of linear feet per minute over the workpiece. For 
example, G96 S50 M03 turns the spindle on, and the linear speed at which the cutting tool’s control 
point travels over the work piece’s surface is 50 feet per minute. In constant surface speed mode, 
the actual spindle RPM depends on the diameter of the work being turned, increasing as diameters 
get smaller and decreasing as diameters get larger. Because tool life and efficiency depends on 
surface speed (and not RPMs), constant surface speed mode is the preferred mode of operation of 
CNC lathes.
5.2.3  Manual Control Group
The buttons and slider on the Manual 
Control Group allow the operator to jog 
the machine axes and start or stop the 
spindle (see Figure 5.6).
Jogging Controls – The 15L Slant-PRO can 
be jogged with either the jog shuttle or 
by using the arrow keys on the keyboard. 
When using the arrow keys:
•	 Left arrow jogs Z-axis in negative Z 
direction (toward spindle)
•	 Right arrow jogs Z-axis in positive Z 
direction (away from spindle)
•	 Up arrow jogs X-axis in positive 
direction (away from operator)
•	 Down arrow jogs X-axis in negative 
X direction (toward operator)
Keyboard jogging is only available on the Main screen and on the Tool Touch tab of the Offsets 
screen. The machine does not jog using the arrow keys when on screens other than Main or Offsets. 
Whether using the jog shuttle or keyboard, there are two modes of jogging: step and continuous.
Figure 5.6


---

## PDF Page 60

Chapter 5
60
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
In step mode, the machine jogs in steps, where the step size is controlled by the four buttons to the 
right of the Step: label. Notice than in imperial (G20) units the step sizes range from 0.0001” to 0.1”, 
whereas in metric (G21) mode the step sizes range from .01 mm to 10 mm. The LED in the upper 
right-hand corner of each of the step buttons indicates which step size is active. When all step LEDs 
are dark, the machine is in continuous jogging mode.
In continuous mode, the machine jogs at a continuous velocity when clicking and holding the arrow 
keys. The machine stops when the arrow key is released. The velocity is set using the jog speed 
slider (to the left of the Jog 100% button). To set jogging velocity to the maximum speed, either 
click and drag the jog speed slider to the far right position or simply click the Jog 100% button. To 
switch from continuous jogging to step jogging, click one of the step size buttons. To switch back 
to continuous jogging click the slider or Jog 100% button. Jogging is not available during program 
execution or during MDI moves.
5.2.3.1  Spindle Controls
The REV, Stop, and FWD buttons can be used to manually control the spindle. REV is the equivalent 
of typing M04 in the MDI field – it starts the spindle in the reverse direction at the RPM specified 
in the spindle RPM DRO (if in G97 – RPM mode) or at an RPM specified by the SFM DRO and the 
X (Dia.) value in the X DRO (if in G96 – Constant Surface Speed mode). The Stop button stops the 
spindle, similar to M05 command. FWD is the equivalent of typing M03 in the MDI field – it starts 
the spindle in the forward direction at the requested RPM. These buttons are unavailable when 
running a G-code program or in the middle of an MDI move. Clicking REV or FWD triggers an alarm 
if the chuck guard or enclosure door is open.
5.2.3.2  Tool Label, Collet Open/Closed, G30 Controls, Ref Axes Buttons
Below the spindle controls are the tool label (T:) and the Set G30 and Go To G30 buttons. The tool 
label displays the current tool, and if wear offsets are applied for that tool displays the wear offset 
number as well. In Figure 5.6, tool 1 is the current tool, but if the wear offsets for tool 1 were also 
applied, the field would read T: 0101. If the machine is equipped with a quick change tool post, and 
the manual tool change option is selected on Settings screen, this label flashes with the requested 
tool number when T command is encountered while running a G-code program. 
The Set G30 button allows you to jog the machine to a safe tool change position and set this position 
as the G30 position (for more information, refer to chapter 6, Programming). Clicking this button is 
equivalent to entering G30.1 in the MDI field. 
The Go To G30 button on the Offsets tab causes the machine to move to the G30 position in the 
Z-direction only, and is equivalent to typing G30 Z#5422 in the MDI field.
To set the G30 position, jog the machine to the desired position and click the Set G30 button. 
Subsequent uses of the G30 command in G-code or the Go To G30 button will cause the machine to 
move to this position.


---

## PDF Page 61

Chapter 5
61
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
Ref X and Ref Z buttons reference the axes to their home switch locations. This must be done after 
power on before you running a part program or using MDI commands. The axes must be referenced 
individually and not simultaneously. When referenced, the LED on each button turns green.
5.3  Keyboard Shortcuts
Several keyboard shortcuts are provided for operator convenience. Below is a list of shortcuts used 
in the PathPilot interface:
Spacebar
Feedhold
Alt+F 
Coolant
Alt + Enter
Give focus to MDI line
Alt+E
Edit currently loaded G-code program1
Alt+R
Cycle Start
1Use the Alt+E command on any PathPilot screen to edit G-code.
5.4  Main Tab
The Main tab is active by default when the PathPilot controller first powers on, and contains four 
controls: recent files, G-code window, MDI line, and tool path display (see Figure 5.7).
Figure 5.7


---

## PDF Page 62

Chapter 5
62
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.4.1  Selecting a Recent G-code Program File
The recent files drop-down menu displays 
the currently loaded G-code program 
file (see Figure 5.8). Click the drop-down 
menu to display the last five program files 
loaded into PathPilot; select the name of 
the program from the menu to load the 
G-code.
Select Clear Current Program in the 
recent files drop-down menu to close the 
currently loaded G-code program file.
5.4.2  Working in the G-code Window
The G-code window displays the G-code of the currently loaded program file. Use the scroll bars to 
view the entire file.
PathPilot highlights certain lines of code of interest. When running a G-code program in single block 
mode, there may be as many as three lines of G-code highlighted, each with a different color:
•	 Green line: indicates the start line, which is the first line in the program unless this has been 
changed with the Set Start Line feature
•	 Blue line: indicates the line of code that is currently executing
•	 Brown line: indicates the move that will occur the next time Cycle Start is pressed
The line at which the G-code program is executing – or start line – is highlighted in green. This 
usually is the first line of the code, but may be changed by placing the mouse pointer over the 
preferred start line, right clicking, and choosing the Set Start Line option.
5.4.2.1  Setting a New Start Line
The start line is the line at which the G-code program begins. By default, this is the first line of code 
in the G-code program. Right-click the preferred start line of code in the program and select Set 
Start Line to change the start line.
When using the Set Start Line option, the operator is responsible for ensuring that the machine is in 
the proper state before the code executes.
To set a start line in the middle of a G-code program file, make sure any preparatory moves (like 
turning the spindle and coolant on) are manually completed before clicking Cycle Start.
The machine reads backwards through the beginning of the G-code program file to do things like 
set the appropriate G5x active work offset, G61/64 setting, and other modal states. It will not turn 
the spindle or coolant on.
Figure 5.8


---

## PDF Page 63

Chapter 5
63
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.4.2.2  Expanding the G-code Window
Double-click the G-code window to expand 
the G-code window and shrink the tool path 
display. Double-click the G-code window 
again to return the display to its original size.
5.4.3  Manually Entering Commands
When running a G-code program, commands 
to the machine are read from a file. You can 
also send G-code commands to the machine 
directly with the MDI line (see Figure 5.9).
Click the MDI field to use the MDI line; the line is highlighted. Type the command, using the 
Backspace, Delete, Left and Right arrow keys to correct typing errors. Press Enter to execute the 
command; press Esc to abandon it.
Click the MDI field and use the Up or Down arrow keys to copy a recent MDI command into the MDI 
line. Up to 100 MDI commands are stored for reuse; these commands are saved between sessions. 
Command history is available after a power cycle.
NOTE: When the MDI line is open, all keystrokes are registered as a typed command. Jogging is not possible 
when you are clicked inside the MDI field.
5.4.3.1  Searching in the Code
MDI has the ability to search the text of a 
G-code program file for specific numbers, 
codes, or items of interest like tools, feeds, 
and speeds.
Type FIND followed by the text to be searched 
in the MDI line (see Figure 5.10). Pressing 
Enter finds the next instance of the searched 
text; pressing Enter while holding down the 
Shift key finds the previous instance.
If found, PathPilot scrolls to the line containing 
the searched text and highlights it in yellow 
(see Figure 5.10). When the search reaches 
the end of the G-code file, it wraps and starts 
again from the beginning.
Change the starting point of the search by 
clicking on any line in the G-code window.
Figure 5.9 
Figure 5.10


---

## PDF Page 64

Chapter 5
64
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
When used in conjunction with the FIND 
command, certain search terms (listed below) 
initiate a search through the G-code file to 
find more than just the actual search term:
•	 FIND TOOL: Searches for instances of 
the actual word Tool in the G-code and 
any T G-code command, which calls up 
a tool (e.g., T12)
•	 FIND SPEED: Searches for instances of 
the actual word Speed in the G-code 
and any S G-code command
•	 FIND FEED: Searches for instances of 
the actual word Feed in the G-code 
and any F G-code command (see Figure 
5.11)
NOTE: Search text ignores case, so the command 
FIND TOOL will match TOOL, Tool, tool, etc.
The FIND command simplifies searching of a G-code file to verify speed and feed values and tool 
calls before cutting a part, or to find a specific set start line point in a large G-code file. For more 
information on using set start line, refer to G-code Window earlier in this section.
5.4.4  Working in the Tool Path Window
The tool path window displays a graphic representation of the tool path that is executed for the 
currently loaded G-code file, each with a different color:
•	 White lines: indicates the preview lines
•	 Red lines: indicates the tool path as it is cut
•	 Yellow lines: indicates jogging moves
•	 Dotted blue lines: indicates the boundary box, which represents the ends of travel of the axes
Double-click the tool path window, or click Reset, to erase the jogging or tool path lines.
5.4.4.1  Changing the View of the Tool Path Window
Grid lines are visible behind the tool path when the view is top, front, or right. Grid lines are not 
available in ortho. By default, grid lines are drawn at 0.5” intervals when in G20 mode (5 mm intervals 
when in G21 mode). Right-click anywhere in the tool path display and select a different grid spacing 
to change the resolution of the grid lines. When a program is loaded, the program extents (furthest 
points to which the tool will travel while executing the G-code) are displayed to the left and bottom 
of the tool path.
Figure 5.11


---

## PDF Page 65

Chapter 5
65
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.5  File Tab
The File tab is used to transfer files to and from a USB drive, copy, delete, and rename files and 
folders (see Figure 5.12). The left window shows files and folders on the controller hard drive; the 
middle window shows files and folders on a removable USB drive.
NOTE: The controller does not run programs from the USB drive. Programs must first be copied to the 
controller before they can be loaded into memory and run. For more information, refer to Transferring 
Files or Folders from a USB Drive later in this section.
5.5.1  Managing Files
Use the New Folder, Rename, and Delete buttons below the respective USB Drive Window and Hard 
Drive Window for file management (see Figure 5.12). To move files into a folder, right-click on the 
file and select cut or copy from the pop-up menu.
5.5.1.1  Transferring Files or Folders from a USB Drive
1.	 Insert a USB drive into an open USB port.
2.	 Navigate to the file to transfer in the USB drive window (see Figure 5.12). 
NOTE: Use Back to navigate backwards; use USB to jump to the highest (home) level (see Figure 5.12).
3.	 In the hard drive window, navigate to the desired location in the PathPilot system to copy the 
transferred file from the USB drive.
4.	 Highlight the file or folder to copy in the USB drive window; click Copy From USB (see Figure 
5.12).
Figure 5.12 
Hard Drive Window
USB Drive Window


---

## PDF Page 66

Chapter 5
66
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.	 If the file to be transferred has the same name as an existing file on the controller, you can 
either overwrite the file, give it a different name, or cancel the file transfer.
6.	 When copied to the new location, the file displays in the USB drive window.
7.	 Click Eject to disconnect the USB drive from the controller (see Figure 5.12).
NOTE: Ejecting the USB drive this way helps to avoid corrupting data on the USB drive.
5.5.2  Loading G-code
The Load G-code function is only available for files stored on the controller (see Figure 5.12).
1.	 Navigate to the desired .nc file in the hard drive window (see Figure 5.12); highlight the file 
and click Load G-code (see Figure 5.12).
2.	 Click on the Main tab; verify the G-code file name appears in recent files drop-down window. 
For more information on selecting a recent G-code program file, refer to Main Tab section 
earlier in this chapter.
5.5.3  Editing G-code
The G-code File Preview window displays the contents of the selected .nc file (see Figure 5.12). You 
can edit G-code in two ways on your PathPilot controller:
•	 Using a text editor
•	 Using the Conversational tab to edit a file created in PathPilot’s conversational programming
NOTE: For more information on using conversational programming in PathPilot, refer to Conversational 
Tab section later in this chapter.
5.5.3.1  Editing G-code with a Text Editor
1.	 Highlight the file and click the Edit G-code (see Figure 5.12).
2.	 A text editor opens the file in a new window for editing the contents of the file. Make the 
appropriate changes to the file and click Save.
3.	 Click the X in the upper right-hand corner of the screen to close the text editor.
4.	 Click OK when asked to reload the file.
5.5.3.2  Editing G-code with Conversational Programming
To edit the G-code using conversational programming, highlight the file and click Conv. Edit (see 
Figure 5.12). A job assignment editor opens the file in a new window for editing the contents of the 
file. The left window shows job assignments of a program; the right window previews the program 
(see Figure 5.13).
Use Move Up, Move Down, Duplicate, or Remove to edit the order in which the steps of the program 
occur.


---

## PDF Page 67

Chapter 5
67
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
Click Insert Step to create a new job assignment using conversational programming. PathPilot opens 
the Conversational tab; after creating the job assignment, click Insert. If necessary, edit the order of 
the newly created job assignment in the program.
Click Insert File to load an already created G-code file into the program – allowable G-code files can 
be hand-written, generated from a CAM software, or generated from PathPilot’s conversational 
programming. Navigate to the desired .nc file and highlight; click Open. If necessary, edit the order 
of the newly created job assignment in the program.
Highlight a job assignment and click Conv. Edit to edit a job assignment created in conversational 
programming. PathPilot opens the relevant tab of the Conversational tab; make the appropriate 
changes to the job and click Finish Editing to update the G-code program file.
Click Revert to restore any edited job assignment to its original parameters. Revert is only available 
for individual job assignments created in conversational programming.
Click Close and, when prompted, Close Without Saving to restore the entire G-code program file to 
its original parameters. PathPilot exits the conversational edit screen without overriding the original 
G-code program file.
Figure 5.13


---

## PDF Page 68

Chapter 5
68
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.6  Settings Tab
The Settings tab displays active settings of the PathPilot controller, allowing you to configure 
PathPilot to suit your machine configuration (see Figure 5.14).
The window on the left side of the Settings tab displays a list of available G-code modalities. Active 
G-codes are highlighted in yellow (see Figure 5.14).
5.6.1  Selecting the Tool Changer Type
Select the tool changer type for specific machine configuration. Machine behavior when it encounters 
a T command is different depending on which tool changing option is selected (see Figure 5.14).
Turret: T commands T01 through T08 cause the turret to index (regardless of current machine 
position) and the offsets for the requested tool are applied. With the turret setup, tool numbers 
higher than eight are still available, and a T command of, for example, T09 does not cause turret 
rotation but does apply the offsets for tool 9. It is possible to mount a parting tool or gang of drills 
to the lower portion of the carriage and assign tool numbers higher than eight to these tools. 
The machine does not automatically retract to G28 or G30 position before a tool change. It is the 
operator’s responsibility to program the machine to a safe position before executing a T command. 
If generating code using the conversational features of the control, a G30 is inserted before each 
tool change command.
Gang: If the gang option is selected, the T command simply applies the offsets for the selected tool. 
Unlike the manual tool change option, T commands with the gang option selected does not pause 
the program during the tool change. Offsets are applied nearly instantaneously, and machining 
resumes automatically during part program execution. 
Figure 5.14


---

## PDF Page 69

Chapter 5
69
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
Manual: The manual tool change option causes the machine to pause at the T command during 
G-code program execution. This allows the operator to manually change tools on a quick change 
tool post (QCTP). After changing tools, clicking the Cycle Start button resumes program execution 
with the new tool offsets applied. When the machine is paused waiting for a manual tool change 
in the middle of a G-code program, the Cycle Start LED blinks and the tool label flashes with the 
requested tool number.
Mixed Tooling: When mixing turret or gang tools with QCTP-mounted tools, there are two choices:
1.	 If the operator selects the turret or gang setting, the lathe will not automatically pause for 
manual changes of QCTP tools. The operator must program these manual M01 stops. This is 
the recommended option.
2.	 If the operator selects the QCTP option, (s)he will have to click the Cycle Start button to 
confirm both manual and turret/gang changes.
5.6.2  Enabling Feeds and Speeds Suggestions in Conversational Programming
Select Conversational Feeds and Speeds to enable feeds and speeds suggestions in PathPilot when 
using conversational programming. For more information on use, refer to Using Feeds and Speeds 
Suggestions later in this chapter.
5.7  Offsets Tab
The Offsets screen is subdivided into two tabs – Tool Touch and Offsets Table (see Figure 5.15). The 
Tool Touch tab provides the selection of a tool type (i.e., front tool post left hand turning tool), as 
well as providing controls for setting the geometry offsets for tools (or touching off). The Offsets 
Table tab has an editable table of tool geometry, wear offsets, and a read-only table of work offsets.
Figure 5.15


---

## PDF Page 70

Chapter 5
70
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.7.1  Tool Touch Tab
The Tool Touch screen allows the operator to graphically select a tool, then touch off the tool to set 
the geometry offsets. The tool images act as buttons, and they highlight as they are moused over. 
The tools along the bottom of the screen are front tool post tools and are used by machines with a 
quick change tool post setups. The tools along top are rear tool post tools and are used by machines 
with a turret setup. Gang tooling setups typically use both front and rear tool post tools. For more 
information on front and rear tool post locations, refer to chapter 3, Operation.
Figure 5.16 shows a right-handed, front tool post turning tool highlighted as mouse hovers over it. 
Clicking on a tool image does a few things:
1.	 Sets the tip orientation for the tool, used (along with tip radius) in cutter compensation.
2.	 Sets the tool type (front tool post or rear tool post), used by the conversational routines to 
double check the user entry fields in an attempt to try to detect and prevent crashes.
3.	 Brings up the tool touch off dialogue. Figure 5.17 shows the tool touch off dialogue for a front 
tool post right-handed turning tool. 
The tip orientation has been automatically set to 3 in orientation graphic (see Figure 5.17). This 
dialogue is intended to make setting the tool geometry offsets (or touching off the tool) easy and 
intuitive.
5.7.1.1  Touch X (Dia.)
1.	 Take a skim cut off of the diameter of the workpiece. This cut only needs to be long enough to 
measure the cut surface with a micrometer. When done, jog the tool away from workpiece in 
Z, but do not jog machine in X.
Figure 5.16


---

## PDF Page 71

Chapter 5
71
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
2.	 Measure the diameter of the skim-cut workpiece with a micrometer, then enter that value 
in the Touch X DRO. If touching off a front tool post tool, enter the negative of the value 
measured. When this value has been entered, click the Touch X button. Notice that the LED 
on that button turns green, indicating that a tool offset has been set for that tool. If touching 
off a front tool post tool using a positive X value, PathPilot accepts the value, but warns that 
something is potentially incorrect. Front tool post tools should be touched off with negative 
X values.
5.7.1.2  Touch Z
1.	 Jog the machine toward the part zero (usually the face of the workpiece) in the Z direction. 
Move the tool so the cutting edge is just touching the surface of the material and define this 
as Z = 0. For now, use a thin sheet of regular paper.
2.	 Jog the Z-axis to approximately 1/4” away from part zero on the workpiece. If using keyboard 
jogging, change the slow jog percent DRO from 10 percent to 2 percent. The jog shuttle allows 
control of speed depending on how far the ring is turned.
3.	 With the paper between the tool and the workpiece, carefully jog until the paper just gets 
trapped by the tool. Do not ram the tool into the material; just touch the paper.
4.	 Enter the paper thickness in the DRO next to the Touch Z button (typically 0.003”) and click 
the Touch Z button.
5.	 One thing to consider when using these methods to measure your tool geometry is that while 
X of zero never changes (the spindle centerline is always X=0), the Z zero location may change 
depending on the length of the workpiece that is chucked into the spindle. As long as each 
tool is measured to a face that has been zeroed, only measure these tools one time or until an 
insert replacement is needed.
Figure 5.17


---

## PDF Page 72

Chapter 5
72
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.7.2  Offsets Table Tab
The Offsets Table tab of the Offsets screen displays an editable table of tool offsets (both geometry 
offsets and wear offsets) as well as a read-only table of work offsets (see Figure 5.18). To alter a 
value, double-click on the field; click Enter on the keyboard to accept the value. 
NOTE: The lathe must be powered on and out of Reset to edit these fields.
5.7.2.1  Creating Tool Descriptions
PathPilot uses keywords and patterns in the tool description to recognize tooling features. Refer to 
the section Using Tool Keywords later in this chapter for more information.
Figure 5.18


---

## PDF Page 73

Chapter 5
73
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
Example: “MVJN-R12-3B carbide AlTiN CRB FA:87.0 BA:52.0 finishing”
This description provides excellent information for PathPilot to calculate machining information:
•	 MVJN holder geometry
•	 Aluminum-titanium nitride coated carbide (AlTiN)
•	 Carbide
•	 87˚ front angle
•	 52˚ back angle
To get accurate machining information, all tooling must be described with detail: the more detail, 
the better results. Using a personal description likely won’t contain meaningful information for 
PathPilot.
Example: “Gold colored tool bit from middle drawer”
This description provides virtually no information. PathPilot will default to tool bit features from the 
setup on the Tool Touch tab. 
To Manually Enter Tool Descriptions
You can manually enter tool descriptions in the Offsets Table window. Descriptions are not case 
sensitive. On the lathe, tools are divided into two groups: Radial tools (which include all single-point 
turning tools), and axial tools (like drills, taps, and reamers).
If a pattern or word in the description is recognized, PathPilot uses syntax highlighting to indicate a 
valid description.
Refer to Using Tool Keywords section later in this chapter for more information.
Using Tool Keywords
Item
Pattern
Example
Notes
type
drill, tap, face-turn, facing, turning, 
profiling, chamfer, spot, centerdrill, 
boring, parting, threading, reamer
•	
Drill
•	
Chamfer
•	
Boring
tool radius
“R” or “radius”, followed by a 
colon, followed by a decimal 
number
•	
R:.0158
•	
radius:0.32
No radius specified is the 
same as a zero radius.
Front angle
“FA”, followed by a colon, followed 
by a decimal number
•	
FA:90


---

## PDF Page 74

Chapter 5
74
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
Item
Pattern
Example
Notes
Back angle
“BA”, followed by a colon, followed 
by a decimal number
•	
BA:90
tool material
carbide, HSS, CoHSS, CRB, carb, 
diamond, DMND
•	
HSS
•	
CoHSS
•	
crb
HSS: High-speed steel
CoHSS: Cobalt high-speed 
steel
CRB: Carbide
No tool material specified is 
the same as “HSS”.
tool diameter
“dia” or “diameter”, followed by 
a colon, followed by a decimal 
number
•	
Dia:.0341
•	
diameter:.750
For axial tools (drills taps, 
reamers, etc.).
tool coating
TiN, AlTiN, TiAlN, CNB, ZrN, TiB2, 
TiB, TiCN, DLC, uncoated, nACo
•	
TiN
•	
ZrN
•	
TiB2
No coating specified is the 
same as “uncoated”
length of cut
“loc”, followed by a colon, followed 
by a decimal number
•	
loc:0.875
For axial tools (drills, reamers, 
etc.). If no length of cut is 
specified, a length will be 
assumed based on cutter 
diameter.
tool width
“width” or “w”, followed by a 
colon, followed by a decimal 
number
•	
W:.118
•	
width:.118
For grooving and parting tools
min bore
“min-bore”, followed by a colon, 
followed by a decimal number
•	
min-bore:.522
flutes
A number, followed by “FL” or 
“FLUTE”
•	
4FL
•	
12FL
•	
2flute
No flutes specified is the 
same as 2 flutes


---

## PDF Page 75

Chapter 5
75
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
To Generate Automatic Tool Descriptions
If you are using a Tormach tool, you can enter the part number to automatically generate tool 
descriptions in the Offsets Table window.
NOTE: If you’re unsure of the part number, you can search for the tool at tormach.com.
1.	 From the PathPilot interface, on the Offsets tab, in the Offsets Table window, select a blank 
line.
2.	 Type the part number for the tool.
Example: “33133”
A full description for a right-handed profiling tool (PN 33133) displays.
3.	 You must use the Tool Touch window to zero the tool for the correct X offset and Y offset.
5.7.3  Tool Offset Information Backup
Make a periodic backup of the tool offset information and machine settings to store externally 
should the controller get replaced or need to be restored to factory settings.
Create a tool offset information backup on a PathPilot controller as follows:
1.	 Insert a USB drive into any open USB slot on the controller.
2.	 On the Main screen, type ADMIN SETTINGS BACKUP in the MDI line.
3.	 In the dialog box, navigate to a location to store the backup .zip file on the USB drive and 
rename if desired; click Save.
NOTE: Keep this file somewhere safe and easily accessible.
Figure 5.19


---

## PDF Page 76

Chapter 5
76
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
Restore tool offset information backup on a PathPilot controller as follows:
1.	 Transfer the tool offset information and machine settings backup to a USB drive; insert into 
any open USB slot on the controller.
2.	 On the Main screen, type ADMIN SETTINGS RESTORE in the MDI line.
3.	 In the dialog box, navigate to the backup .zip file on the USB drive; click Open. PathPilot exits, 
restores from the backup file, and then restarts PathPilot.
5.8  Conversational Screens
5.8.1  Overview
The included G-code generators are intended for making G-code programs for simple parts or parts 
made up from a collection of simple features (for more information, refer to chapter 4, Intro to 
PathPilot). For complex parts or parts with complex shapes, using CAD/CAM may be better.
Conversational screens are divided into two sections: parameters common to most operations on 
the left and operation-specific parameters (including part geometry) on the right. DRO fields which 
are not used for a particular generator do not allow editing. Each generator produces G-code with 
common elements:
•	 Comments describing the file and parameter values entered
•	 G-code for setting up lathe
•	 G30 to move to tool change position
•	 Tool change with wear offsets applied
•	 Coolant and spindle on
•	 Move to workpiece starting point, usually starting somewhere on the tool clearance zone
•	 Roughing as needed
•	 Finishing as needed
•	 Coolant and spindle off
•	 G30 to park tool
•	 M30 to end program
During roughing and finishing, the tool clearance zone is often used as a landmark for path direction 
and feed/rapid rate changes, so the tool clearance value may need to be adjusted to compromise 
between different requirements, such as clearance from both the stock OD and an uneven face. At 
the end of finishing, the tool is usually returned to the workpiece starting position. 
When appending to an existing file, the M30 in the existing file is removed to allow the appended 
M30 to end the program. All other G-code for each appended generator remains untouched. The 
tool always goes to tool change position between routines, even if there is no tool change required.


---

## PDF Page 77

Chapter 5
77
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
Tool Table and Work Offset (User Coordinates)
The Work Offset DRO field is used to select the work offset coordinate system to be used when the 
program runs.
NOTE: The tool table and work offset need to be set up before the DRO fields are filled in; the data is the 
same when the G-code program is loaded and run.
Adjusted DOCs
Usually a value for a depth of cut (DOC) is set by considering the tool configuration and workpiece 
material properties. If this value is used directly across a cutting range, such as for roughing from a 
stock diameter to a rough OD, it is likely there is a fraction of the depth of cut left for the last cut. 
Where appropriate, an adjusted value is determined by dividing the range by the entered DOC to 
find the integer number of cuts that fit within the range. One is added to make sure at least one 
cut is made, and also that the adjusted value is always less than the requested depth. For example:
(Xend – Xstart) / DOC = n, the positive integer from n = N, DOCadj = (Xend – Xstart) / (N + 1)
Some tool and material conditions may need a minimum depth of cut, but because the adjusted 
value is less than the requested value, it is wise to check the adjusted value in the resulting G-code file 
to make sure it meets a minimum if needed. If running the lathe in the conversational programming 
mode, enter operational parameters for the specific part geometry on the appropriate tab: OD Turn, 
ID Turn, Profile, Face, Chamfer, Groove/Part, Drill/Tap, or Thread.
NOTE: If the ENTER key is pressed, the cursor moves to the next text field on the screen. Pressing ENTER 
rather than clicking through the fields using a mouse reduces the likelihood of inadvertently typing an 
invalid value and confirms the value is established within that field.
After entering the appropriate operational and part-parameters, 
click Post to File or Append to File, depending on workflow.
Post to File
1.	 The Post to File window opens on the screen.
2.	 If the appropriate file name is not displayed in the Name: 
field, click the correct file; verify it is displayed.
3.	 Click Save or Cancel. If Save is selected, a message 
confirming the save is displayed.
Common DRO Fields
Common DRO fields – parameters that are most likely to be 
reused by operations to make a part – are on the left side of the 
programming screen (see Figure 5.20). Some operations do not 
use a common DRO field, in which case it is grayed out.
Figure 5.20


---

## PDF Page 78

Chapter 5
78
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
Title: This is an optional entry to allow the operator to prefix the automatic date stamp that appears 
when Post to File is used.
Work Offset: Sets which coordinate system to use. The available offsets are: 
•	 Machine coordinates (G53)
•	 Six work offsets (G54-G59)
Roughing SFM or MPM: This sets the constant surface speed value (not RPM) for the roughing 
section of the G-code. Usually set to optimize the rate of material removal. When this is grayed out, 
a DRO field should be available to set an RPM rather than the constant surface speed input.
Finishing SFM or MPM: This sets the value (or constant surface speed), not RPM for the finishing 
section of the G-code. This is usually set to optimize surface finish. When this is grayed out, a DRO 
field should be available to set RPM.
Max. Spindle RPM: Constant surface speed varies spindle speed dependent on the tool’s X position. 
As X decreases the RPM increases, but at some point the RPM needs to be limited by the maximum 
RPM that the workpiece, work holder, spindle, or tooling can handle. The operator needs to consider 
which feature has the lowest RPM limit and enter this value. When this is grayed out, a DRO field 
should be available to set a simple spindle RPM.
Roughing IN/Rev. or MM/Rev: This sets the value for feed or units per spindle revolution for the 
roughing section of the G-code. When this is grayed out, a DRO field should be available to set a 
simple feed per minute.
Finishing IN/Rev. or MM/Rev: This sets the value for feed or units per spindle revolution for the 
finishing section of the G-code. When this is grayed out, a DRO field should be available to set a 
simple feed per minute.


---

## PDF Page 79

Chapter 5
79
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.8.2  Using Feeds and Speeds Suggestions
You can use PathPilot to automatically calculate feeds and speeds: from the Conversational tab, in the 
Conversational DROs group, select a material, a sub-type, and a tool. Then, PathPilot automatically 
loads all machining-related DROs (see Figure 5.21).
1.	 From the PathPilot interface, on the Conversational tab, locate the Material dropdowns in the 
Conversational DROs group. 
2.	 From the Material dropdown, select your material. 
Examples:
•	 Aluminum
•	 Plastic
3.	 If required, from the Sub-type dropdown, select the material sub-type.
Examples: 
•	 -any-
•	 6061
4.	 In the Tool DRO, type the assigned tool number.
5.	 Click Refresh (to the right of the Sub-type dropdown).
The following machining-related DRO fields are calculated:
•	 Roughing SFM
•	 Finishing SFM
•	 Max Spindle RPM
•	 Roughing (in/rev)
Figure 5.21


---

## PDF Page 80

Chapter 5
80
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
•	 Finishing (in/rev)
•	 Finishing DOC
•	 Roughing DOC
•	 Peck (for drilling)
NOTE: After PathPilot calculates values for the machining-related DROs, the background turns green (see 
Figure 5.21).
5.8.2.1  Adjusting DRO Values
After selecting the material and tool, you 
can adjust the values in the calculated 
DROs, like Feedrate or Stepover. Adjusting 
the value in one of these DROs does not 
change the value in the other machining-
related DROs.
Once you adjust the value in the DRO, the 
background switches from green back to 
white (see Figure 5.22). This helps you 
identify which DROs have suggested values 
(those with a green background), and 
which DROs have values you’ve supplied 
(white background).
5.8.2.2  Refreshing DRO Values
The suggested feeds and speeds are no 
longer valid if:
•	 You select different material or sub-
type values, or if you type a new 
value in to the Tool DRO.
The suggested feeds and speeds are 
made by taking into account all of 
these values. Changing any value 
requires you to refresh.
•	 You select a different Conversational 
tab.
The suggested feeds and speeds are made by taking into account the current, specific 
conversational operation — like Face, or OD Turn. Changing your conversational operation 
requires you to refresh.
When the feeds and speeds are no longer valid, the Refresh button turns green, and the machining-
related DRO backgrounds switch from green to white (see Figure 5.23).
Figure 5.22 
Figure 5.23


---

## PDF Page 81

Chapter 5
81
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.8.3  OD Turn Tab
OD Turn creates G-code to rough and 
finish three features; an outside diameter, 
a fillet (corner radius), and an adjacent 
face (see Figure 5.24 and Figure 5.25). 
The face is always on the headstock end 
of the diameter being cut. Cutter Radius 
Compensation (CRC) is not used, so the 
fillet does not follow a true radius for 
cutters having a finite tip radius.
Roughing starts at the Initial X diameter 
and incrementally cuts diameters at an adjusted depth of cut (for more information, refer to section 
Adjusted DOCs earlier in this chapter) using Roughing DOC until the start of the finish diameter 
[FINAL X + ( 2 * FINISH DOC)]. Finishing is done in one pass at the value entered into the Finish DOC 
DRO field.
The finish pass is started at the +Z end of the OD and feeds to the middle of the fillet. The tool is then 
retracted to the stock diameter, and the face finish pass is cut from the stock diameter to the end of 
the fillet. Since there is only one finish pass, the Finish DOC is not adjusted. The tool is cutting both 
an OD and face, so valid tools are limited to orientation 2 for a rear tool, and type 3 for a front tool.
The Tool DRO field is a command value (meaning that it sets the location of a new feature) that sets 
the tool number for a tool change at the start of the program.
Figure 5.25 
Figure 5.24


---

## PDF Page 82

Chapter 5
82
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
The Initial X DRO field is a reference value (the value should describe an existing feature), usually set 
to the stock diameter. It is also used with Tool Clearance DRO field to locate some of the transitions 
between Rapid and Feed rate. If the values in the Initial X DRO field and the Final X DRO field are 
both positive, the tool will work on the positive X side of the spindle center, the side away from the 
operator. If they are both negative, the tool works the negative side of the spindle which is the side 
closer to the operator. A positive and negative value for each produces an error.
The Final X DRO field is a command value. It sets the location of the new outside diameter.
The Z Start DRO field is a reference value for the stock face location. It is used with Tool Clearance 
DRO field to set the transition between Rapid and Feed rate on some Z moves. The value entered in 
the Z Start DRO field should be larger than the value in the Z End DRO field.
The Z End DRO field is a command value that sets the face location. The value entered in the Z End 
DRO field should be smaller than the value in the Z Start DRO field.
The Fillet Radius DRO field is a command value that sets the radius between the new outside 
diameter and the face. The fillet calculation does not use CRC, so the middle of the fillet is not on 
the true radius for a tool with a tip radius. Valid values are greater than or equal to zero. A value less 
than the tip radius is allowed and drives the cutter to the corner. A value larger than the Z range (Z 
START - Z END) or the X range [(INITIAL X - FINAL X) / 2] are valid, but will have a fillet start or end 
outside of the stock perimeter and not end at the X and Z locations entered.
The Tool Clearance DRO field is a reference value that should match the desired space beyond the 
stock outside diameter and face needed for rapid movements to clear the workpiece. Since there 
is one value used for X and Z moves, the value should be set to the greater of the two clearances. 
Larger values may be safer; smaller values may save time once the operator is familiar with how the 
program works. A typical move would be a rapid move from G28 to the start of the first cut, which 
would be at Z START + TOOL CLEARANCE, then the rate would change to a cutting feed rate. The 
Tool Clearance DRO field is also sometimes used as a location for retracting the tool while making 
cutting passes.
The Roughing DOC DRO field is a command value that sets the depth of material being cut. This 
depth of cut is adjusted (for further information, refer to the Adjusted DOCs section) to get the value 
used in the G-code. Valid values are positive.
The Finish DOC DRO field is a command value used to leave enough material after roughing to do 
one finish pass. Valid values are positive.


---

## PDF Page 83

Chapter 5
83
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.8.4  ID Turn Tab
ID Turn creates G-code that cuts an internal diameter. There are two varieties available: Basic 
and Extended. The ID Turn tab initially opens with a screen for Basic (see Figure 5.26). A button is 
provided to switch to Extended (see Figure 5.27).
Both versions use CSS for spindle speed control, and FPR for feed control. The fillet does not use CRC 
so the fillet will not follow a true radius for tools with a tip radius.
The Basic version has one operation which roughs and finishes from an initial pilot hole diameter 
to a final internal diameter without cutting a face at the bottom of hole. This should be used with 
through holes or holes that don’t need a finished face. Each pass ends at Z End.
Roughing starts at the pilot hole diameter, X Start, and incrementally cuts diameters with an adjusted 
DOC (for further information, refer to section Adjusted DOCs earlier in this chapter) until the start of 
the finish diameter (X END - ( 2 * FINISH DOC)). Finishing is done in one pass. 
The Extended version has three operations: ID roughing, face roughing, and an ID, fillet, and face 
finish pass. The extended ID roughing passes stop at the bottom of the pilot hole in order to prevent 
engaging too much of the tool cutting edge. Once the rough ID is cut to the pilot hole bottom, 
rough facing is started. Depending on the tool geometry, ID roughing and face roughing may need 
different DOCs so a separate facing DOC DRO field is provided.
For each face pass, the tool tip cuts to the hole center + Tool Clearance which requires a rough hole 
diameter (which was cut in the first operation) that is a little more than twice the tool’s X width. 
Caution is needed to prevent hitting the back of the tool holder on the side of the hole.
Figure 5.26


---

## PDF Page 84

Chapter 5
84
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
Valid tool orientations are limited to type 2 for a front tool, and type 3 for a rear tool. Other orientation 
types will create an error alarm on selecting the Post To File button, so it is best to have the proper 
tool information set in the tool table before starting. The tool path also changes by 90° on the same 
side of the tool, so a form tool (narrow tip angle) and separate roughing DOCs are needed.
The Tool DRO field is a command value that sets the tool number for a tool change at start of the 
program. 
The Initial X DRO field  is a reference value (meaning that the value should describe an existing 
feature). This value should be set to the pilot hole diameter which needs to be large enough to clear 
the tool holder X width.
The Final X DRO field is a command value (meaning that it will set the location of a new feature). It 
sets the location of the new finished inside diameter. For Extended, this value needs to be greater 
than twice the tool holder’s X width plus tool clearance.
The Z Start DRO field is a reference value for the location of the stock face. It is used with the Tool 
Clearance DRO field to set the transition between rapid and feed rates on some moves.
The Z End DRO field Is a command value for the finished face location.
The Fillet Radius DRO field Is a command value that sets the radius between the finished inside 
diameter and face. The fillet calculation does not use CRC, so the middle of the fillet may not be on 
the true radius for a tool with a tip radius. Valid values are 0 or positive. Values larger than the Z 
range (Z START - Z END) or the X range ((INITIAL X - FINAL X) / 2) are valid, but will have a fillet start 
or end short of the finish locations, which may not be practical.
Figure 5.27


---

## PDF Page 85

Chapter 5
85
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
The Tool Clearance DRO field is a reference value that should match the desired space needed for 
tool retracting and transitions between rapid and cutting feed rate. Since there is one value used for 
X and Z moves, the value should be set to the greater of the two clearances. Larger values may be 
safer, but brings the back of the tool holder closer to the ID wall on the end of facing cuts; smaller 
values may save time once the operator is familiar with how the program works.
The ID Rough DOC DRO field is a command value that sets the depth of material being cut. This depth 
of cut is adjusted (for further information, refer to section Adjusted DOCs earlier in this chapter) to 
get the value used in the G-code. Valid values are positive.
The Face Rough DOC DRO field is a command value that sets the depth of material being cut. This 
depth of cut is adjusted (for further information, refer to section Adjusted DOCs earlier in this 
chapter) to get the value used in the G-code. Valid values are positive. Note that the reverse or back 
cutting direction is sensitive to DOC. Form tools with a small angle between cutting edges allows for 
a larger DOC.
The Finish DOC DRO field is a command value that is used to leave enough material after roughing 
to do one finish pass on the ID, fillet, and face. Valid values are positive.
5.8.5  Profile Tab
Use the Profile tab to create G-code that roughs and finishes an arbitrary internal or external 
profile on a part (see Figure 5.30). The profile is created from a list of points that describes the 
part geometry. A profile can have both forward (away from the headstock) and rear (toward the 
headstock) facing features, and can also start behind the highest Z plane. 
Figure 5.28 
ID Turn (Basic) Tool Path
Figure 5.29 
ID Turn (Extended) Tool Path


---

## PDF Page 86

Chapter 5
86
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
On the Profile tab, you can also specify things like:
•	 Tool geometry
•	 Feeds and speeds
•	 Finish depth
•	 Number of finish passes
•	 Roughing depth of cut (roughing DOC)
The Profile tab initially opens with a screen for External. To switch to Internal, click the External/
Internal button (see Figure 5.30).
To create an internal profile, you must make sure that:
•	 The Tool Clear Dia X DRO field has a value of smaller diameter than first X value on the Profile 
Point table. 
•	 An internal tool is indicated in the Tool DRO field.
Figure 5.30


---

## PDF Page 87

Chapter 5
87
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
Describe the Stock
Use the DRO fields on the right side of the Notebook to describe the stock for which you want to 
create a profile (see Figure 5.31).
1.	 From the PathPilot interface, on the Profile tab, in the Stock Dia DRO field, type the diameter 
of the stock. Then, press ENTER on the keyboard.
2.	 In the Tool Clearance Z DRO field, type the Z value for the tool clearance on the Z-axis. Then, 
press ENTER on the keyboard.
Tool Clearance Z is the Z plane the tool goes from rapid to feed. 
3.	 In the Stock Z DRO field, type the starting Z value for the profile. Then, press ENTER on the 
keyboard.
4.	 In the Tool Clear Dia X DRO field, type the X value – as a diameter – for the tool clearance on 
the X-axis.
•	 For external profiles: You must make sure the value typed in the Tool Clear Dia X DRO field 
is a larger diameter than the value typed in the Stock Dia DRO field.
•	 For internal profiles: You must make sure the value typed in the Tool Clear Dia X DRO field 
is a smaller diameter than the first diameter (specified in the Profile Point table).
Figure 5.31


---

## PDF Page 88

Chapter 5
88
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
Identify the Profile Points
Use the Profile Point table to describe the point-to-point values of a profile – from a larger Z value 
to a smaller Z value.
1.	 From the PathPilot interface, on the Profile tab, click the Profile Point tab.
2.	 In the Profile Point table, type the X and Z values for the profile. X values are in diameters 
terms. The X field is expressed in terms of X+ cutting (X- G-code will properly be generated if 
the tool selection calls for it).
NOTE: If the value is unchanged from the previous row in the Profile Point table, PathPilot assumes the 
value is repeated. If you are using the same value, you can leave the cell empty.
To Create an Arc with the Profile Point Table
•	 In the Profile Point table, type a Radius value to X and Z end points (see Figure 5.32).
•	 A positive radius value creates a center point above and/or to the right of the start point.
•	 A negative radius value creates a center point below and/or to the left of the start point.
To Preview the Profile
•	 As you work through the Profile Point table, PathPilot displays a graphical representation of 
the profile on your part.
Click on any segment in the graphic to highlight the corresponding row in the Profile Point table. 
Figure 5.32


---

## PDF Page 89

Chapter 5
89
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
Alternately, you may click on any row in the Profile Point table to highlight the corresponding 
segment in the graphic.
Point the mouse toward any area in the graphic and use the scroll wheel to zoom in and out to 
enlarge small features. To quit zooming, either press ESC on the keyboard or click on another 
line in the Profile Point table.
Identify the Tool
1.	 In the Tool DRO field, type the number of the tool to use for creating the profile.
Tool Geometry displays a graphical representation of the selected tool.
2.	 On the graphical representation of the profile on your part, make sure there are no red line 
segments. If there are red line segments, you must specify a new tool or edit the fields in the 
Profile Point table.
A red line segment indicates that the geometry of the selected tool cannot cut the programmed 
angle without gouging the part profile – typically, when feature entry or exit angles are too steep 
for the tool geometry to clear (see Figure 5.32).
For example, in Figure 5.32, the back angle of the tool will not clear the entry to the arc feature. 
Identify the Roughing and Finishing
Use the Roughing / Finishing tab to describe the required roughing and finishing for the part’s 
profile.
NOTE: You can use only roughing or only finishing. It is an error if all three of the following DRO fields are 
empty: Finishing Passes, Roughing DOC, and Finishing DOC.
Figure 5.33 
Figure 5.34


---

## PDF Page 90

Chapter 5
90
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
1.	 From the PathPilot interface, on the Profile tab, click the Roughing / Finishing tab.
PathPilot updates the graphical representation of the profile depending on which DRO field 
you select:
•	 Click the Roughing DOC DRO field to display a roughing graphic (see Figure 5.33).
•	 Click the Finishing DOC DRO field or the Finish Passes DRO field to display a finishing 
graphic (see Figure 5.34).
2.	 In the Roughing DOC DRO field, type the depth of cut for each roughing pass. Then, press 
ENTER on the keyboard.
NOTE: The default value is 0.02 inches.
3.	 In the Finishing DOC DRO field, type the depth of cut for each finishing pass. Then, press 
ENTER on the keyboard.
NOTE: The default value is 0.003 inches.
4.	 In the Finishing Passes DRO field, type the number – from 0-2 – of finishing passes. Then, 
press ENTER on the keyboard.
NOTE: The default value is 2 (passes).
A finishing pass is a continuous pass from the start of the profile (away from the headstock) to the 
end of the profile (toward the headstock).
Describe the Tool Geometry
Use the Tool Geometry tab to describe the front and rear profiling angles (see Figure 5.35). Because 
there are many tool and tool holder geometries, the Tool Geometry tab allows you to properly 
describe each tool and avoid part gouging.
To describe the tool geometry, you must first determine the cutting direction: either X+ or X-, based 
on the tool orientation and an external or internal profile. 
For example, if you are cutting an external profile on a part and have a tool orientation of 2, PathPilot 
creates X+ G-code.
Use the following table to determine the cutting direction:
Cutting Direction
Internal or External
Tool Orientation
X+
(typically, while using a turret)
External
1, 2, 6
Internal
3, 4, 8
X-
(typically, while using a quick-change 
tool post)
External
3, 4, 8
Internal
1, 2, 6


---

## PDF Page 91

Chapter 5
91
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
To Describe X+ Cutting Tool Geometries
•	 In the Front Angle DRO field and the Back Angle DRO field, type the value of the tool geometry 
expressed as a negative angle in the counterclockwise direction from 0˚.
NOTE: The Tool Geometry graphic preview (to the right of the Tool DRO field) updates as angles are 
changed.
To Describe X- Cutting Tool Geometries
•	 In the Front Angle DRO field and the Back Angle DRO field, type the value of the tool geometry 
expressed as a negative angle in the clockwise direction from 0˚.
5.8.6  Face Tab
Face creates G-code that cuts a face with tool paths from the stock OD to the spindle center, or to an 
ID. Passes progress in Z toward the headstock (see Figure 5.36). For cutting with a rear tool both the 
value in the Initial X DRO field and the value in the Final X DRO field need to be positive. For front 
tool cutting, both need to be negative. CSS is used for spindle speed control. FPR controls feedrate. 
Rough facing starts at Z Start and incrementally cuts at the DOC until the start of the finish face pass 
(Z END + FINISH DOC). 
The start of each pass is at the Initial X diameter + Tool Clearance and moves in the minus X direction 
until the Final X diameter – Tool Clearance is reached. If the value in the Final X DRO field is zero, the 
end of the pass will go beyond the spindle center. Finishing is done in one pass at the value entered 
into the Finish DOC DRO field.
Figure 5.35


---

## PDF Page 92

Chapter 5
92
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
The Tool DRO field is a command value (meaning that it will set the location of a new feature) that 
sets the tool number for a tool change at the start of the program.
The Initial X DRO field is a reference value 
(meaning that the value should describe 
an existing feature). This value is usually 
set to the stock diameter. It is also used 
with Tool Clearance to locate some of the 
transitions between rapid and feed rate. If 
the values in the Initial X DRO field and the 
Final X DRO field are both positive, the 
tool works on the positive X side of spindle 
center, the side away from operator. If 
they are both negative, the tool will work 
the negative side of the spindle which is 
the side closer to the operator. A positive 
and negative value for each will produce 
an error.
Figure 5.36 
Figure 5.37 
Facing Tool Path


---

## PDF Page 93

Chapter 5
93
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
The Final X DRO field is a command value. It sets the location of the face inside diameter. The tool 
path will go beyond this diameter by the tool clearance. For tools with a tip radius, the control point 
and face contact point are not the same, so the tool clearance value, if greater than the tool tip 
radius, can be used to extend the path to the contact point.
The Z Start DRO field is a reference value for the location of the stock face. Roughing passes start 
here. It is also used with Tool Clearance to set the transition between rapid and feed rates on some 
moves.
The Z End DRO field Is a command value for the finished face location. 
The Tool Clearance DRO field is a reference value that should match the desired space needed for 
tool retracting and transitions between rapid and cutting feed rate. Since there is one value used for 
X and Z moves, the value should be set to the greater of the two clearances. Larger values may be 
safer, but brings the back of the tool holder closer to the ID wall on the end of facing cuts. Smaller 
values may save time once the operator is  familiar with how well the program works.
The Roughing DOC DRO field is a command value that sets the depth of material being cut. This 
depth of cut is adjusted (for more information, refer to section Adjusted DOCs earlier in this chapter) 
to get the value used in the G-code. Valid values are positive.
The Finish DOC DRO field is a command value that is used to leave enough material after roughing 
to do one finish pass. Valid values are positive.
5.8.7  Chamfer and Radius Tab
Chamfer/radius creates G-code for cutting a chamfer, taper or corner radius (see Figure 5.38). Cutter 
radius compensation (G41, G42) is used, so tools with a nose radius can cut to the correct profile. 
Radii are limited to 90° arcs that start on the outside diameter (Initial X, Z End). Depending on the 
sense of the X and Z DRO field entries, the chamfer or radius feature may face away from or toward 
the spindle, or use back or front mounted tooling. 
Spindle speed is controlled by CSS. Tool feed is controlled by FPR. Roughing starts at the corner of 
X and Z Start in adjusted DOC increments perpendicular to the chamfer angle or incremental arcs 
for radius (for more information, refer to section Adjusted DOCs earlier in this chapter). The last 
roughing pass leaves enough material for the finish pass; finishing is done with a single pass.
Passes start and end on the perimeter of the tool clearance space, which is set by adding the tool 
clearance DRO value to the stock OD, X, and the face location, Z Start. Extra caution is advised when 
using chamfer angles less than 30° or greater than 60°, due to the extra travel involved in traversing 
the tool clearance space at an angle. The path may take the tool into the chuck, spindle or adjacent 
workpiece features.
The Tool DRO field is a command value (meaning that it sets the value of a new feature) which sets 
the tool number for a tool change at the start of the program.
The X DRO field is a reference value (meaning that the value should describe an existing feature).


---

## PDF Page 94

Chapter 5
94
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
This value is usually set to the stock diameter. It is also used with Tool Clearance to locate some of 
the transitions between rapid and feed rates. If Initial X is positive, the tool works on the positive X 
side of the spindle center, the side away from the operator. If the value in the Initial X DRO field is 
negative, the tool will work the negative side of the spindle which is the side closer to the operator.
The Z Start DRO field is a reference value for the stock face or the end of the chamfer or radius. It is 
used with Tool Clearance to set the transition between rapid and feed rates on some Z moves.
The Z End DRO field is a command value that sets the location of the start of the chamfer or radius. 
The Z width of a chamfer or the radius of a corner radius equals Z END – Z START.
The Chamfer Angle DRO field is a command value that sets the angle between the workpiece center 
line and the chamfer. Valid values are between 0° and 90° (non-inclusive).
The Tool Clearance DRO field is a reference value that should match the desired space beyond 
the stock outside diameter and face that is needed for some movements to clear the workpiece. 
Since there is one value used for X and Z moves, the value should be set to the greater of the two 
clearances. Larger values may be safer; smaller values may save time once the operator is familiar 
with how well the program works. A typical move would be a rapid move from G28 to the start 
of the first cut, which might be at X + TOOL CLEARANCE, Z START + TOOL CLEARANCE, then the 
rate would change to a roughing feed rate. Tool Clearance is also sometimes used as a location for 
retracting the tool while making cutting passes.
Figure 5.38


---

## PDF Page 95

Chapter 5
95
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
The Roughing DOC DRO field is a command value that sets the depth of cut during roughing. The 
depth of cut is adjusted (for more information, refer to section Adjusted DOCs earlier in this chapter). 
In this case the roughing range is the distance from the workpiece corner (the intersection of the 
face and OD) and the closest point on the chamfer or radius minus the finish DOC. Valid values are 
positive. 
The Finish DOC DRO field is a command value that is used to leave enough material after roughing 
to do one finish pass. Valid values are positive.
Figure 5.39 
Figure 5.40 
Chamfer on Bar End Tool Path
Figure 5.41 
Radius on Bar End Tool Path


---

## PDF Page 96

Chapter 5
96
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.8.8  Groove and Part Tab
Groove/Part creates G-code to rough and finish a groove, or to part a workpiece from stock. Initially, 
the Groove screen is presented (see Figure 5.42), but can be switched to Part with the Groove/Part 
button (see Figure 5.43). Grooving paths are based on Z START and Z END values. If the value in the 
Z Start DRO field is greater than the value in the Z End DRO field, the tool’s control point is set to 
the +Z side of the tool. If the value in the Z Start DRO field is less than the value in the Z End DRO 
field, the control point is set to the -Z side of the tool (see Figure 5.44). Groove roughing is done 
with plunge cuts in the X direction. Each plunge is incremented in the Z direction from Z START – or 
+ FINISH DOC to Z END – or + (TOOL WIDTH + FINISH DOC).
Groove finishing is done with a plunge cut down the Z END side. When the tool reaches the bottom, 
the tool is moved in the Z direction toward the center of the groove, then retracts. Next, the tool is 
plunged on the Z START side of the groove, then again is moved in Z toward the groove center and 
retracted. This requires a grooving tool, which can side cut. Part does one plunge cut at Z START. The 
tool’s control point is on the +Z side of the tool. The plunge cannot be set to go beyond the spindle 
center (X = 0).
Even though a grooving/parting tool may be considered to have two tips, valid tool orientation is 
limited to:
•	 Groove on the – side of Z START, Back Tool = Type 1
•	 Groove on the + side of Z START, Back Tool = Type 2
•	 Groove on the + side of Z START, Front Tool = Type 3
Figure 5.42


---

## PDF Page 97

Chapter 5
97
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
•	 Groove on the – side of Z START, Front Tool = Type 4
•	 Part on the – side of Z START, Back Tool = Type 1
•	 Part on the – side of Z START, Front Tool = Type 4
CSS is used for spindle speed control. FPR is used for feed rate control. CRC is not used.
If the value in the Z Start DRO field is less than the value in the 
Z End DRO field, the control point is set to the –Z side of the tool 
(see Figure 5.44).
The Tool DRO field is a command value (sets the location of a 
new feature) that sets the tool number for a tool change at the 
start of the program.
The Initial X DRO field is a reference value (the value should 
describe an existing feature). This value is usually set to the 
stock diameter. It is also used with Tool Clearance to locate 
some of the transitions between rapid and feed rates. If the 
value in the  Initial X DRO field and the value in the Final X DRO 
field are both positive, the tool will work on the positive X side 
of the spindle center, which is the side away from the operator. If they are both negative, the tool 
will work the negative side of the spindle which is the side closer to the operator. A positive and 
negative value for each produces an error. 
Figure 5.43 
Figure 5.44


---

## PDF Page 98

Chapter 5
98
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
The Final X DRO field is a command value for setting the diameter of the new groove bottom, or the 
end of parting. If the value in the Initial X DRO field and the value in the Final X DRO field are both 
positive, the tool will work on the positive X side of the spindle center, which is the side away from 
the operator. If they are both negative, the tool will work the negative side of the spindle which is 
the side closer to the operator. A positive and negative value for each produces an error.
The Z Start DRO field is a command value for setting the location of the groove start. For parting, Z 
Start sets the location of the +Z side of the slot.
The Z End DRO field is a command value for setting the location of the groove end. This value is not 
used with part.
The Tool Width DRO field is a reference value for setting the groove or parting tool width. This value 
is added or subtracted based on the tool’s control point (see Figure 5.44).
The Rough DOC DRO field is a command value that sets the depth of material being cut. In this case, 
for groove, it is the Z offset for each plunge cut. The depth of cut is adjusted. Valid values are positive 
and normally should be less than the full depth width of the tool tip (usually the distance between 
tip radii centers). This value is not used with part.
The Finish DOC DRO field is a command value for the amount 
of material roughing should leave for the finishing pass (groove 
sides and bottom). Valid values are positive. This value is not 
used with part.
The Tool Clearance DRO field is a reference value that should 
match the desired space beyond the stock outside diameter for 
rapid movements to clear the workpiece. Larger values may be 
safer; smaller values may save time once the operator is familiar 
with how well the program works. A typical move would be a 
rapid move from G28 to the start of the first cut, which would be 
at Z Start, Initial X + Tool Clearance, then the rate would change 
to a cutting feed rate. Tool Clearance is also sometimes used as 
a location for retracting the tool between cutting passes.
Figure 5.45 
Groove Tool Path


---

## PDF Page 99

Chapter 5
99
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.8.9  Drill and Tap Tab
The Drill/Tap tab creates G-code to drill a hole or use rigid tapping to thread a hole. Initially, the Drill 
screen is presented, but can be switched to the Tap screen using the Drill/Tap button (see Figure 
5.46 and Figure 5.47). Drill and tap use the tool at X = 0, so an RPM DRO is used instead of CSS from 
the common DRO section to the left. Otherwise, X = 0 would call for the maximum spindle speed.
For feed rate control, drill uses a millimeter or inch feed per revolution (G95) to feed from Z START 
+ TOOL CLEARANCE until Z END is reached, then rapids back to Z START + TOOL CLEARANCE. Drilling 
is limited to the -Z direction, toward the spindle. A Dwell DRO field is provided to allow a pause for 
the drill to stay at Z END long enough to cut a full revolution at the bottom of the hole, otherwise 
the drill is immediately retracted and may leave an irregular bottom. Pecking can be used to help 
clear chips before they bind in the hole during drilling. The peck motion retracts to Z START + TOOL 
CLEARANCE on each cycle. Due to motion control limits, the retract to Z START + TOOL CLEARANCE 
may not retract fully before starting the next drilling feed. Please verify the pecking retract motion 
meets requirements for your application.
Tap uses electronic gearing (G33.1, Rigid Tapping) to lock the Z-axis and spindle motion together 
for rigid tapping. Tapping starts with the tap at Z START + TOOL CLEARANCE. Z motion waits until 
the spindle encoder index is tripped, at this point, the gears are engaged and Z feeds at the rate set 
by the pitch or threads per unit (TPU) and spindle encoder count. The Z motion follows the spindle 
motion no matter what the spindle does. For tapping, the spindle is run forward until Z END is 
reached, the spindle is reversed, which causes it to slow to a stop, then reverse. During this time, 
the tap continues to follow the spindle motion and continues to make threads until the spindle 
reverses. These extra threads needs to be considered when setting the Z End DRO field. The reverse 
motion continues until reaching Z START + TOOL CLEARANCE where the gearing is disengaged.
Figure 5.46


---

## PDF Page 100

Chapter 5
100
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
The Tool DRO field is a command value that sets the tool number for a tool change at start of the 
program. 
The Z Start DRO field is a reference value for the stock face location. It is used with Tool Clearance 
to set the transition between rapid and the feed for drilling or tapping. An error is produced if the 
value in the Z Start DRO field is not larger than the value in the Z End DRO field.
The Z End DRO field is a command value. 
For drill, Z End DRO field sets the location where the drill feed stops and optionally dwells. The hole 
depth is from Z Start to the drill’s radial corner, but typically the drill tip is touched-off, so the Z 
distance between the tip and the drill’s radial corner must be considered when selecting a value for 
the Z End DRO field.
For tap, Z End is a command value that sets the Z location where the spindle rotation is reversed. 
The value in the Z End DRO field should be smaller than the value in the Z Start DRO field and should 
allow for extra threading while the spindle comes to a stop and reverses.
The Peck Depth DRO field is a command value that sets an incremental depth for retracting the drill 
to clear chips from the hole if needed. If drilling the hole does not need a peck, enter zero. To make 
each peck depth equal, the Peck Depth DRO field value is adjusted to fit an integer number of pecks 
within the hole depth. The Peck Depth DRO field also needs a direction, so should have a negative 
value.
The Tool Clearance DRO field is a reference value that should match the desired space needed for 
tool retracting and transitions between rapid and cutting feed rate.
Figure 5.47


---

## PDF Page 101

Chapter 5
101
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
The Spindle RPM DRO field is a command value for the RPM (G97) desired for drill or tap.
The Dwell at Bottom DRO field is a command value used with drill for the length of time that Z 
motion is paused in order for the drill to finish cutting the hole bottom before retracting. If dwell is 
needed, a value can be calculated by converting RPM to seconds/revolution or 60/RPM.
The Threads/Inch, mm DRO field is a command value that is used with tap to set the Z motion to 
spindle ratio to match the thread pitch needed. This DRO field is coupled with the Pitch DRO field, 
so entering a value in either DRO field calculates and enters a value in the other.
The Pitch DRO field is a command value that is used with tap to set the Z motion to spindle ratio to 
match the required thread pitch. This DRO field is coupled with the Threads/Inch, mm DRO field, so 
entering a value in either DRO field calculates and enters a value in the other.
5.8.10  Thread Tab
Thread can be used to create G-code to single point an external or internal thread on an existing 
OD (Figure 5.48) or ID (Figure 5.49). Initially, the screen is in external mode, but can be switched to 
internal mode with the External/Internal button.
Thread is based on the G76 Threading Cycle. This canned cycle contains a lead-in, cut, lead out, and 
return path for each threading pass. Each cycle is incrementally offset in X and Z to account for a 30° 
software compound angle. The offset is calculated such that the each pass cuts the same amount 
of material by cross sectional area. The first pass has the most X displacement, and this decreases 
with each pass.
Figure 5.48


---

## PDF Page 102

Chapter 5
102
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
The Tool DRO field is a command value that sets the tool number for a tool change at the start of a 
program.
The X Start DRO field is a reference value (meaning that the value should describe an existing feature). 
This value is usually set to the existing major diameter for external threads or minor diameter for 
internal.
The X End DRO field is a command value. It sets the location of the new outside diameter.
The Z Start DRO field is a reference value for the stock face location. It is used with Tool Clearance to 
set the transition between rapid and feed rate on some Z moves. The value in the Z Start DRO field 
should be larger than the value in the Z End DRO field.
The Z End DRO field is a command value that sets the face location. The value in the Z End DRO field 
should be smaller than the value in the Z Start DRO field.
The Tool Clearance DRO field is a reference value that should match the desired space beyond the 
stock outside diameter that is needed for rapid movements to clear the workpiece. In thread, this 
sets the starting X diameter of the thread cycle return path. Larger values may be safer; smaller 
values may save time once the operator is familiar with how well the program works.
Figure 5.49


---

## PDF Page 103

Chapter 5
103
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
The Lead Length DRO field is a reference value that sets the required length during the start of the 
cutting path that allows the motion to stabilize before cutting material. The start of a cutting pass 
waits for the spindle encoder index to trip; when it does, the Z motion tries to instantly match the 
spindle speed, but actually needs time to accelerate and match the spindle encoder count. This 
value needs to be a compromise between spindle speed, thread pitch, and workpiece clearance.
The Thread Table drop-down menu contains values for some common threads. The threads listed 
follow the current unit setting (inch or millimeter). Once a selection is made, the data from the 
selected thread is copied to the appropriate DRO fields. This table is stored in user-editable text files 
found in the thread_data subdirectory of the G-code folder on the controller’s hard drive; to edit 
(e.g., to add to or modify the defaults), highlight the file and click Edit G-code. For more information 
on files stored on the controller’s hard drive, refer to File Tab section earlier in this chapter.
NOTE: The values entered in these tables assume a full form thread tool. If using a fine point threading 
tool to cut coarse threads, the root diameter must be modified to account for the smaller tool nose radius 
of the fine point threading tool.
The Spindle RPM DRO field is a command value that sets the spindle RPM as opposed to the CSS 
DRO in the common DRO section.
The Depth of Cut DRO field is a command value that sets the depth of material being cut. Each pass 
is incremented based on a calculation of the area of the material being removed. This allows for a 
constant tool load for each pass. Valid values are positive. 
The Threads/In, mm DRO field is a command value that sets the number of threads per inch or 
millimeter. This DRO field is coupled to the Pitch DRO field, so whichever value is handy – threads 
per unit or pitch – may be entered.
The Pitch DRO field is a command value that sets the distance per thread. This DRO field is coupled 
to the Threads/In, mm DRO field, so whichever value is handy – threads per unit or pitch – may be 
entered.
The Number of Passes DRO field is coupled to the Depth of Cut DRO field. A value may be entered 
into either DRO field and its compliment updates to reflect the new value. Often, a depth of cut is 
entered and the number of passes presents a number that might seem excessive. Either DRO field 
can be adjusted to reach a compromise between the depth of cut and the number of passes.


---

## PDF Page 104

Chapter 5
104
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
5.9  Status Tab
The Status tab displays diagnostic machine information, error messages, and the Software Updates 
button, used to update PathPilot as new releases become available (see Figure 5.50).
Error Messages
The left hand side of this screen consists 
of a scrolled text box that displays error 
messages should any errors occur. For 
instance, attempting to enter an MDI 
command that moves the axes before 
referencing the machine generates an 
error message (see Figure 5.51).
There are three levels of error messages:
1.	 Minor errors: these errors will cause the Status tab to change color to yellow type on a red 
background. Typing an invalid G-code into the MDI field is an example of a minor error.
2.	 Major errors: these errors change the color of the Status tab, but they also cause PathPilot 
to switch to the Status page, instantly making the operator aware of the error. Errors in 
conversational code generation are examples of major errors.
3.	 E-stop errors: these errors stop all machine motion, G-code program execution, and causes the 
Reset button to flash. The machine must be brought out of reset condition before continuing 
if this type of error occurs. An example of an E-stop error is a failed turret tool change – if the 
turret is jammed or otherwise fails to change a tool, the machine puts itself into an E-stop 
condition.
Figure 5.50 
Diagnostic 
LEDs
Figure 5.51


---

## PDF Page 105

Chapter 5
105
UM10225_15L_Slant-PRO_Manual_0626A
PathPilot Interface
If the operator encounters a minor error 
message (the Status tab turns red), they 
can hover over the Status tab with the 
mouse to a tool tip of the error message 
(see Figure 5.52).
Alternately, pressing the F1 key  temporarily changes from the current screen to the Status screen, 
allowing the operator to quickly scan the error message. Releasing the F1 key returns the interface 
to the previous screen. A history of error messages is displayed in the scrolled text box with the 
most recent error messages displayed at the top. If desired, the operator may clear the message 
history using the Clear Error Messages button. The entire history is also saved in a log file, found in 
the G-code/logfiles directory.
Diagnostic LEDs and Counts
On the upper right-hand side of the Status screen are diagnostic LEDs and a DRO displaying encoder 
counts (see Figure 5.50) used for troubleshooting purposes that should not be needed in normal 
operation. For more information, refer to chapter 7, Maintenance, and chapter 8, Troubleshooting.
Tool Orientation Errors
If the operator enters information on a Conversational page that doesn’t match the information 
in the tool table – for instance entering positive diameters but selecting a front tool post mounted 
tool – the Status screen displays error message in the text box as well as images of the expected tool 
orientation and the actual tool orientation (see Figure 5.53).
NOTE: The current PathPilot version is listed in the lower right corner of the screen (see Figure 5.53). 
Figure 5.52 
Figure 5.53 
Error 
Message
PathPilot 
Version


---

## PDF Page 106

Chapter 6
106
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.  Programming
This section defines the language (G-codes, etc.) that is understood and interpreted by the 
PathPilot® operating system, and is is intended for reference purposes. If you want to learn about 
the principles of the control language so you can write programs by hand from first principles, 
consult an introductory textbook on G-code programming.
6.1  Definitions
The following terms are defined as follows:
PathPilot Controller
This is the Tormach motion controller.
PathPilot Operating System
This is the PathPilot controller operating system.
Linear Axes
The X- and Z-axes are at right angles to each other. The Z-axis 
lies along the centerline of the spindle; distance values increase 
moving away from the spindle towards the right-hand side of the 
machine. The X-axis distance values increase as the tool moves up 
and away from the operator. The tool cutting position (controlled 
point) is represented by coordinates on these axes.
Controlled Point 
The controlled point is the point whose position and rate of 
motion are controlled to make cuts. In practice, a tool is not a 
point – the sharper the point of a tool, the weaker it is – so a tip 
radius is always part of the tip profile. Figure 6.1 shows a real tool. 
If this tool is in a front tool post, it can turn to a diameter moving 
toward the headstock (negative-Z) and face toward the centerline 
(positive-X).
Many standard shapes of tools are available; PathPilot does not 
need to know the exact shape of the tool, but does need to know 
where it is used to cut and how to interpret the controlled point.
There are nine possible orientations for the cutting point,  identified 
by numbers shown in Figure 6.2; orientation code 3 is illustrated. 
If this tool is put in the turret, or a rear position on the gang plate, 
it is orientation 2.
Controlled 
Point
Figure 6.1  
Figure 6.2


---

## PDF Page 107

Chapter 6
107
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Tools with orientations 1, 2, 3 and 4 all turn to 
size and face. Their controlled points are the 
intersection of tangents to the cutting tip radius so 
the radius has no effect on the diameter or length 
of the part made.
If, however, the cut is angled, then the radius 
means it does not cut the expected part but one 
a little larger than required. This is represented by 
the gap between a colored part and the tip of the 
middle tool in Figure 6.3.
To machine a part corresponding to the angled tool 
path defined in the G-code, it is necessary to use 
tool-tip radius compensation (i.e., G41 or G42).
Orientations 6 and 8 turn diameters to size and 
are often used for making profiles. It is difficult to 
accurately estimate their controlled point in the 
Z-direction.
Orientations 5 and 7 turn on the face of stock and are unusual. It is difficult to accurately estimate 
their controlled point in the X-direction without a test cut.
Orientation 9 is used when tool-tip compensation is applied in all moves.
Some orientations seem unusual at first glance. For example, a parting or grooving tool in the front 
tool post has orientation 4. This is because the program defines the part to the right of the tool. The 
size of the waste left in the chuck is unimportant.
Coordinated Linear Motion
To drive a tool along a specified path, a machining system must often coordinate the motion of both. 
We use the term coordinated linear motion to describe the situation in which each axis moves at 
constant speed and both axes move from their starting positions to their end positions at the same 
time. As we only have the X- and Z-axes, this produces motion in a straight line – hence the word 
linear in the term. In actual motions, it is often not possible to maintain constant speed because 
acceleration or deceleration is required at the beginning and/or end of the motion. It is feasible, 
however, to control the axes so that, at all times, each axis has completed the same fraction of its 
required motion as the other axes. This moves the tool along the same path and we also call this 
kind of motion coordinated linear motion.
Coordinated linear motion can be performed either at the prevailing feed rate or at rapid traverse 
rate. If physical limits on axis speed make the desired rate unobtainable, the axes are slowed to 
maintain the desired path.
Figure 6.3


---

## PDF Page 108

Chapter 6
108
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Feed Rate
The rate at which the controlled point or the axes move is nominally a steady rate which may be set 
by the operator. In the interpreter, the interpretation of the feed rate is as follows unless inverse 
time feed rate (G93) mode is being used: the feed rate means the length in units per minute or units 
per spindle revolution along the programmed linear path.
Arc Motion
The axes can be controlled to move in a circular arc in the plane of the axes. While this is occurring, as 
in coordinated linear motion, the motions can be coordinated so that acceleration and deceleration 
do not affect the path. The feed rate during arc motion is as described in Feed Rate above.
Coolant
Although G-code provides for separate flood and mist coolant, either M07 or M08 turn on the 15L 
Slant-PRO coolant pump and M09 turns it off.
Dwell
A machining system may be commanded to dwell (i.e., keep the axes unmoving) for a specific 
amount of time. The most common use of dwell is to break and clear chips or for a spindle to get up 
to speed. The units in which you specify dwell are seconds; a decimal value can be used to get less 
than one second.
Units
Units used for distances along the X- and Z-axes may be measured in millimeters or inches. Units for 
all other quantities involved in machine control cannot be changed. Different quantities use different 
specific units. Spindle speed is measured in revolutions per minute. Feed rates are expressed in 
current length units per minute.
IMPORTANT! Be sure to carefully double check tool and work offsets when changing units (G20, G21) 
within a part program.
Current Position
The controlled point is always at some location called the current position and PathPilot always 
knows where that is. The numbers representing the current position are adjusted in the absence of 
any axis motion if any of several events take place:
•	 Length units are changed
•	 Tool length offsets are changed
•	 Work offsets are changed
NOTE: These events do not move the tool, instead they change its displayed position in the axis DROs.


---

## PDF Page 109

Chapter 6
109
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Work Offsets
Work offsets allow you to jog the machine to an arbitrary location (i.e., the end of a workpiece) and 
call that location zero. Up to nine different work offsets can be saved in the machine memory, but 
only one can be active at any given time. The default (used in this example) is G54. More information 
on work offsets can be found in the part programming reference section of this manual.
Selected Plane
There is always a selected plane, which for a lathe is the XZ-plane of the machining system.
Tool Table
Zero or one tool is assigned to each slot in the tool table. The table defines the offset of the controlled 
point of the tool from the work offset coordinate system’s origin, the wear corrections to be made 
to this tool offset, the tool tip radius, and the orientation of the tool tip.
Wear Offsets
Wear offsets are values used to fine tune a part program to compensate for things like tool wear, 
spring back, etc. Wear offsets are applied with the T command as well, by specifying the desired 
wear offset register with the last two digits of a four-digit T command. For example, T02 applies the 
geometry offsets for tool 2, whereas T0202 applies both geometry offsets and wear offsets. Note 
that either command causes the turret to change position to pocket 2 if the machine is equipped 
with a turret. There is no M6 tool change command for lathes like there is for CNC milling machines.
Path Control Modes 
The lathe may be put into any one of three path control modes:
1.	 Exact stop mode – the machine stops briefly at the end of each programmed move.
2.	 Exact path mode – the machine follows the programmed path as exactly as possible, slowing 
or stopping if necessary at sharp corners of the path.
3.	 Continuous mode with optional tolerance – sharp corners of the path may be rounded slightly 
so that the feed rate may be kept up (but by no more than the tolerance, if specified).
For further information, refer to sections Set Path Control Mode – G61 and G61.1 and Set Blended 
Path Control Mode – G64 later in this chapter.
Feed and Speed Override Controls
PathPilot has commands which enable (M48) or disable (M49) the feed and speed override slider 
controls. It is useful to be able to override these for some machining operations. Default settings in 
the program are set and the operator should not change them.


---

## PDF Page 110

Chapter 6
110
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Block Delete Control
PathPilot does not implement the optional omission of blocks of code that are prefixed with the 
forward slash symbol (/).
Optional Program Stop Control
The optional program stop control (M01 BREAK) works as follows. If this button is on and an input 
line contains an M01-code, program execution is stopped at the end on the commands on that line 
until the Cycle Start button is pushed.
6.2  Tool File
PathPilot maintains a tool file for each of the 28 tools which can be used. Each data line of the table 
contains the data for one tool. This allows the definition of the tool length (X- and Z-axis), tool wear 
compensation values, tool tip radius, and tip orientation. The data is displayed on the Offsets Table 
tab of the Offsets screen of main notebook.
6.3  Part-programs Language
IMPORTANT! Do not use a word processor to create or edit G-code files. A word processor leaves unseen 
codes that cause problems and may prevent a G-code file from working. Use a text editor like Gedit or 
Notepad++ to create or edit the files.
6.3.1  Overview
The program language is based on lines of code. Each line, also called a block, may include commands 
to the machining system to do several different things. Lines of code may be collected in a file to 
make a program.
A typical line of code consists of an optional line number at the beginning followed by one or more 
words. A word consists of a letter followed by a number (or strictly something that evaluates to a 
number). A word may either give a command or provide an argument to a command. For example, 
G01 X3 is a valid line of code with two words. G01 is a command meaning move in a straight line at 
the programmed feed rate, and X3 provides an argument value (the value of X should be 3 at the 
end of the move).
Most commands start with either G (general) or M (miscellaneous). The words for these commands 
are called, respectively, G-codes and M-codes.
The language has two commands (M02 or M30), execution of either of which ends a program. A 
program may end before the end of a file. Lines of a file that occur after the end of a program are 
not to be executed in the normal flow, so generally they’re parts of subroutines.


---

## PDF Page 111

Chapter 6
111
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.3.2  Parameters 
NOTE: There are significant differences between controls in the way parameters work. Do not assume 
that code from another control works in the same way with PathPilot. Tormach advises against writing 
parametric G-code as this is difficult to debug and very difficult for another operator to understand. 
Modern CAM virtually eliminates the need for it.
PathPilot maintains an array of 10,320 numerical parameters. Many of them have specific uses. 
The parameters that are associated with fixtures are persistent over time. Other parameters are 
undefined when PathPilot is loaded. The parameters are preserved when the interpreter is reset. 
Parameters 1-1000 can be used by the code of part-programs.
6.3.3  Coordinate Systems
PathPilot has an absolute coordinate system and 9 work offset (fixture) systems.
You can set the offsets of tools by using G10 L1 P~ X~ Z~. The P word defines the tool number to be 
set.
You can set the offsets of the fixture systems using G10 L2 P~ X~ Y~ Z~ A~ B~ C~. The P word defines 
the fixture to be set. The X, Y, Z, etc. words are the coordinates for the origin of the axes in terms of 
the absolute coordinate system. 
You can select one of the first seven work offsets by using G54, G55, G56, G57, G58 or G59. Any of 
the 254 work offsets can be selected by G59 P~ (e.g., G59 P23 would select fixture 23). The absolute 
coordinate system can be selected by G59 P0. 
You can offset the current coordinate system using G92 or G92.3. This offset is then applied on top 
of work offset coordinate systems. This offset may be cancelled with G92.1 or G92.2. 
You can make straight moves in the absolute machine coordinate system by using G53 with either 
G0 or G01.
6.3.4  Formatting G-code Lines (Block) 
A permissible line of input code consists of the following, in order, with the restriction that there is 
a maximum (currently 256) to the number of characters allowed on a line.
•	 Block delete character, which is a forward slash (/)
•	 Optional line number
•	 Any number of words, parameter settings, and comments
•	 End of line marker (carriage return or line feed or both)
Any input not explicitly allowed is illegal and causes the interpreter to either signal an error or to 
ignore the line.
Currently, programs are limited to 999,999 lines of code.


---

## PDF Page 112

Chapter 6
112
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Spaces and tabs are allowed anywhere on a line of code and do not change the meaning of the line, 
except inside comments. This makes some strange-looking input legal. For example, the line g0x +0. 
12 34y 7 is equivalent to g0 x+0.1234 y7 
Blank lines are allowed in the input, but are ignored.
Input is case insensitive, except in comments, therefore any letter outside a comment may be in 
upper or lower case without changing the meaning of a line.
6.3.5  Line Number
A line number is the letter N followed by an integer (with no sign) between 0 and 99,999,999 written 
without commas. Line numbers may be repeated or used out of order, although normal practice is 
to avoid such usage. A line number is not required to be used (and this omission is common), but it 
must be in the proper place if it is used.
6.3.6  Subroutine Labels
A subroutine label is the letter O followed by an integer (with no sign) between 0 and 99,999 written 
with no more than five digits (000009 is not permitted, for example). Subroutine labels may be used 
in any order but must be unique in a program. Nothing else except a comment should appear on the 
same line as a subroutine label. 
NOTE: Line numbers are not permitted with an O word in the current release of PathPilot.
6.3.7  Word
A word is a letter other than N or O followed by a real value. Words may begin with any of the 
letters detailed in Word Initial Letters table later in this section. The table includes N and O for 
completeness, even though, as defined above, line numbers are not words. Several letters (I, J, K, 
L, P and R) may have different meanings in different contexts. A real value is some collection of 
characters that can be processed to come up with a number. A real value may be an explicit number 
(such as 341 or -0.8807), a parameter value, an expression or a unary operation value. Definitions 
of these follow (for more information, refer to Word Initial Letters table). Processing characters to 
come up with a number is called evaluating. An explicit number evaluates to itself.
6.3.8  Number
The following rules are used for (explicit) numbers. In these rules, a digit is a single character 
between 0 and 9.
•	 A number consists of:
	–
(1) an optional plus or minus sign, followed by 
	–
(2) zero to many digits, followed, possibly, by 
	–
(3) one decimal point, followed by 
	–
(4) zero to many digits, provided that there is at least one digit somewhere in the number.


---

## PDF Page 113

Chapter 6
113
UM10225_15L_Slant-PRO_Manual_0626A
Programming
•	 There are two kinds of numbers: integers and decimals. An integer does not have a decimal 
point; a decimal does.
•	 Numbers may have any number of digits, subject to the limitation on line length. Only about 
17 significant figures are retained, however (enough for all known applications).
•	 A non-zero number with no sign as the first character is assumed to be positive.
Notice that initial (before the decimal point and the first non-zero digit) and trailing (after the 
decimal point and the last non-zero digit) zeros are allowed but not required. A number written 
with initial or trailing zeros has the same value when it is read as if the extra zeros were not there.
Numbers used for specific purposes by PathPilot are often restricted to some finite set of values 
or some to some range of values. In many uses, decimal numbers must be close to integers; this 
includes the values of indexes (for parameters and carousel slot numbers, for example), M-codes, 
and G-codes multiplied by 10.
A decimal number which is supposed to be close to an integer is considered close enough if it is 
within 0.0001 of an integer.
6.3.9  Comments and Messages
Comments can be added to lines of G-code to help clear up the intention of the programmer. 
Comments can be embedded in a line using parentheses ( ) or for the remainder of a line using a 
semicolon. The semicolon is not treated as the start of a comment when enclosed in parentheses.
Comments may appear between words, but not between words and their corresponding parameter.
Example:
S100(set speed)F200(feed) is OK while
S(speed)100F(feed) is not.
If there are several comments on a line, only the last comment is interpreted according to these 
rules. Hence, a normal comment following an active comment in effect disables the active comment. 
Example:
(foo) (msg, Start machining cycle1) shows the message, however
msg, Start machining cycle1)(foo) does not.
A comment introduced by a semicolon is, by definition, the last comment on that line and is always 
interpreted for active comment syntax.


---

## PDF Page 114

Chapter 6
114
UM10225_15L_Slant-PRO_Manual_0626A
Programming
If the comment occurs on a line with M00 or M01 and contains a file name with a .jpg or .png 
extension, PathPilot displays the image in the tool path window when it reaches a programmed 
M00 or M01 break.
1.	 Move an image file with a .jpg or .png extension to your PathPilot controller in one of the 
following locations:
•	 In the same folder as the G-code program file
•	 In a folder called images within the G-code program file’s folder
•	 In a folder called images within the home directory
2.	 Program an M00 or M01 break.
3.	 Using parentheses ( ), embed a comment within the line of G-code.
4.	 Type the file name of the image within the comment.
NOTE: Ensure the file name has either a .jpg or .png extension.
Example
M01 (photo_of_my_setup.jpg)
(MSG,) – displays message if MSG appears after the left parenthesis and before any other printing 
characters. Variants of MSG, which include white space and lower case characters, are allowed. The 
rest of the characters before the right parenthesis are considered to be a message. Messages are 
displayed on the Status screen.
6.3.10  Item Repeats
A line may have any number of G words, but two G words from the same modal group can not 
appear on the same line.
A line may have zero to four M words. Two M words from the same modal group may not appear on 
the same line. For all other legal letters, a line may have only one word beginning with that letter.
If a parameter setting of the same parameter is repeated on a line, #3=15 #3=6, for example, only 
the last setting takes effect. It is illogical but not illegal to set the same parameter twice on the same 
line.
If more than one comment appears on a line, only the last one is used. Each of the other comments 
is read and its format is checked, but ignored thereafter. It is expected that putting more than one 
comment on a line is very rare.


---

## PDF Page 115

Chapter 6
115
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Word Initial Letters
Letter
Meaning
A
A-axis of machine
B
B-axis of machine
C
C-axis of machine
D
Tool radius compensation number
F
Feed rate
G
General function (see Modal Groups table)
H
Tool length offset index
I
X-axis offset for arcs 
X offset in G87 canned cycle
J
Y-axis offset for arcs 
Y offset in G87 canned cycle
K
Z-axis offset for arcs 
Z offset in G87 canned cycle
L
Number of repetitions in canned cycles/subroutines
key used with G10
M
Miscellaneous function (see Modal Groups table)
N
Line number
O
Subroutine label number
P
Dwell time in canned cycles 
dwell time with G04 
key used with G10
tapping depth in M871 – M874
Q
Feed increment in G83 canned cycle 
repetitions of subroutine call
R
Arc radius
canned cycle retract level
S
Spindle speed
T
tool selection
U
Synonymous with A
V
Synonymous with B
W
Synonymous with C
X
X-axis of machine
Y
Y-axis of machine
Z
Z-axis of machine


---

## PDF Page 116

Chapter 6
116
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.3.11  Item Order
The three types of items whose order may vary on a line (as given at the beginning of this section) 
are word, parameter setting, and comment. Imagine that these three types of items are divided into 
three groups by type. The first group (the words) may be reordered in any way without changing the 
meaning of the line.
If the second group (the parameter settings) is reordered, there is no change in the meaning of 
the line unless the same parameter is set more than once. In this case, only the last setting of the 
parameter takes effect. For example, after the line #3=15 #3=6 has been interpreted, the value 
of parameter 3 is 6. If the order is reversed to #3=6 #3=15 and the line is interpreted, the value 
of parameter 3 is 15. If the third group (the comments) contains more than one comment and is 
reordered, only the last comment is used.
If each group is kept in order or reordered without changing the meaning of the line, then the three 
groups may be interleaved in any way without changing the meaning of the line. 
Example: 
The line g40 g01 #3=15 (so there!) #4=-7.0 has five items and means exactly the 
same thing in any of the 120 possible orders – such as #4=-7.0 g01 #3=15 g40 (so there!) – for the 
five items.
6.3.12  Commands and Machine Modes 
PathPilot has many commands, called modal commands, that cause a machining system to change 
from one mode to another. The mode stays active until some other command changes it implicitly 
or explicitly. For example, if coolant is turned on, it stays on until it is explicitly turned off.
The G-codes for motion are also modal. If a G01 (straight move) command is given on one line, 
for example, it is executed again on the next line if one or more axis words is available on the line, 
unless an explicit command is given on that next line using the axis words or canceling motion. In 
contrast, non-modal codes have effect only on the lines on which they occur. For example, G04 
(dwell) is non-modal.
6.4  Modal Groups
Modal commands are arranged in sets called modal groups, and only one member of a modal group 
may be in force at any given time. In general, a modal group contains commands for which it is 
logically impossible for two members to be in effect at the same time (i.e., measure in inches vs. 
measure in millimeters). A machining system may be in many modes at the same time, with one 
mode from each modal group being in effect. For several modal groups, when a machining system is 
ready to accept commands, one member of the group must be in effect. There are default settings 
for these modal groups. When the machining system is turned on or re-initialized, default values are 
automatically in effect.


---

## PDF Page 117

Chapter 6
117
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Group 1 is a group of G-codes for motion. One of these is always in effect, called the current motion 
mode. It is an error to put a G-code from group 1 and a G-code from group 0 on the same line if both 
of them use axis words. If an axis word-using G-code from group 1 is implicitly in effect on a line (by 
having been activated on an earlier line) and a group 0 G-code that uses axis words appears on the 
line, the activity of the group 1 G-code is suspended for that line. The axis word-using G-codes from 
group 0 are G10, G28, G30 and G92. PathPilot displays current mode on the screen.
Modal Groups
Modal Group
Group #
Specific Code
For G-codes
Group 1
= {G00, G01, G02, G03, G33, G38.x, G76, G80, G81, G82, G84, G85, G86, G87, 
G88, G89} motion
Group 2
= {G17, G18, G19, G17.1, G17.2, G17.3} plane selection
Group 3
= {G90, G91} distance mode
Group 4
= {G90.1, G91.1} arc IJK distance mode
Group 5
= {G93, G94} feed rate mode
Group 6
= {G20, G21} units
Group 7
= {G40, G41, G42, G41.1, G42.1} cutter radius compensation
Group 8
= {G43, G43.1, G49} tool length offset
Group 10
= {G98, G99} return mode in canned cycles
Group 12
= {G54, G55, G56, G57, G58, G59, G59.1, G59.2, G59.3} coordinate system 
selection
Group 13
= {G61, G61.1, G64} path control mode
Group 14
= {G96, G97} spindle speed mode
Group 15
= {G07, G08} lathe diameter mode
For M-codes
Group 4
= {M0, M1, M2, M30, M60} stopping
Group 7
= {M3, M4, M5} spindle turning
Group 8
= {M7, M8, M9} coolant (special case: M7 and M8 may be active at same 
time)
Group 9
= {M48, M49} enable/disable feed and speed override controls
Group 10
= {user defined M100 to M199}
For non-modal 
G-codes
Group 0
= {G4, G10, G28, G30, G53, G92, G92.1, G92.2, G92.3}
6.5  G-codes
The supported G-codes are shown and described in more detail in this section. The descriptions 
contain command examples set in Courier type font.


---

## PDF Page 118

Chapter 6
118
UM10225_15L_Slant-PRO_Manual_0626A
Programming
G-code Table
G-code
Summary
G00
Rapid positioning
G01
Linear interpolation
G02
Clockwise circular interpolation
G03
Counterclockwise circular interpolation
G04
Dwell
G07
Diameter mode 
G10 L1
Set Tool Table Entry
G10 L10
Set Tool Table – calculated - Workpiece
G10L11
Set Tool Table – calculated - Fixture
G10 L2
Set work offset origin
G10 L20
Set work offset origin - calculated
G17, G18, G19
Plane selection
G20/G21
Inch/millimeter unit
G28
Return home
G28.1
Reference axes
G30
Return home
G33
Spindle sync. motion (e.g. threading)
G33.1
Rigid tapping
G40
Cancel cutter radius compensation
G41/G42
Start cutter radius compensation left/right
G41.1, G42.1
Dynamic cutter compensation
G43
Apply tool length offset – not used on lathe
G49
Cancel tool length offset
G53
Move in absolute machine coordinate system
G54
Use fixture offset 1
G55
Use fixture offset 2
G56-58
Use fixture offset 3, 4, 5
G59
Use fixture offset 6 / use general fixture number
G61/G61.1
Path control mode
G64
Path control with optional tolerance
G76
Multi-pass threading cycle
G80
Cancel motion mode (including canned cycles)
G90, G90.1
Absolute distance mode
G91, G91.1
Incremental distance mode
G92
Offset coordinates and set parameters
G92.x
Cancel G92 etc.
(continued on next page...)


---

## PDF Page 119

Chapter 6
119
UM10225_15L_Slant-PRO_Manual_0626A
Programming
G-code Table
G-code
Summary
G93, G94, G95
Feed modes
G96, G97
CSS, RPM modes
G98
Initial level return / R-point level after canned cycles
In the command examples, the tilde symbol (~) stands for a real value. A real value may be:
•	 An explicit number (4.4, for example)
•	 An expression ([2+2.4], for example)
•	 A parameter value (#88, for example)
•	 A unary function value (acos[0], for example)
In most cases, if axis words (X~ or Z~) are given, they specify a destination point. Axis numbers 
relate to the currently active coordinate system, unless explicitly described as being in the absolute 
coordinate system. Where axis words are optional, any omitted axes will have their current value. 
Any items in the command examples not explicitly described as optional are required. It is an error 
if a required item is omitted.
In the examples, the values following letters are often given as explicit numbers. Unless stated 
otherwise, the explicit numbers can be real values. For example, G10 L2 could equally well be written 
G[2*5] L[1+1]. If the value of parameter 100 were 2, G10 L#100 would also mean the same. Using 
real values which are not explicit numbers as shown in examples is rarely useful. If L~ is written in 
a example, the “~” is often referred to as the L number. Similarly the “~” in H~ may be called the H 
number, and so on for any other letter.
6.5.1  Rapid Linear Motion – G00
For rapid linear motion, program G00 X~ Z~ where the axis words are optional, except that at least 
one must be used. The G00 is optional if the current motion mode is G00. This produces coordinated 
linear motion to the destination point at the current traverse rate (or slower if the machine does not 
go that fast). It is expected that cutting won’t take place when a G00 command is executing. It is an 
error if all axis words are omitted.
If cutter radius compensation is active, the motion differs from the above; for more information, 
refer to section G41, G42 – Cutter Compensation later in this chapter. If G53 is programmed on the 
same line, the motion also differs; for more information, refer to section G90 – Absolute Coordinates 
later in this chapter. Depending on where the tool is located, there are two basic rules to follow for 
safety: if the Z value represents a cutting move in the positive direction (i.e., out of a hole), the X-axis 
should be moved first. If the Z value represents a move in the positive direction, the X-axis should 
be executed last.
(...continued)


---

## PDF Page 120

Chapter 6
120
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.5.2  Linear Motion at Feed Rate – G01
For linear motion at feed rate (for cutting or not), program G01 X~ Z~, where the axis words are 
optional, except that at least one must be used. The G01 is optional if the current motion mode is 
G01. This produces coordinated linear motion to the destination point at the current feed rate (or 
slower if the machine will not go that fast). It is an error if all axis words are omitted. 
If cutter radius compensation is active, the motion differs from the above; for more information, 
refer to section G41, G42 – Cutter Compensation later in this chapter. If G53 is programmed on the 
same line, the motion also differs; for more information, refer to section G90 – Absolute Coordinates 
later in this chapter.
6.5.3  Arc at Feed Rate – G02, G03 
A circular or helical arc is specified using either G02 (clockwise arc) or G03 (counterclockwise arc). 
The axis of the circle is normal to the XZ plane of the machine coordinate system. The direction is 
viewing from above the lathe.
If cutter radius compensation is active, the motion differs from the above; for more information, 
refer to section G41, G42 – Cutter Compensation later in this chapter. Two formats are allowed for 
specifying an arc. We call these the center format and the radius format. In both formats, the G02 
or G03 is optional if it is the current motion mode.
6.5.3.1  Radius Format Arc
In the radius format, the coordinates of the end point of the arc in the selected plane are specified 
along with the radius of the arc. Program G02 X~ Z~ R~ (or use G03 instead of G02). The axis words 
are optional except that at least one must be used. The R number is the radius. A positive radius 
indicates that the arc turns through 180° or less, while a negative radius indicates a turn of 180° to 
359.999°. The arc center is absolute or relative as set by G90.1 or G91.1 respectively. 
It is an error if:
•	 Both of the axis words are omitted
•	 No R word is given
•	 The end point of the arc is the same as the current point
6.5.3.2  Center Format Arc
In the center format, the coordinates of the end point of the arc in the selected plane are specified 
along with the center of the arc. Program G02 X~ Z~ I~ K~ (or use G03 instead of G02). The axis words 
and arc center words are optional except that at least one of each type must be used.  I and K specify 
the distance offset of the center of the arc from the start point of the arc in X and Z, respectively.
It is an error if:
•	 Both of the axis words are omitted
•	 Both I and K are omitted
•	 The end point of the arc is the same as the current point


---

## PDF Page 121

Chapter 6
121
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.5.4  Dwell – G04 
For a dwell, program G04 P~. This keeps the axes unmoving for the period of time in seconds 
specified by the P number.
It is an error if:
•	 The P number is negative.
G04 P4.2 (To wait 4.2 seconds)
6.5.5  Lathe Diameter Mode – G07
The standard operating mode where X1.2 turns a part with diameter 2.4.
6.5.6  Set Offsets – G10
Offsets are generally set up using the graphical PathPilot interface, but can be set programmatically.
6.5.7  Set Tool Table – G10 L1
To define an entry in the tool table, program G10 L1 P~ X~ Y~ R~ I~ J~ Q~
•	 P – tool number
•	 R – radius of tool
•	 I – front angle (lathe)
•	 J – back angle (lathe)
•	 Q – orientation (lathe)
G10 L1 sets the tool table for the P tool number to the values of the words.
A valid G10 L1 rewrites and reloads the tool table.
Example: 
G10 L1 P2 R0.015 Q3 (setting tool 2 radius to 0.015 and orientation to 3)
It is an error if:
•	 Cutter Compensation is on
•	 The P number is unspecified
•	 The P number is not a valid tool number from the tool table
•	 The P number is 0
For more information on cutter orientation used by the Q word, see Figure 6.2.


---

## PDF Page 122

Chapter 6
122
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.5.8  Set Coordinate System – G10 L2
•	 To define the origin of a work offset coordinate system, program G10 L2 P- 
•	 P = number of coordinate system to use (G54 = 1, G59.3 = 9) 
Important Concepts:
•	 G10 L2 PN does not change from the current coordinate system to the one specified by P; you 
have to use G54-59.3 to select a coordinate system.
•	 If a G92 origin offset was in effect before G10 L2, it continues to be in effect afterwards.
•	 The coordinate system whose origin is set by a G10 command may be active or inactive at the 
time the G10 is executed. If it is currently active, the new coordinates take effect immediately.
It is an error if:
•	 The P number does not evaluate to an integer in the range 0 to 9
•	 An axis other than X or Z is programmed
6.5.9  Set Tool Table – G10 L10
G10 L10 P- X~ Z~ R~ I~ J~ Q~
•	 P – tool number
•	 R – radius of tool
•	 I – front angle
•	 J – back angle 
•	 Q – orientation 
G10 L10 changes the tool table entry for tool P so that if the tool offset is reloaded, with the machine 
in its current position and with the current G5x and G92 offsets active, the current coordinates for 
the given axes will become the given values. The axes that are not specified in the G10 L10 command 
are not changed. This could be useful with a probe move as described in the G38 section. 
It is an error if:
•	 Cutter Compensation is on
•	 The P number is unspecified
•	 The P number is not a valid tool number from the tool table
•	 The P number is 0


---

## PDF Page 123

Chapter 6
123
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.5.10  Set Tool Table – G10 L11
G10 L11 P~ X~ Z~ R~ I~ J~ Q~
•	 P – tool number
•	 R – radius of tool
•	 I – front angle (lathe)
•	 J – back angle (lathe)
•	 Q – orientation (lathe)
G10 L11 is just like G10 L10, except that instead of setting the entry according to the current offsets, 
it is set so that the current coordinates would become the given value if the new tool offset is 
reloaded and the machine is placed in the G59.3 coordinate system without any G92 offset active. 
This allows the operator to set the G59.3 coordinate system according to a fixed point on the 
machine, and then use that fixture to measure tools without regard to other currently active offsets. 
It is an error if:
•	 Cutter Compensation is on
•	 The P number is unspecified
•	 The P number is not a valid tool number from the tool table
•	 The P number is 0
6.5.11  Set Coordinate System – G10 L20
G10 L20 P- X~ Z~
•	 P – coordinate system (0-9)
G10 L20 is similar to G10 L2 except that instead of setting the offset/entry to the given value, it is set 
to a calculated value that makes the current coordinates become the given value.
•	 The P number does not evaluate to an integer in the range 0 to 9
•	 An axis other than X or Z is programmed
6.5.12  Plane Selection – G17, G18, and G19 
The lathe should always be operated in G18 (XZ-plane). Do not use G17 or G19.
6.5.13  Length Units – G20 and G21 
Program G20 to use inches for length units and program G21 to use millimeters. It is usually a good 
idea to program either G20 or G21 near the beginning of a program before any motion occurs and 
not to use either one anywhere else in the program. It is the responsibility of the operator to be sure 
all numbers are appropriate for use with the current length units.


---

## PDF Page 124

Chapter 6
124
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.5.14  Return to Pre-defined Position – G28, G28.1 
G28 uses the values stored in parameters 5161 and 5163 as the X and Z final point to move to. The 
parameter values are absolute machine coordinates in the native machine units of inches.
•	 G28 makes a rapid traverse move from the current position to the absolute position of the 
values in parameters.
•	 G28 X~ Z~ makes a rapid traverse move to the position specified by axes including any offsets, 
then makes a rapid traverse move to the absolute position of the values in parameters 5161 
and/or 5163. Any axis not specified will not move.
•	 G28.1 stores the current absolute position into parameters 5161-5163.
It is an error if:
•	 Cutter Compensation is turned on
6.5.15  Return to Pre-defined Position – G30, G30.1 
G30 uses the values stored in parameters 5181 and 5183 as the X and Z final point to move to. The 
parameter values are absolute machine coordinates in the native machine units of inches.
A Tool-change request, Tnnww, also causes a G30 to be executed.
•	 G30 makes a rapid traverse move from the current position to the absolute position of the 
values in parameters.
•	 G30 X~ Z~ makes a rapid traverse move to the position specified by axes including any offsets, 
then makes a rapid traverse move to the absolute position of the values in parameters 5181 
and/or 5183. Any axis not specified won’t move.
•	 G30.1 stores the current absolute position into parameters 5181-5183.
It is an error if:
•	 Cutter Compensation is turned on
6.5.16  Spindle Synchronized Motion – G33
To make a cut – like a thread – where the spindle and the tool motion are synchronized, program 
G33 X~ Z~ K~
•	 K = distance per revolution
For spindle-synchronized motion in one direction, program G33 X~ Z~ K~ where K gives the distance 
moved in X and Z for each revolution of the spindle. For instance, if starting at Z=0, G33 Z-1 K.0625 
produces a 1 inch motion in Z over 16 revolutions of the spindle. This command might be part of a 
program to produce a 16TPI thread. 
Another example in metric, G33 Z-15 K1.5 produces a movement of 15 mm while the spindle rotates 
10 times for a thread of 1.5 mm pitch.


---

## PDF Page 125

Chapter 6
125
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Spindle-synchronized motion waits for the spindle index and spindle at speed signals from the 
machine so multiple passes line up. G33 moves end at the programmed endpoint. Thus, G33 could 
be used to cut tapered threads, a face scroll like in a 3-jaw chuck.
The axis words are optional, except that at least one must be used.
NOTE: K follows the drive line described by X~ Z~. K is not parallel to the Z axis if X endpoint is used, for 
example, when cutting tapered threads.
At the beginning of each G33 pass, PathPilot uses the spindle speed and the machine acceleration 
limits to calculate how long it takes Z to accelerate after the index pulse, and determines how many 
degrees the spindle rotates during that time. It then adds that angle to the index position and 
computes the Z position using the corrected spindle angle. That means that Z reaches the correct 
position just as it finishes accelerating to the proper speed, and can immediately begin cutting a 
good thread.
G33 Example:
G90 (absolute distance mode)
G0 X1 Z0.1 (rapid to position)
S100 M03 (start spindle turning)
G33 Z-2 K0.125 (move Z axis to -2 at a rate to equal 0.125 per revolution)
G0 X1.25 (rapid move tool away from work)
Z0.1 (rapid move to starting Z position)
M2 (end program)
For more information, refer to G90, G0, and M2 sections later in this chapter.
It is an error if:
•	 One axis word is not present
•	 The spindle is not turning when this command is executed
•	 The requested linear motion exceeds machine velocity limits due to the spindle speed


---

## PDF Page 126

Chapter 6
126
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.5.17  Rigid Tapping – G33.1
For rigid tapping, program G33.1 Z~ K~
•	 K – distance per revolution
For rigid tapping (spindle synchronized motion with return), program G33.1 Z~ K~ where K~ gives 
the distance moved for each revolution of the spindle. A rigid tapping move consists of the following 
sequence.
 CAUTION! Crash Hazard: If the X coordinate is specified non-zero or the current X coordinate is non-
zero (i.e., not tapping a hole in the axis of the workpiece), a crash is likely.
1.	 A move to the specified Z coordinate, synchronized with the spindle at the given ratio and 
starting with a spindle index pulse.
2.	 When reaching the endpoint, a command to reverse the spindle (i.e., from forward to reverse).
3.	 Continued synchronized motion beyond the specified end coordinate until the spindle actually 
stops and reverses.
4.	 Continued synchronized motion back to the original coordinate.
5.	 When reaching the original coordinate, a command to reverse the spindle a second time (i.e., 
from reverse to forward).
6.	 Continued synchronized motion beyond the original coordinate until the spindle actually 
stops and reverses.
7.	 An unsynchronized move back to the original coordinate.
Spindle-synchronized motions wait for spindle index, so multiple passes line up. G33.1 moves end 
at the original coordinate.
The Z-axis word must be used.
G33.1 Example:
G90 (set absolute mode)
G0 X0 Z0.100 (rapid move to starting position)
G33.1 Z-0.750 K0.05 (rigid tap a 20 TPI thread 0.750 deep)
M2 (end program)
See G90, G0, and M2 sections for more information.
It is an error if:
•	 The Z-axis word is omitted
•	 The spindle is not turning when this command is executed
•	 The requested linear motion exceeds machine velocity limits due to the spindle speed


---

## PDF Page 127

Chapter 6
127
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.5.18  Compensation Off – G40
G40 – Turn cutter compensation off. If tool compensation was on, the next move must be a linear 
move and longer than twice the tool tip radius. It is OK to turn compensation off when it is already off.
It is an error if:
•	 A G2/G3 arc move is programmed next after a G40
•	 The linear move after turning compensation off is less than twice the tool tip radius
6.5.19  Cutter Compensation – G41, G42
G41 D~ (left of programmed path)
G42 D~ (right of programmed path)
where D = tool number
The D word is optional; if there is no D word, the radius of the currently loaded tool is used. If no 
tool is loaded and no D word is given, a radius of 0 is used.
If supplied, the D word is the tool number to use.
To start cutter compensation to the left of the part profile, use G41. G41 starts cutter compensation 
to the left of the programmed line as viewed looking down on the lathe.
To start cutter compensation to the right of the part profile, use G42. G42 starts cutter compensation 
to the right of the programmed line as viewed looking down on the lathe.
The lead in move must be at least as long as the tool radius. The lead in move can be a rapid move. 
User M100-M199 commands are allowed when Cutter Compensation is on.
The behavior of the 15L Slant-PRO lathe when cutter compensation is on is described in the Cutter 
Compensation section.
It is an error if:
•	 The D number is not a valid tool number or 0
•	 Cutter Compensation is commanded to turn on when it is already on
6.5.20  Dynamic Cutter Compensation – G41.1, G42.1
G41.1 D~ L~ (left of programmed path)
G42.1 D~ L~ (right of programmed path)
where D = twice tip radius, and L = tool orientation
G41.1 and G42.1 function the same as G41 and G42 with the added scope of being able ignore the 
tool table and to program the tool diameter. The L word defaults to 0 if unspecified.


---

## PDF Page 128

Chapter 6
128
UM10225_15L_Slant-PRO_Manual_0626A
Programming
It is an error if:
•	 The L number is not in the range from 0 to 9 inclusive
•	 Cutter compensation is commanded to turn on when it is already on
6.5.21  Move in Absolute Coordinates – G53 
For linear motion to a point expressed in absolute coordinates, program G01 G53 X~ Z~ (or similarly 
with G0 instead of G1), where all the axis words are optional except that at least one must be 
used. The G0 or G01 is optional if it is in the current motion mode. G53 is not modal and must be 
programmed on each line on which it is intended to be active. This produces coordinated linear 
motion to the programmed point. If G01 is active, the speed of motion is the current feed rate (or 
slower if the machine will not go that fast). If G0 is active, the speed of motion is the current traverse 
rate (or slower if the machine will not go that fast).
It is an error if:
•	 G53 is used without G0 or G01 being active
•	 G53 is used while cutter radius compensation is on
For more information, refer to section Coordinate Systems earlier in this chapter.
6.5.22  Select Work Offset Coordinate System – G54 to G59 and G59 P~ 
G54 – Select coordinate system 1
G55 – Select coordinate system 2
G56 – Select coordinate system 3
G57 – Select coordinate system 4
G58 – Select coordinate system 5
G59 – Select coordinate system 6
G59.1 – Select coordinate system 7
G59.2 – Select coordinate system 8
G59.3 – Select coordinate system 9
It is an error if one of these G-codes is used while cutter radius compensation is on.
The X- and Z-axis work offset values are stored in parameters corresponding to the system in use 
(i.e., System 1 X=5221, Z=5223; System 2 X=5141, Z=5143; up to System 9 X= 5381, Z = 5383).
For more information, refer to section Coordinate Systems earlier in this chapter.


---

## PDF Page 129

Chapter 6
129
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.5.23  Set Path Control Mode – G61, G61.1 
Program G61 to put the machining system into exact path mode, or program G61.1 for exact stop 
mode which behaves in an identical way. The tool comes to a stop at corners that are sharp.
6.5.24  Set Blended Path Control Mode – G64 
Program G64 P~ Q~ to attempt to maintain the defined feed velocity.
The P~ word specifies a permitted deviation to round corners and so maintain speed. If P is omitted, 
then the speed is maintained however far from the programmed path the tool cuts.
If Q~ is not present, then it turns on the naive cam detector; when there are a series of linear XZ 
feed moves at the same feed rate that are less than Q~ away from being collinear, they are collapsed 
into a single linear move.
It is OK to program for the mode that is already active.
6.5.25  Threading Cycle – G76
To cut a thread in multiple passes, program 
G76 P~ Z~ I~ J~ R~ K~ Q~ H~ E~ L
•	 Drive Line – A line through the initial 
X position parallel to the Z
•	 P~ – The thread pitch in distance per 
revolution
•	 Z~ – The final position of threads; 
at the end of the cycle the tool is at 
this Z position
NOTE: As G07 Lathe Diameter Mode is always 
in force, the values for I, J and K are diameter 
measurements. 
•	 I~ – The thread peak offset from 
the drive line. Negative I values are external threads; positive I values are internal threads. 
Generally the material has been turned to this size before the G76 cycle.
•	 J~ – A positive value specifying the initial cut depth. The first threading cut is J beyond the 
thread peak position.
•	 K~ – A positive value specifying the full thread depth. The final threading cut is K beyond the 
thread peak position.
NOTE: Signs (either negative or positive) of I, J, and K values discussed in this section assume a rear tool 
post configuration. If using a front tool post configuration (either quick change or gang tooling), reverse 
the sign of I, J, and K.
Figure 6.4


---

## PDF Page 130

Chapter 6
130
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.5.25.1  Optional Settings
•	 R~ – The depth degression. R1.0 selects constant depth on successive threading passes. R2.0, 
which is usual, selects constant area. Values between 1.0 and 2.0 select decreasing depth 
but increasing area. Values above 2.0 select decreasing area. Beware that unnecessarily high 
degression values causes a large number of passes to be used (degression = a descent by 
stages or steps).
•	 Q~ – The compound slide angle is the angle (in degrees) describing to what extent successive 
passes should be offset along the drive line. This is used to cause one side of the tool to 
remove more material than the other. A positive Q value causes the leading edge of the tool 
to cut more heavily. Typical values for threads with a 60° angle are 29, 29.5 or 30.
•	 H~ – The number of spring passes. Spring passes are additional passes at full thread depth 
used to allow for any tool or workpiece deflection during the main cuts. If no additional passes 
are desired (for example on a work-hardening material), program H0.
•	 E~ – Specifies the distance along the drive line used for the entry/exit taper. The angle of the 
taper is so the last pass tapers to the thread crest over the distance specified with E.’ E0.2’ 
will give a taper for the first/last 0.2 length units along the thread. For a 45° entry/exit taper, 
program E the same as K.
•	 L~ – Specifies which ends of the thread get the taper. Program L0 for no taper (the default), 
L1 for entry taper, L2 for exit taper, or L3 for both entry and exit tapers. Entry tapers pause at 
the drive line to synchronize with the index pulse then feed in to the beginning of the taper. 
No entry taper and the tool will rapid to the cut depth, then synchronize and begin the cut.
The tool should be moved to the initial X and Z positions prior to issuing the G76. The X position is 
the drive line and the Z position is the start of the threads.
The tool pauses briefly for synchronization before each threading pass, so a relief groove is required at 
the entry unless the beginning of the thread is past the end of the material or if an entry taper is used.
Unless using an exit taper, the exit move (traverse to original X) is not synchronized to the spindle 
speed. With a slow spindle, the exit move might take only a small fraction of a revolution. If the 
spindle speed is increased after several passes are complete, subsequent exit moves requires a 
larger portion of a revolution, resulting in a very heavy cut during the exit move. This can be avoided 
by providing a relief groove at the exit, or by not changing the spindle speed while threading.
The final position of the tool is at the end of the drive line. A safe Z move is needed with an internal 
thread to remove the tool from the hole.
It is an error if:
•	 Other axis words, such as X-, are specified
•	 The R- degression value is less than 1.0
•	 All the required words are not specified
•	 P~, J~, K~ or H~ is negative


---

## PDF Page 131

Chapter 6
131
UM10225_15L_Slant-PRO_Manual_0626A
Programming
•	 E~ is greater than half the drive line length
The G76 canned cycle is based on the G33 Spindle Synchronized Motion. For more information, 
refer to section G33 – Spindle Synchronized Motion earlier in this chapter.
6.5.26  Tapping Cycle – G84
The G84 cycle is intended for tapping. This cycle rotates the spindle clockwise to tap a pre-drilled 
hole; when the bottom of the hole is reached, the spindle rotates in the reverse direction and exits 
the hole.
This cycle uses a P word, where P specifies the number of seconds to dwell. The P word is 
optional – if it is not included, PathPilot calculates a dwell for you (half of a second per 1000 RPM).
Program: G84 X~ Y~ Z~ R~ P~ F~
Word
Definition
X~
The position of the hole on the X-axis.
Y~
The position of the hole on the Y-axis.
Z~
The depth, tapping from the R-plane to Z-depth.
R~
The position of the retract plane (R-plane).
P~
The number of seconds to dwell.
F~
The federate.
•	 Spindle speed must be commanded before calling a G84 cycle.
•	 Feedrate override is ignored during a tapping cycle.
•	 Feedhold is ignored until the return operation is executed.
•	 After the tapping operation is completed, either a G98 or G99 command controls the return 
height. G99 returns the tool to the R-plane (see Figure 6.5); G98 returns the tool to the initial 
height (see Figure 6.6).
Figure 6.5 
R-plane
Z-depth
Spindle FWD
Spindle REV
G84 with G99
Figure 6.6 
R-plane
Z-depth
Spindle FWD
Spindle REV
G84 with G98


---

## PDF Page 132

Chapter 6
132
UM10225_15L_Slant-PRO_Manual_0626A
Programming
G84 Example:
N40 T51 G43 H51 M6
N45 S400 M3
N50 G54
N55 M8
N65 G0 X0.5 Y-0.75
N70 G43 Z0.6 H51
N80 G0 Z0.2
N85 S400
N90 G98 G84 X0.5 Y-0.75 Z-0.605 R0.2 F20.
N95 X1.0 Y -1.25
N100 G80
N105 G0 Z0.6
6.5.27  Distance Mode – G90, G91 
Interpretation of the PathPilot-code can be in one of two distance modes: absolute or incremental.
To go into absolute distance mode, program G90. In absolute distance mode, axis numbers (X, Y, Z, 
A) usually represent positions in terms of the currently active coordinate system. Any exceptions to 
that rule are described explicitly in this section describing G-codes.
To go into incremental distance mode, program G91. In incremental distance mode, axis numbers 
(X, Y, Z, A) usually represent increments from the current values of the numbers.
I and J numbers always represent increments, regardless of the distance mode setting. K numbers 
represent increments.
6.5.28  Arc Distance Mode – G90.1, G91.1
G90.1 – Absolute distance mode for I and K offsets. When G90.1 is in effect, I and K both must be 
specified with G2/3 for the XZ-plane, or it is an error.
G91.1 – Incremental distance mode for I and K offsets. G91.1 Returns I and K to default behavior.
6.5.29  G92 Offsets – G92, G92.1, G92.2, and G92.3 
This is a legacy feature. It is usually more straightforward to rely on work offsets.
To apply the offsets, program G92 X~ Z~
G92.1 – Reset axis offsets to zero and set parameters 5211-5219 to zero
G92.2 – Reset axis offsets to zero
G92.3 – Set the axis offset to the values saved in parameters 5211-5219


---

## PDF Page 133

Chapter 6
133
UM10225_15L_Slant-PRO_Manual_0626A
Programming
G92 makes the current point have the coordinates you want (without motion), where the axis words 
contain the axis numbers you want. The axis words are optional, except that at least one must be 
used. If an axis word is not used for a given axis, the coordinate on that axis of the current point is 
not changed.
When G92 is executed, the origins of all coordinate systems move. They move such that the value of 
the current controlled point, in the currently active coordinate system, becomes the specified value. 
All coordinate system’s origins are offset this same distance.
For example, suppose the current point is at X=4 and there is currently no G92 offset active. Then 
G92 X7 is programmed. This moves all origins -3 in X, which causes the current point to become X=7. 
This -3 is saved in parameter 5211.
Being in incremental distance mode has no effect on the action of G92.
G92 offsets may be already be in effect when the G92 is called. If this is the case, the offset is 
replaced with a new offset that makes the current point become the specified value. 
It is an error if: 
•	 All axis words are omitted
PathPilot stores the G92 offsets and reuses them on the next run of a program. To prevent this, one 
can program a G92.1 (to erase them), or program a G92.2 (to stop them being applied – they are 
still stored).
For more information, refer to Coordinate System section earlier in this chapter.
6.5.30  Feed Rate Mode – G93, G94, and G95
G93 – Inverse Time Mode. This mode is very unusual on a lathe with only X- and Z-axes. In inverse 
time feed rate mode, an F word means the move should be completed in [one divided by the F 
number] minutes. For example, if the F number is 2.0, the move should be completed in half a 
minute.
When the inverse time feed rate mode is active, an F word must appear on every line which has a 
G1, G2, or G3 motion, and an F word on a line that does not have G1, G2, or G3 is ignored. Being in 
inverse time feed rate mode does not affect G0 (rapid traverse) motions.
G94 – Units per Minute Mode. In this mode, an F word is interpreted to mean the controlled point 
should move at a certain number of inches per minute, or millimeters per minute, depending upon 
what length units are being used.
G95 – Units per Revolution Mode. In this mode, an F word is interpreted to mean the controlled 
point should move a certain number of inches per revolution of the spindle, depending on what 
length units are being used. G95 is not suitable for threading; for threading, use G33 or G76.


---

## PDF Page 134

Chapter 6
134
UM10225_15L_Slant-PRO_Manual_0626A
Programming
It is an error if:
•	 Inverse time feed rate mode is active and a line with G1, G2, or G3 (explicitly or implicitly) 
does not have an F word
•	 A new feed rate is not specified after switching to G94 or G95 Canned Cycle Return Level – 
G98 and G99
6.5.31  Spindle Control Mode – G96, G97
G96 D~ S~ (Constant Surface Speed = CSS)
G97 (RPM Mode)
D = Maximum spindle RPM
S = Surface speed
G96 D~ S~ – Selects constant surface speed of S feet per minute (if G20 is in effect) or meters per 
minute (if G21 is in effect).
D~ is optional.
When using G96 (the most common mode of lathe operation), X0 in the current coordinate system 
(including offsets and tool lengths) must be the spindle axis.
G97 selects RPM mode.
G96 Example Line:
G96 D2500 S250 (set CSS with a max rpm of 2500 and a surface speed of 250)
It is an error if:
•	 S is not specified with G96
•	 A feed move is specified in G96 mode while the spindle is not turning


---

## PDF Page 135

Chapter 6
135
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.6  Built-in M-codes 
M-codes interpreted directly by PathPilot are detailed in the following table.
M-code
Meaning
M00
Program stop
M01
Optional program stop
M02
Program end
M03
Rotate spindle in the forward direction
M04
Rotate spindle in the reverse direction
M05
Stop spindle rotation
M07 or M08
Coolant on
M09
All coolant off
M30
Program end and rewind
M48
Enable speed and feed override
M49
Disable speed and feed override
M98
Call subroutine
M99
Return from subroutine/repeat
M100-M199
Operator defined M-codes
6.6.1  Program Stop and Program End – M00, M01, M02, and M30 
To stop a running program temporarily, regardless of the setting of optional stop switch, program 
M00.
To stop a running program temporarily, but only if the optional stop switch is on, program M01.
It is OK to program M00 and M01 in MDI mode, but the effect probably will not be noticeable 
because normal behavior in MDI mode is to stop after each line of input, anyway.
If a program is stopped by an M00 or M01, clicking the Cycle Start button restarts the program at 
the following line of the G-code program.
To end a program, program M02 or M30. M02 leaves the next line to be executed as the M02 line. 
M30 rewinds the G-code file. These commands will have the following effects: 
•	 Distance mode is set to absolute (like G90)
•	 Feed and speed overrides are set to On (like M48)
•	 Cutter compensation is turned off (like G40)
•	 The spindle is stopped (like M05)
•	 The current motion mode is set to G01 (like G1)
•	 Coolant is turned off (like M9)
No more lines of code in the file is executed after the M02 or M30 command is executed. Clicking


---

## PDF Page 136

Chapter 6
136
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Cycle Start starts the program back at the beginning of the file.
6.6.2  Spindle Control – M03, M04, and M05 
To start the spindle turning reverse at the currently programmed speed, program M03. 
To start the spindle turning forward at the currently programmed speed, program M04. 
The speed is programmed by the S word.
To stop the spindle from turning, program M05.
It is OK to use M03 or M04 if the spindle speed is set to zero; if this is done (or if the speed override 
switch is enabled and set to zero), the spindle will not start turning. If, later, the spindle speed is set 
above zero (or the override switch is turned up), the spindle starts turning. It is permitted to use 
M03 or M04 when the spindle is already turning or to use M05 when the spindle is already stopped.
6.6.3  Coolant Control – M07, M08, and M09
To turn coolant on, program M07 or M08.
To turn flood coolant on, program M08.
To turn all coolant off, program M09.
It is always OK to use any of these commands, regardless of what coolant is on or off.
6.6.4  Automatic Collet Closer Control – M10 and M11
To open the collet closer, program M10.
To close the collet closer, program M11.
6.6.5  Override Control – M48, M49 
To enable the speed and feed override, program M48. To disable both overrides, program M49. It is 
OK to enable or disable the switches when they are already enabled or disabled. 
6.6.6  Feed Override Control – M50
M50 P1 – Enable the feed rate override control; P1 is optional
M50 P0 – Disable the feed rate control
While disabled, the feed override slider will have no influence, and the motion is executed at 
programmed feed rate (unless there is an adaptive feed rate override active).
6.6.7  Spindle Speed Override Control – M51
M51 P1 – Enable the spindle speed override control; P1 is optional
M51 P0 – Disable the spindle speed override control


---

## PDF Page 137

Chapter 6
137
UM10225_15L_Slant-PRO_Manual_0626A
Programming
While disabled, the spindle speed override has no influence, and the spindle speed has the exact 
program specified value of the S-word (described in Spindle Speed section).


---

## PDF Page 138

Chapter 6
138
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.6.8  Set Current Tool Number – M61
M61 Q~ – Change the current tool number while in MDI or Manual mode. One use is when you power 
on the system with a tool selected but the tool turret is set for a different tool to that indicated. You 
can set that tool number without doing a tool change operation. 
It is an error if: 
•	 Q~ is not 0 or greater.
6.6.9  Call Subroutine – M98
To call a subroutine, program M98 P~ L~ or M98 ~P ~Q. The program must contain a letter O line 
with the number of the P word of the call (for instance O1, O125, O777). This O line is a label which 
indicates the start of the subroutine. The O line, and the associated G-code, is normally placed at 
the end of the program with other subroutines following an M2, M30 or M99, so it is not reached 
directly by the flow of the program.
The L word (or, optionally, the Q word) gives the number of times that the subroutine is to be called 
before continuing with the line following the M98. If the L (Q) word is omitted, value defaults to 1.
By using parameters, values, or incremental moves, a repeated subroutine can make several 
roughing cuts around a complex path or cut several identical objects from one piece of material.
Subroutine calls may be nested. That is to say a subroutine may contain a M98 call to another 
subroutine. As no conditional branching is permitted, it is not meaningful for subroutines to call 
themselves recursively.
6.6.10  Return from Subroutine – M99
To return from a subroutine, program M99. Execution continues after the M98 G-code which called 
the subroutine.
6.7  Other Input Codes 
6.7.1  Feed Rate – F 
To set the feed rate, program F~.
Depending on the setting of the Feed Mode toggle, the rate may be in units-per-minute or 
units-per-rev of the spindle.  The units are those defined by the G20/G21 mode. The feed rate may 
sometimes be overridden (see Override Control – M48 and M49 section earlier in this chapter).


---

## PDF Page 139

Chapter 6
139
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.7.2  Spindle Speed – S 
To set the speed in revolutions per minute (rpm) of the spindle, program S~. The spindle turns at 
that speed when it has been programmed to start turning. It is OK to program an S word whether 
the spindle is turning or not. If the speed override switch is enabled and not set at 100 percent, the 
speed is different from what is programmed. It is OK to program S0, but the spindle does turn if that 
is done.
It is an error if:
•	 The S number is negative
6.7.3  Change Tool – T
To select a tool, program T~~ 
The first number indicates the tool to be selected and the geometry offsets entry for it in the tool 
table. The second number, which is optional, indicates the line of the tool table giving the wear 
offsets to be applied. 
Example:
T03 – Selects tool number 3 with geometry offsets from line 3 of the tool table
T0303 – Selects tool 3 and applies geometry and wear offset values from line 3 of the tool table
T0309 – Selects tool 3 and wear offsets from line 9 of the tool table; not often used in practice
If the tool turret is installed, numbers T01 through T08 automatically actuates the turret to select 
the chosen tool (see chapter 5, PathPilot Interface, for more information). Numbers greater than 
T08 are assumed to be gang tools and the program continues after applying the relevant offsets.
If Manual Tool Change is selected then the machine stops flashing the display of the required tool 
number and the LED on the Cycle Start button. The program continues on clicking Cycle Start.
It is the programmer’s responsibility to ensure that the carriage is in a safe place for changing tools, 
for example by using G30. This allows optimization of motion which can save a lot of time, especially 
with gang tooling. A pause for manual intervention can always be provided by an M00 or M01 
before the tool change.
It is an error if:
•	 A negative T number is used or a T number larger than 54 is used


---

## PDF Page 140

Chapter 6
140
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.8  Repeated Items
A line may have any number of G words, but two G words from the same modal group may not 
appear on the same line (for more information, refer to section Modal Groups earlier in this chapter).
A line may have zero to four M words. Two M words from the same modal group may not appear 
on the same line.
For all other legal letters, a line may have only one word beginning with that letter. If a parameter 
setting of the same parameter is repeated on a line, #3=15 #3=6, for example, only the last setting 
takes effect. It is illogical but not illegal to set the same parameter twice on the same line.
If more than one comment appears on a line, only the last one is used. Each of the other comments 
is read and its format is checked, but it is ignored thereafter. Putting more than one comment on a 
line is very rare.
6.9  Order of Execution 
The order of items on a line does not determine the order of execution on the commands. This 
is as defined in the Order of Execution table later in this section. The three types of items whose 
order may vary on a line (as given at the beginning of this section) are word, parameter setting, and 
comment. Imagine that these three types of items are divided into three groups by type. 
The first group (the words) may be reordered in any way without changing the meaning of the line 
which is as defined above. If the second group (the parameter settings) is reordered, there is no 
change in the meaning of the line unless the same parameter is set more than once. In this case, 
only the last setting of the parameter takes effect.
Example:
After the line #3=15 #3=6 has been interpreted, the value of parameter 3 is 6. If the order is reversed 
to #3=6 #3=15 and the line is interpreted, the value of parameter 3 is 15.
If the third group (the comments) contains more than one comment and is reordered, only the last 
comment is used. If each group is kept in order or reordered without changing the meaning of the 
line, then the three groups may be interleaved in any way without changing the meaning of the line. 
Example:
The line g40 g1 #3=15 (foo) #4=-7.0 has five items and means exactly the same thing in any of the 
120 possible orders, such as #4=-7.0 g1 #3=15 g40 (foo), for the five items. 
The order of execution of items on a line is critical to safe and effective machine operation. Items are 
executed in the order shown in the following table if they occur on the same line. Impose a different 
order (i.e., turn coolant off before spindle is stopped), by coding the commands on separate blocks.


---

## PDF Page 141

Chapter 6
141
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Order of Execution
Order
Item
1
Comment (including message)
2
Set feed rate mode (G93, G94, G95)
3
Set feed rate (F)
4
Set spindle speed (S)
5
Special I/O (M62 to M68) – not currently supported
6
Change tool (T)
7
Spindle On/Off (M03, M04, M05)
8
Save State (M70, M73, Restore State (M72), Invalidate State (M71)
9
Coolant On/Off (M07, M08, M09)
10
Enable/disable overrides (M48, M49, M50, M51, M52, M53)
11
User defined commands (M100 to M199)
12 
Dwell (G4)
13
Set active plane (G17, G18, G18) – not applicable to lathe
14
Set length units (G20, G21)
15
Cutter radius compensation On/Off (G40, G41, G42)
16
Tool table offset On/Off (G43, G49) – not applicable to lathe
17
Fixture table select (G54 – G58 and G59 P~)
19
Set path control mode (G61, G61.1, G64)
19
Set distance mode (G90, G91)
20
Set canned cycle return level mode (G98, G99)
21
Home, change coordinate system data (G10) or set offsets (G92, G94)
22
Perform motion (G00 to G03, G12, G13, G80 to G89 as modified by G53
23
Stop (M00, M01, M02, M30, M60
6.10  Error Handling 
PathPilot sometimes ignores things it does not understand. If a command does not work as expected 
or does nothing, check that you have typed it correctly. PathPilot does not check for excessively high 
machining feeds or speeds. Nor does it detect situations where a legal command does something 
unfortunate, such as machining a fixture.


---

## PDF Page 142

Chapter 6
142
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.11  Parameters and Expressions
NOTE: You may wish to skip this section on first reading as it describes features of PathPilot not used by 
code generated by the Conversational screens in PathPilot or by most CAM systems.
6.11.1  Parameters 
The RS274/NGC language supports parameters or what in other programming languages would 
be called variables. There are several types of parameters of different purpose and appearance, 
each described in the following sections. The only value type supported by parameters is 
floating-point; there are no string, Boolean or integer types in G-code like in other programming 
languages. However, logic expressions can be formulated with Boolean operators (AND, OR, XOR, 
and the comparison operators EQ,NE,GT,GE,LT,LE), and the MOD, ROUND, FUP and FIX operators 
support integer arithmetic. Parameters differ in syntax, scope, behavior when not yet initialized, 
mode, persistence and intended use.
Syntax
There are three kinds of syntactic appearance:
•	 Numbered – #4711
•	 Named local – #<localvalue>
•	 Named global – #<_globalvalue>
Scope
The scope of a parameter is either global or local within a subroutine. Subroutine parameters and 
local named variables have local scope. Globally-named parameters and numbered parameters 
starting from number 31 are global in scope.
RS274/NGC uses lexical scoping. In a subroutine, only the local variables defined therein and any global 
variables are visible. The local variables of a calling procedure are not visible in a called procedure.
Behavior of Uninitialized Parameters
1.	 Uninitialized global parameters and unused subroutine parameters return the value zero 
when used in an expression.
2.	 Uninitialized named parameters signal an error when used in an expression.
Mode
Most parameters are read/write and may be assigned to within an assignment statement. However, 
for many predefined parameters this does not make sense, so they are read-only and may appear in 
expressions, but not on the left-hand side of an assignment statement.


---

## PDF Page 143

Chapter 6
143
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Persistence
When PathPilot is powered off, volatile parameters lose their values. All parameters, except numbered 
parameters in the current persistent range (5163 to 5390), are volatile. Persistent parameters are 
saved in a disc file and restored to their previous values when PathPilot is powered on again. Volatile 
numbered parameters are reset to zero.
Intended Use
User parameters: numbered parameters in the range 31 to 5000 and named global and local 
parameters, except predefined parameters, are available for general-purpose storage of 
floating-point values, like intermediate results, flags, etc., throughout program execution. They are 
read/write (can be assigned a value).
Subroutine parameters: Used to hold the actual parameters passed to a subroutine.
Numbered parameters: Most of these are used to access offsets of coordinate systems.
System parameters: Used to determine the current running version and are read-only.
Numbered Parameters
A numbered parameter is the pound symbol # followed by an integer between 1 and 5399. The 
parameter is referred to by this integer, and its value is whatever number is stored in the parameter.
A value is stored in a parameter with the = operator; for example:
#3 = 15 (set parameter 3 to 15)
A parameter setting does not take effect until after all parameter values on the same line are found. 
Example: 
If parameter 3 has been previously set to 15 and the line #3=6 G01 X#3 is interpreted, a straight 
move to a point where X equals 15 occurs and the value of parameter 3 is then set to 6.
The # symbol takes precedence over other operations, so that, for example, #1+2 means the number 
found by adding 2 to the value of parameter 1, not the value found in parameter 3. Of course, #[1+2] 
does mean the value found in parameter 3. The # character may be repeated; for example ##2 
means the value of parameter whose index is the (integer) value of parameter 2.
The PathPilot interpreter maintains a number of read-only parameters. Only axes X and Z are 
relevant to the 15L Slant-PRO so parameters for Y, A, B, C, U, V, W axes are undefined and unused.
1-30 – Subroutine local parameters of call arguments. These parameters are local to the subroutine. 
For further information, refer to section O-codes later in this chapter.
31-5000 – G-code user parameters. These parameters are global in the G-code file.
5061-5070 – Result of G38.2 Probe (X Y Z A B C U V W)


---

## PDF Page 144

Chapter 6
144
UM10225_15L_Slant-PRO_Manual_0626A
Programming
5161-5169 – G28 Home for (X Y Z A B C U V W)
5181-5189 – G30 Home for (X Y Z A B C U V W)
5210 – 1 if G92 offsets are active, 0 if not
5211-5219 – G92 offset (X Y Z A B C U V W)
5220 – Current Coordinate System number 1-9 for G54-G59.3
5221-5230 – Coordinate System 1, G54 (X Y Z A B C U V W R); R denotes the XY rotation angle around 
the Z-axis
5241-5250 – Coordinate System 2, G55 (X Y Z A B C U V W R)
5261-5270 – Coordinate System 3, G56 (X Y Z A B C U V W R)
5281-5290 – Coordinate System 4, G57 (X Y Z A B C U V W R)
5301-5310 – Coordinate System 5, G58 (X Y Z A B C U V W R)
5321-5330 – Coordinate System 6, G59 (X Y Z A B C U V W R)
5341-5350 – Coordinate System 7, G59.1 (X Y Z A B C U V W R)
5361-5370 – Coordinate System 8, G59.2 (X Y Z A B C U V W R)
5381-5390 – Coordinate System 9, G59.3 (X Y Z A B C U V W R)
5399 – Result of M66; check or wait for input
5400 – Current Tool Number
5401-5409 – Tool Offset (X Y Z A B C U V W)
5410 – Current Tool Diameter
5411 – Current Tool Front Angle
5412 – Current Tool Back Angle
5413 – Current Tool Orientation
5420-5428 – Current Position including offsets in current program units (X Y Z A B C U V W)


---

## PDF Page 145

Chapter 6
145
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Subroutine Parameters
1-30
Subroutine local parameters of call arguments. These parameters are local to the subroutine.
Named Parameters
Named parameters work like numbered parameters but are easier to read and remember. All 
parameter names are converted to lower case and have spaces and tabs removed. Named 
parameters must be enclosed with < > marks.
#<named parameter here> is a local named parameter. By default, a named parameter is local to 
the scope in which it is assigned.
You can’t access a local parameter outside of its subroutine. This is so two subroutines can use the 
same parameter names without fear of one subroutine overwriting the values in another.
#<_global named parameter here> (i.e., name starting with an underscore) is a global named 
parameter. They are accessible from within called subroutines and may set values within subroutines 
that are accessible to the caller. As far as scope is concerned, they act just like regular numeric 
parameters. They are not made persistent by storage in a file.
Examples
Declaration of named global variable
#<_endmill_dia> = 0.049
Reference to previously declared global variable
#<_endmill_rad> = [#<_endmill_dia>/2.0]
Mixed literal and named parameters
o100 call [0.0] [0.0] [#<_inside_cutout>-#<_endmill_dia>] [#<_Zcut>] [#<_feedrate>]
NOTE: The global parameters _a, _b, _c, . . . _z have been reserved for special use. Two global, read only 
named parameters are available to check which version is running from G-code.
#<_vmajor> – Major package version. If current version was 2.5.2 would return 2.5.
#<_vminor> – Minor package version. If current version was 2.5.2 would return 0.2.


---

## PDF Page 146

Chapter 6
146
UM10225_15L_Slant-PRO_Manual_0626A
Programming
6.11.2  Expressions
An expression is a set of characters starting with a left bracket ([) and ending with a balancing right 
bracket (]). In between the brackets are numbers, parameter values, mathematical operations, and 
other expressions. An expression is evaluated to produce a number. The expressions on a line are 
evaluated when the line is read and before anything on the line is executed. 
Example: 
[1 + acos[0] - [#3 ** [4.0/2]]]
Binary Operators
Binary operators only appear inside expressions. There are four basic mathematical operations: 
addition (+), subtraction (-), multiplication (*), and division (/). There are three logical operations: 
non-exclusive or (OR), exclusive or (XOR), and logical and (AND). The eighth operation is the modulus 
operation (MOD). The ninth operation is the power operation (**) of raising the number on the left 
of the operation to the power on the right. The relational operators are equality (EQ), inequality 
(NE), strictly greater than (GT), greater than or equal to (GE), strictly less than (LT), and less than or 
equal to (LE). The binary operations are divided into several groups according to their precedence, 
detailed in Binary Operators table later in this section.
If operations in different precedence groups are strung together (for example in the expression [2.0 
/ 3 * 1.5 - 5.5 / 11.0]), operations in a higher group are to be performed before operations in a lower 
group. If an expression contains more than one operation from the same group (such as the first / 
and * in the example), the operation on the left is performed first.
Binary Operators
Operators
Precedence
**
highest
* / MOD
+ -
EQ NE GT GE LT LE
AND OR XOR
lowest
Thus, the example is equivalent to: [ [ [2.0 / 3] * 1.5] - [5.5 / 11.0] ], which is equivalent to [1.0 - 0.5] 
, which is 0.5.
The logical operations and modulus are to be performed on any real numbers, not just on integers. The 
number zero is equivalent to logical false, and any non-zero number is equivalent to logical true.


---

## PDF Page 147

Chapter 6
147
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Functions
A function is either ATAN followed by one expression divided by another expression (for example 
ATAN[2]/[1+3]) or any other function name followed by an expression (for example SIN[90]). The 
available functions are detailed in the Functions table later in this section.
Arguments to unary operations which take angle measures (COS, SIN, and TAN) are in degrees, as 
are values returned by unary operations which return angle measures (ACOS, ASIN, and ATAN).
The FIX function rounds towards the left (less positive or more negative) on a number line, so, for 
example, FIX[2.8] =2 and FIX[-2.8] = -3. 
The FUP operation rounds towards the right (more positive or less negative) on a number line; so, 
for example, FUP[2.8] = 3 and FUP[-2.8] = -2.
The EXISTS function checks for the existence of a single named parameter. It takes only one named 
parameter and returns 1 if it exists and 0 if it does not exist. It is an error if you use it with a 
numbered parameter or an expression.
Functions
Function name
Function Result
ATAN[Y]/[X] 
Four quadrant inverse tangent
ABS[arg]
Absolute value
ACOS[arg]
Inverse cosine
ASIN[arg]
Inverse sine
COS[arg]
Cosine
EXP[arg]
e raised to the given power
FIX[arg]
Round down to integer
FUP[arg]
Round up to integer
ROUND[arg]
Round to nearest integer
LN[arg]
Base-e logarithm
SIN[arg]
Sine
SQRT[arg]
Square Root
TAN[arg]
Tangent
EXISTS[arg]
Check named Parameter
6.12  O-codes
O-codes provide for flow control in NC programs. Each block has an associated number, which is the 
number used after O. Care must be taken to properly match the O-numbers. O-codes use the letter 
O, not the number zero, as the first character in the number like O100.


---

## PDF Page 148

Chapter 6
148
UM10225_15L_Slant-PRO_Manual_0626A
Programming
Numbering Example
o100 sub
  (notice that the if-endif block uses a different number)
  o110 if [#2 GT 5]
     (some code here)
  o110 endif
  (some more code here)
o100 endsub
The behavior is undefined if:
•	 The same number is used for more than one block
•	 Other words are used on a line with an O-word
•	 Comments are used on a line with an O-word
NOTE: Using the lowercase o makes it easier to distinguish from a 0 that might have been mistyped. For 
example o100 is easier to determine to be different from O100, which is not a 0.
Subroutines
Subroutines extend from a O~ sub to an O~ endsub. The lines between O~ sub and O# endsub are 
not executed until the subroutine is called with O~ call.
Subroutine Example
o100 sub
   G53 G0 X0 Y0 Z0 (rapid move to machine home)
o100 endsub
...
o100 call (call the subroutine here)
M2
For further information, refer to G53 and G0 and M2 sections.
O~ Return – Inside a subroutine, O~ return can be executed. This immediately returns to the calling 
G-code, just as though O~ endsub was encountered.


---

## PDF Page 149

Chapter 6
149
UM10225_15L_Slant-PRO_Manual_0626A
Programming
O~ Return Example
o100 sub
o110 if [#2 GT 5] (test if parameter #2 is greater than 5)
o100 return (return to top of subroutine if test is true)

o110 endif
(some code here that only gets executed if parameter #2 is less than 5)
o100 endsub
For further information, refer to Binary Operators in section Parameters and Expressions earlier in 
this chapter.
O~ Call – O~ Call takes up to 30 optional arguments, which are passed to the subroutine as #1, #2 , . 
. . , #N. Parameters from #N+1 to #30 have the same value as in the calling context. On return from 
the subroutine, the values of parameters #1 through #30 (regardless of the number of arguments) 
are restored to the values they had before the call. Parameters #1-#30 are local to the subroutine.
Because 1 2 3 is parsed as the number 123, the parameters must be enclosed in square brackets. 
The following calls a subroutine with three arguments.
O~ Call Example
o200 call [1] [2] [3]
Subroutine bodies may not be nested. They may only be called after they are defined. They may 
be called from other functions, and may call themselves recursively if it makes sense to do so. The 
maximum subroutine nesting level is 10.
Subroutines do not have return values, but they may change the value of parameters above #30 
and those changes are visible to the calling G-code. Subroutines may also change the value of global 
named parameters.
Looping
The while loop has two structures: while/endwhile, and do/while. In each case, the loop is exited 
when the while condition evaluates to false. The difference is when the test condition is done. The 
do/while loop runs the code in the loop then checks the test condition. The while/endwhile loop 
does the test first.


---

## PDF Page 150

Chapter 6
150
UM10225_15L_Slant-PRO_Manual_0626A
Programming
While Endwhile Example
(draw a sawtooth shape)
G0 X1 Y0 (move to start position)
#1 = 1 (assign parameter #1 the value of 0)
F25 (set a feed rate)
o101 while [#1 LT 10]
  G01 X0
  G01 Y[#1/10] X1
  #1 = [#1+1] (increment the test counter)
o101 endwhile
M2 (end program)
Do While Example
#1 = 0 (assign parameter #1 the value of 0)
o100 do
 (debug, parameter 1 = #1)
 o110 if [#1 EQ 2]
  #1 = 3 (assign the value of 3 to parameter #1)
  (msg, #1 has been assigned the value of 3)
  o100 continue (skip to start of loop)
  o110 endif
  (some code here)
  #1 = [#1 + 1] (increment the test counter)
o100 while [#1 LT 3]
(msg, Loop Done!)
M2
Inside a while loop, O~ break immediately exits the loop, and O~ continue immediately skips to the 
next evaluation of the while condition. If it is still true, the loop begins again at the top. If it is false, 
it exits the loop.
 Conditional
The if conditional consists of a group of statements with the same o number that start with if and 
end with endif. Optional elseif and else conditions may be between the starting if and the ending 
endif.
If the if conditional evaluates to true then the group of statements following the if up to the next 
conditional line are executed.


---

## PDF Page 151

Chapter 6
151
UM10225_15L_Slant-PRO_Manual_0626A
Programming
If the if conditional evaluates to false then the elseif conditions are evaluated in order until one 
evaluates to true. If the elseif condition is true then the statements following the elseif up to 
the next conditional line are executed. If none of the if or elseif conditions evaluate to true then 
the statements following the else are executed. When a condition is evaluated to true no more 
conditions are evaluated in the group.
If Endif Example
o101 if [#31 EQ 3] (if parameter #31 is equal to 3 set S2000)
  S2000
o101 endif
If ElseIf …Else … EndIf Example
o102 if [#2 GT 5] (if parameter #2 is greater than 5 set F100)
  F100
o102 elseif [#2 LT 2] (else if parameter #2 is less than 2 set F200)
  F200
o102 else (else if parameter #2 is 2 through 5 set F150)
  F150
o102 endif
Repeat
The repeat executes the statements inside of the repeat/endrepeat the specified number of times. 
The example below shows how you might mill a diagonal series of shapes starting at the present 
position.
Repeat Example
(Mill 5 diagonal shapes)
G91 (Incremental mode)
o103 repeat [5]
  ... (insert millinG-code here)
  G0 X1 Y1 (diagonal move to next position)
o103 endrepeat
G90 (Absolute mode)
Indirection
The O-number may be given by a parameter and/or calculation.
Indirection Example
o[#101+2] call


---

## PDF Page 152

Chapter 6
152
UM10225_15L_Slant-PRO_Manual_0626A
Programming
For more information on computing values refer to these items in section Parameters and Expressions 
earlier in this chapter:
•	 Parameters
•	 Expressions
•	 Binary Operators
•	 Functions
Calling Files
To call a separate file with a subroutine, name the file the same as your call and include a sub and 
endsub in the file. The file must be in the directory Subroutines. The file name can include lowercase 
letters, numbers, dashes, and underscores only. A named subroutine file can contain only a single 
subroutine definition. The file must end with the extension .nc.
Named File Example
o<myfile> call
Numbered File Example
o123 call
In the called file you must include the oxxx sub and endsub and the file must be a valid file.
Called File Example
(filename myfile.nc)
o<myfile> sub
  (code here)
o<myfile> endsub
M2
NOTE: File names are lowercase letters only; o<MyFile> is converted to o<myfile> by the interpreter.


---

## PDF Page 153

Chapter 7
153
UM10225_15L_Slant-PRO_Manual_0626A
Maintenance
7.  Maintenance
7.1  Lathe Maintenance Schedule
Frequency
Completed
Item
Daily
Check coolant level (12 gallon capacity)
Check oiler level and top off as needed (Auto Oiler 2.1 quarts / Manual Oiler 
0.25 quart)
Clean chips from ways and carriage
Spray exposed, non-painted metal surfaces areas with WD-40® or similar to 
prevent rust
Weekly
Check/adjust draw tube tension on 5C lever closer (if applicable)
Clean chip basket on coolant tank
Check air gauge/regulator for proper PSI (90 PSI minimum)
Use mild cleaner to clean all exterior surfaces (no solvents)
Check oil and grease reservoirs; top up as needed
Monthly
Dispose of oil in drain bucket
Remove coolant tank pump and clean out sediment buildup in tank; reinstall
Inspect electrical cabinet vent(s) for dust build up; if necessary, wipe vents with 
clean cloth or use compressed air to remove dust if accumulation is excessive
Every Six 
Months
Inspect way covers as needed to ensure proper operation; replace as needed
Inspect oil system for blockages; clean/replace as needed
Check lubrication hoses for signs of wear or cracking; replace as needed
Every 12 
Months
Check limit switches for proper function; replace as needed
Check door switches for proper function; replace as needed


---

## PDF Page 154

Chapter 7
154
UM10225_15L_Slant-PRO_Manual_0626A
Maintenance
7.2  Understanding Machine Design
The 15L Slant-PRO lathe has been designed for operator maintenance, but an important prerequisite 
to effective maintenance is an understanding of some general machine-design concepts. For many 
owners, a Tormach machine is their first experience with a machine tool and they may be unfamiliar 
with the ideas presented here. This section should be read and understood before attempting any 
adjustments to the machine.
7.2.1  Machine Stiffness
In the context of the human experience, the iron and steel of your lathe seems exceptionally stiff 
and essentially immovable. Nevertheless, any physicist or material scientist will tell you that iron is 
a Hookean material, meaning that it always obeys Hooke’s law and distorts linearly in proportion to 
applied force. In simple terms, it acts like a spring. A small force makes a small distortion, and a large 
force makes for a large distortion.
A good dial indicator can show motion of a distance 0.0002”. This sort of distance is outside the 
scope of normal human experience. In the context of a dial indicator, the iron and steel of your 
lathe no longer seems rigid, and the motion of the frame under force becomes quite apparent. You 
should know that this flexibility is natural. You would see more flex on an 800 lb. machine and less 
on an 8000 lb. machine. One of the keys to creating accurate parts with your lathe is developing an 
awareness of machine flex. The flexure of the machine cutting tool and workpiece are the principle 
reasons that a light finishing cut yields a more accurate part.
7.2.2  Backlash, Friction, and Lost Motion
All machines show backlash. Conventional backlash is the result of open spaces between moving 
parts. For example most ball bearings have clearance between the balls and races which results in 
backlash. Pre-loading bearings is the technique of putting opposing pairs of bearings in compression. 
This technique eliminates the open space, but apparent backlash, more correctly called lost motion, 
still exists. There is always some force required for motion. Since the bearings are compressible 
(steel is a spring), there is some motion required for compression before enough force is delivered 
and motion is obtained. This is lost motion and has the same effect as conventional backlash.
When performing maintenance on the machine you should be aware that if there is backlash of 
more than 0.003”, there is some conventional backlash and something needs to be adjusted or 
replaced. Backlash of 0.002” or less is probably lost motion and not conventional backlash.
There are compromises and tradeoffs made when adjusting the machine. Tightening the gibs on the 
X-axis reduces backlash in Z, but it also increases the force required for motion in X, thus increasing 
lost motion in X. Increasing the preload on a bearing pair reduces lost motion, but it shortens the 
life of the bearing.


---

## PDF Page 155

Chapter 7
155
UM10225_15L_Slant-PRO_Manual_0626A
Maintenance
7.2.3  Factors Combine
Machine setup and tuning is done under no-load conditions. The accuracy of machined work is 
going to be worse because tool flex, workpiece flex, and other factors combined with the basic 
machine accuracy. Even thermal expansion adds to the mix. A 30” ball screw changes 0.0025” in 
length with a 10˚F change in temperature.
7.2.4  Adjusting Geometry
Over time, a machine may need adjustment. All of the iron castings of your machine undergo thermal 
stress reliving. Major elements, such as the column and base, also undergo a vibratory stress relief 
process between rough machining and final machining. Nevertheless, it is possible that any iron 
casting can change shape a small amount, whether due to changes in the crystalline structure over 
time or changes induced through tool crashes and abuse.
Before making any adjustment, think carefully about the need for the adjustment and implications 
associated with it. Adjustments can be made and are sometimes necessary. Proceed slowly and think 
carefully, assessing the need for any adjustment and the best method for making that adjustment.
7.2.5  Achieving Accuracy in Machining
The key to achieving maximum accuracy is understanding and controlling the magnitude and 
direction of forces. Maximum accuracy is achieved when the forces are minimized, as occurs in a 
finishing cut. Maximum repeatability is achieved when the forces are repeatable, both in magnitude 
and direction.
Machining is a mix of science, skill, and art. The caveat in stating accuracy and repeatability is 
that these factors depend on the techniques used by the machinist. A skilled machinist can often 
deliver accuracy that exceeds the accuracy specified by the machine builder, while an inexperienced 
machinist may have difficulty delivering the expected accuracy.
7.2.6  Rust Prevention
Exposed iron and steel surfaces will rust if proper care is not taken to protect them. The following 
recommendations will slow or reduce the onset of surface rust.
•	 If possible, install the lathe in a temperature- and humidity-controlled environment.
•	 Always use a flood coolant recommended for machining; never use water or a coolant that 
does not contain rust-inhibitors. When using a water-based coolant, always mix the coolant 
concentrate to the dilution ratio recommended by the coolant manufacturer.
•	 If the lathe is not used for more than 72 hours, apply a light mist of water repellent oil (WD-40 
or similar) to the exposed bare metal surfaces.
•	 Trapped areas are susceptible to rust. Apply way oil or machine oil directly to the table surface 
under the trapped area when you mount a gang plate or T-slot plate on the lathe.


---

## PDF Page 156

Chapter 7
156
UM10225_15L_Slant-PRO_Manual_0626A
Maintenance
7.3  Gibs, Dovetail Slideways, and Lubrication
The X and Z slideways have a bonded layer of skived plastic compound, a composition of acetyl and 
PTFE. The material is commonly known under the trade names of Turcite® or Rulon®. This is state 
of the art technology for oil lubricated slideways and superior to plain ground surfaces or hardened 
and chromed surfaces. We don’t have data on how long the material lasts on the 15L Slant-PRO, 
but we do know that there have been no reports of appreciable wear – even on machines that 
are reported to have seen more than 5000 hours of operation. If you use the automatic oiler, the 
slideways are not normally maintenance items.
The lubrication system should be filled with Tormach Machine Oil (PN 31386). Other options include 
Perkins Perlube WL-68, Tonna 68 (Shell), Vactra No. 2 (Mobil), Way-lube 68 (Sunoco), WayLube 68 
(Texaco), Febis 68 (Esso) or equivalent oil.
A shot of lubrication should be given for each four hours of operation as well as each time the 
machine is powered on. The oil is delivered to 10 points throughout the machine. This includes the 
eight sliding surfaces (four on each axis) and two ball nuts. These are some of the most critical (and 
costly) mechanical parts of the machine. Always make certain that the lubrication oil is clean. Any 
dirt or foreign material suspended in the oil is going to be delivered directly to these parts and can 
dramatically shorten the effective life of the machine. Be sure to clean off the cover and surrounding 
area before refilling the oil reservoir. The strainer at the top of the reservoir is only a screen – it is 
not a filter.
Extreme axis positions can expose the oil distribution channels that are cut into the way support 
saddle surfaces. If the pump is used in those positions the hydraulic force of the oil does not apply 
it throughout the machine as intended. Instead, the oil simply squirts out at the point where the oil 
channel is exposed. After a long period of inactivity or in cold conditions, the oil system may become 
clogged. For more information, refer to Tormach service bulletin SB0031 – Flushing the Lubrication 
System.
Figure 7.1


---

## PDF Page 157

Chapter 7
157
UM10225_15L_Slant-PRO_Manual_0626A
Maintenance
The slideways are hand scraped as part of the manufacturing process. This means that the Z-axis 
saddle is fitted to the bed. They are scraped in as a set and neither the saddle nor the base can be 
had as a replacement component. The slideways have tapered gib plates (also hand scraped), where 
the position of the gib plate controls the tightness and friction in a slide way. For example, in Figure 
7.1, the Z-axis gib plate is part of the saddle and is held in position on both front and back via the 
gib screws.
7.3.1  Gib Adjustment Procedure
The adjustment procedure is similar for both axes. The Z-axis is described in detail. The gib plate is 
tapered from right to left. When the gib plate is moved in the Z negative direction (to the left of the 
operator), the Z-axis saddle the slide way tightens; when it moves in the Z positive direction, the 
slideway loosens. With the machine is powered on, move the Z-axis to near the middle of its travel 
and locate the gib plate screw on either end of the Z saddle (Figure 7.1).
It is difficult to assess the correct clearance for the gib as a very small force on its end can, via the 
shallow taper, apply a large force to the dovetail. Too tight a gib results in zero gap and very high 
friction since there is no longer space for an oil film.
The easiest method is by a form of dead reckoning:
1.	 Ensure the left (loosening) gib screw is unscrewed by several turns to allow for clearance for 
the gib to be adjusted to the left.
2.	 Tighten the right (tightening) gib screw in, thus pushing the gib left until it is tight yet not 
hitting the bottom screw. Wiggle the carriage while you are tightening this screw to get the 
gib reasonably tight – but not so tight as to strip the screw head or flex the castings.
3.	 Loosen the right screw four full turns. 
4.	 Tighten the left screw, thus pushing the gib back up against the upper screw and creating a 
positive amount of gib clearance. The gib should be held in place with upper and lower screw 
tight on the gib. 
IMPORTANT! Ensure both adjustment screws are tight after any gib adjustment. Failure to do so will result 
in gib movement.
A more precise method of adjusting the gibs is to use lost motion, apparent as backlash on a dial 
indicator, to arrive at the correct setting:
1.	 Loosen the right screw eight turns and tighten the left screw eight turns so that the gib 
clearance is loose.
2.	 Use a dial indicator to measure the axis backlash. With a very loose gib, the measured backlash 
is entirely attributable to the backlash in the belt reduction drive, the angular contact bearings, 
and the ball nut. On a newer machine, the value should be under 0.0025” on either axis. 
3.	 Tighten the gib by one turn (by loosening the lower screw first, then tightening the upper 
screw). Measure the backlash again.


---

## PDF Page 158

Chapter 7
158
UM10225_15L_Slant-PRO_Manual_0626A
Maintenance
4.	 Repeat this procedure until the measured backlash increases – this is the point at which the 
gib setting has started to induce lost motion in the axis.
5.	 Back the adjustment off to the point just before you saw the increased backlash. That is the 
ideal setting for the axis (see Figure 7.2).
NOTE: For the X-axis, the gib tightens with the gib screw on the bottom (operator side). No covers need to 
be removed.
0.004
0.0035
0.003
0.0025
0.002
0.0015
0.001
0.0005
0
0 
   0.5         1  
1.5 
     2 
        2.5 
  3 
     3.5           4 
  4.5 
 
Backlash (in)
Number of Turns of Adjusting Screw
(Zero represents a loose gib, five represents a tight gib)
Figure 7.2 
Backlash Versus Turns of Adjusting Screw


---

## PDF Page 159

Chapter 8
159
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
8.  Troubleshooting
8.1  Troubleshooting Basics
The 15L Slant-PRO is an integration of mechanical components, electrical components, a controller, 
and software. Taken as a whole, the 15L is a complex machine; however, the machine comprises 
several subsystems, each of which is much easier to understand than is the machine in its entirety. 
1
Divide and conquer
Work on one problem at a time; focus on related issues only
2
Know the machine
Be familiar with how machine functions under normal circumstances
3
Environmental changes
Determine if any changes occurred in machine environment including:
•	
The lathe was moved
•	
A fuse blew or breaker tripped causing electronics to malfunction
•	
Water/moisture entered machine area
•	
Major temperature change in unheated facility
•	
Unauthorized lathe use occurred
4
Work smart
Draft a list of tests to perform by level of difficulty; try simplest, most 
likely tests first to determine causes of problem; record results
5
One step at a time
Take time to complete one test before starting another, thereby not making 
the problem worse by conducting random troubleshooting.
This chapter builds on these key principles by providing a description of each of the subsystems. 
This serves to help the operator understand how the machine will work, and provides an overview 
of the components that are involved in the subsystem. We also list some guidelines for equipment 
and procedures used in troubleshooting.
As in most electromechanical machines, it is frequently easier to see problems in the mechanical 
systems than the electrical and controller systems. With this in mind, most of the details in the 
troubleshooting section will address non-mechanical areas.
8.2  Tips and Tools for Troubleshooting (equipment and procedures)
8.2.1  Safety
During troubleshooting, the operator is exposed to more hazards than during normal operation: 
electrical tests may need to be done on live circuits; guards may have to be removed; a safety switch 
may have to be overriden in order to make an observation. Take things slow and be extra cautious.
IMPORTANT! For complete safety information, refer to the Safety Overview starting on page 2.


---

## PDF Page 160

Chapter 8
160
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
8.2.2  Tips on Controller Diagnosis
The PathPilot® operating system provides a status screen that is useful for troubleshooting. If calling 
Tormach Technical Support, make sure you know what version of PathPilot is running and any 
pertinent information from the Status screen and the error line.
To email the log file to Tormach Technical Support, use the File tab to transfer the relevant information 
to a USB flash drive.
1.	 Insert a USB flash drive into any 
open USB slot on the controller.
2.	 On the File screen, click Home in 
the upper right-hand corner of the 
screen (see Figure 8.1).
3.	 Locate and click the logfile folder 
(see Figure 8.1); inside this folder, 
highlight the pathpilotlog.txt file.
4.	 Click Copy to USB (see Figure 8.1).
5.	 After the file transfers, remove the 
USB flash drive from controller and 
email the file to Technical Support.
8.2.3  Troubleshooting Tools
The following are some basic tools to have on hand for troubleshooting:
•	 Good lighting such as a trouble light, headlamp, or flashlight
•	 A digital multimeter that can test for AC volts up to 300 V, DC volts up to 100 V, and resistance 
from 0 to 1M ohms (Ω)
•	 Assorted screwdrivers: #2 and #3 Phillips, 1/8” and 3/16” flat blade
•	 Assorted hex keys in metric sizes
•	 A wire stripper
•	 Measuring tools like tape measure, micrometer, or dial indicator (optional)
8.2.4  Using Digital Multimeter for Electrical Tests
Almost all digital multimeters have the capability of measuring AC volts, DC volts, and resistance. 
These are the important functions used when troubleshooting a Tormach machine tool. Two test 
leads are required to measure these three functions. While many meters have more than two 
receptacles in which to plug leads, for our purposes the leads will always remain in the same two 
receptacles. One receptacle is almost universally labeled COM (for common) and the black lead 
is to be plugged into this receptacle. The other lead, most often red in color, is plugged into the 
receptacle labeled VΩ (volts and ohms).
Figure 8.1


---

## PDF Page 161

Chapter 8
161
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
8.2.4.1  Measuring DC Voltage
Select the DC voltage scale on the meter. The scale may be labeled DCV. DC voltage has polarity, 
so if the common lead on the meter is not placed on the common signal, the voltage will read as a 
negative number. This does not harm the meter, but could be confusing in certain cases. We strive 
to define the common terminal when asking you to take a measurement.
8.2.4.2  Measuring AC Voltage
Select the AC voltage scale on the meter. The scale may be labeled ACV. There is no polarity to AC 
voltage; either lead can be placed on either location to measure.
8.2.4.3  Measuring Resistance
Ohms are the units in which resistance is measured. Select the resistance scale on the meter, most 
often labeled Ω. There is no polarity to resistance so either lead can be placed on either location we 
are having you measure; however, resistance measurements are always taken with power off.
NOTE: When making resistance measurements on motors and other devices with low resistance, always 
take a tare or zero reading on the meter before doing the resistance measurement on the motor or device. 
A tare reading is a reading using only the instrument and its test leads. In the case of using a digital 
multimeter to measure resistance, touch the probes together to get the tare reading. Subtract the tare 
reading from the meter reading when measuring the resistance of the motor to get a true value.
8.2.5  Contacting Technical Support
Always try to resolve any issue by first reviewing this manual’s troubleshooting section. If this effort 
does not produce results – and you do need to contact Tormach Technical Support – please review 
the list below prior to calling Tormach Technical Support. This will make the problem resolution 
process go smoother.
1.	 Record machine serial number and have it available.
2.	 We use a case management database system to track problems. Be sure to inform Technical 
Support staff if you experienced the problem before, as this allows us to review the history of 
the machine. If possible, please have your case management number ready.
3.	 If the machine was purchased from someone else, please have that person’s name available. 
This way we can reference your specific machine in our case management database system 
and identify any problems the previous owner experienced.
4.	 Analyze what might have changed since the machine last worked correctly and have that 
information available.
5.	 Review the troubleshooting-related subsystem you are having problems with to gain a better 
understanding of that subsystem.
6.	 Make sure you can repeat the problem(s). Do this several times and record the results to 
determine if you can repeat the problem(s) exactly.


---

## PDF Page 162

Chapter 8
162
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
7.	 Record any pertinent information from the diagnostic screen of the PathPilot interface and 
have it available.
8.	 Try to define the problem as clearly and concisely as possible by writing it down. Often times 
by doing this you may help pinpoint the problem or find the solution to the problem yourself.
9.	 Consider sending Technical Support an email first, as this may help define the problem better. 
Communicating via email has the added benefit of documenting the issue, thus eliminating 
the need to interpret any hastily transcribed notes made during the phone conversation later 
on. Even if you do need to speak with Technical Support, sending an email first can help the 
conversation go smoother.
Tormach Technical Support
 Email contact (preferred)
info@tormach.com
 Phone contact (8:00 – 5:00 CST)
608-849-8381
8.3  Frequently Found Problems
The sections to follow detail several frequently found problems with all electromechanical machinery. 
It is not that the problems are frequent, but among the problems that have occurred, these are 
more frequent than others.
8.3.1  Loose Wires
Try as we might, it seems that on occasion we find a poor wire connection. This can be the wire in a 
screw clamp terminal where the clamp is loose or a problem with a crimp spade or ring connector 
where the connector is tight in the screw clamp terminal but the wire is loose in the crimp connector. 
This is most frequently found during the initial startup of the machine. The vibration that occurs 
during travel tends to loosen connections. Use the two finger pull test: grasp the wire close to its 
termination point between your thumb and index finger, and gently but firmly tug each wire. If the 
wire comes loose, re-terminate it before moving on to other wires. 
8.3.2  Wire Hairs
Sometimes with stranded wire we find that a stray strand, or wire hair, from the stripped end of the 
wire may be sticking out and touching another wire or the machine frame; this can cause short circuits.
8.3.3  Poor Cable Connections
There are a number of cables on a Tormach 15L Slant‐PRO lathe. Some are flat cables connecting 
the control board to the axis drives (or other devices) and some cables connect with the controller. 
An improperly seated cable can allow some functions to work and cause others not to. The ribbon 
cables are plugged into connectors with locking ears; ensure that the cables are correctly seated 
and that the ears are in the locked position.


---

## PDF Page 163

Chapter 8
163
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
The parallel port cable connection between the machine tool and the PCI card in the back of the 
controller should be firmly attached with the locking screws. Loose parallel port cables can cause 
machine communication issues that are hard to diagnose.
8.3.4  Controller Restart Required
It is a good practice to power cycle the controller on a daily basis. Controllers left on for weeks at a 
time can become problematic.
8.4  Review of Subsystems
8.4.1  Power Distribution Subsystem
8.4.1.1  Overview
Operator-supplied electrical power (both the primary 230 VAC and secondary 115 VAC) is run 
through the main disconnect on the machine. This switch controlls all power to the machine and 
the controller.
8.4.1.2  Details of the Power Distribution Subsystem
The power distribution subsystem portion of the electrical schematic is highlighted in Figure 8.2. For 
a more detailed view, refer to the lathe’s electrical schematic in the back of this manual.
Figure 8.2


---

## PDF Page 164

Chapter 8
164
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
The related power distribution component locations in the electrical cabinet are highlighted in 
Figure 8.3.
The 15L Slant-PRO lathe is powered by a user provided nominal 230/1/60 (230 V single phase, 60 
HZ) 20 Amp, 3-wire electrical circuit in North America and a 220/1/50 20 Amp, three wire electrical 
circuit in most other parts of the world. Tormach allows an input voltage range of 200 VAC to 250 
VAC. The two current-carrying conductors of this supply are connected to the main disconnect 
located on the electrical cabinet. When the main disconnect is in the Off position, no power is 
supplied to the machine or to the accessories (controller, monitor, coolant pump) plugged into the 
outlets on the back panel of the electrical cabinet.
In addition to the main 230 VAC electrical supply, the lathe requires a 115 VAC auxiliary supply 
for the controller, monitor, and coolant pump. The power source for this circuit can be 110/1/50, 
115/1/60 or 220/1/50 single phase power with one leg of the two current carrying conductors 
grounded. Normally, a 115 VAC circuit would be supplied in North America. A third wire ground 
must also be provided. The ungrounded leg of this supply is connected to a third pole on the main 
disconnect described earlier in this section. Running this circuit in this manner allows the coolant 
pump outlet to be controlled through PathPilot. The circuit also provides power to two outlets 
which can be used for the controller and monitor. Turning the main disconnect to the Off position 
powers off the coolant and controller.
Figure 8.3


---

## PDF Page 165

Chapter 8
165
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
8.4.2  Control Power Subsystem
8.4.2.1  Overview
Control power enables running of the machine. When control power is on, the lathe control PCB and 
the axis motor drives in the cabinet are powered on. The spindle drive will not power on with the 
control power circuit – it only powers on at the first PathPilot spindle command. Turn control power 
on by pressing the green Start button; turn control power off by turning the red E-stop clockwise. 
The Machine LED illuminates when control power is on.
8.4.2.2  Details of the Control Power Subsystem
The control power subsystem portion of the electrical schematic is highlighted in Figure 8.4. For a 
more detailed view, refer to the lathe’s electrical schematic in the back of this manual.
Figure 8.4


---

## PDF Page 166

Chapter 8
166
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
The related control power distribution component locations in the electrical cabinet are highlighted 
in Figure 8.5.
The control power circuit is energized when the machine is in a ready-to-run state and de-energized 
when the red E-stop is in the depressed position. The circuit does not energize until the red E-stop 
button is and the green Start button is momentarily depressed, energizing the latching C1 contactor. 
 WARNING! Hazardous Voltage: When control power is off, some components in the electrical 
cabinet are still energized, including: the main fuses FU1 and FU2; the control power transformer (XFM1); 
fuse FU3; and wires 102 and 103 on the stop and start push buttons. Additionally, the filter is powered by 
L11 and L21 and the filter passes power on wires L23 and L24 to contacts on the contactors C1 and C2. Be 
sure to remove power from the machine tool by switching the Main Disconnect to the off position. Failure 
to do so could result in serious injury or death.
Should the main power to the machine be lost when the control power circuit is on, the control 
power circuit turns off and stays off until power is restored and the green Start button is pressed. 
This prevents the machine from restarting without operator action after any power outage, natural 
or man-made. Transformer XFM1 reduces the incoming voltage from a nominal 230 (or 220) VAC 
to a nominal 115 (or 110) VAC. 115V control circuits are industry standard in North America (this 
allows the use of readily available push buttons, contactors, and other control circuit components).
Figure 8.5


---

## PDF Page 167

Chapter 8
167
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
If the wall breaker consistently trips whenever the spindle is powered on, verify that the main 
machine power is not coming through a ground fault interruptor (GFI, or RCCB in Europe), as the 
filters in the spindle drive can allow minor leakage current to ground that, while considered safe, 
may also be sufficient to trip a GFI circuit breaker.
8.4.3  Controller Communication Subsystem
8.4.3.1  Overview
PathPilot operating system is the control software for the 15L Slant-PRO lathe. It allows for manual 
jogging of X- and Z-axes, spindle speed, and coolant pump through the PathPilot interface. It also 
allows the machine to run automatically with operator-supplied programs. PathPilot communicates 
with the lathe control PCB to provide machine control. The Controller LED on the operator panel 
must be illuminated before the computer can control the machine. 
8.4.3.2  Details of the Controller Communication Subsystem
When the machine tool is first powered on following the power off/on procedure detailed in chapter 
3, Operation, the Machine OK LED on the operator panel illuminates. PathPilot loads automatically 
when the controller is powered on (the main disconnect turned to the On position). When the 
software is loaded and the flashing Reset button is pressed, the LED on the operator panel illuminates.
The controller communicates with the machine tool via a PCI card with a DB-25 connector. This 
connector is identical to the parallel port connector, and it would be easy to mistakenly plug the 
cable into the wrong connector. If PathPilot will not communicate with the machine tool, verify that 
you have plugged the cable into the correct port on the back of the controller. PathPilot provides a 
Status screen with diagnostic LEDs which can be useful for troubleshooting.
8.4.4  Axis Drive Subsystem
8.4.4.1  Overview
The axis motors (otherwise known as stepper motors) are used to move the X- and Z-axes. The 
motors are powered by electronic driver modules (also referred to as axis drivers) which receive 
control signals from the lathe control board. The electronic driver modules get power from the DC 
bus board. Once the machine has been referenced, it is limited in travel by PathPilot soft limits.


---

## PDF Page 168

Chapter 8
168
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
8.4.4.2  Details of the Axis Drive Subsystem
The axis drive subsystem portion of the electrical schematic is highlighted in Figure 8.6. For a more 
detailed view, refer to the lathe’s electrical schematic in the back of this manual.
Motion for the X- and Z-axes is provided by stepper motors. Each motor is powered by an electronic 
driver module. The driver module receives nominal 65 VDC power from the DC bus board and 
receives control signals from the lathe control board, which processes and formats information 
sent by the controller. The axes are driven by stepper motors that have no encoder feedback. It is 
possible that an axis can be commanded to move but will not move as far as it is commanded to. 
Excessive friction or load in the mechanical system causes position loss. If losing steps, it is possible 
to hear a cogging noise from the motor. This problem is most likely to appear when attempting to 
drill large holes with the lathe: a 3/4” hole in mild steel without a pilot drill will almost certainly 
require more force than the Z-axis motor can provide. It is our recommendation to use a pilot hole 
with any drill diameter over 1/2”.
Figure 8.6


---

## PDF Page 169

Chapter 8
169
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
The related axis drive distribution component locations in the electrical cabinet are highlighted in 
Figure 8.7.
Figure 8.7


---

## PDF Page 170

Chapter 8
170
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
8.4.5  Spindle Drive Subsystem
8.4.5.1  Overview
The spindle drive subsystem portion of the electrical schematic is highlighted in Figure 8.8. For a 
more detailed view, refer to the lathe’s electrical schematic in the back of this manual.
8.4.5.2  Details of the Spindle Drive Subsystem
The spindle is powered by a three horsepower AC motor whose speed is controlled by a variable 
frequency drive (VFD). The spindle is in a ready-to-run condition when the control power is on and 
the chuck guard or enclosure door is closed. 
The drive itself is powered by contactor C2, which allows power to pass when the drive is commanded 
to run by the controller. Power is removed from this drive whenever the chuck guard or enclosure 
door switch is opened, or when the E-stop removes power from the control power circuit.
NOTE: After powering off, the VFD only powers back on when first commanded to run. The VFD will not 
power on by pushing the green Start button on the operator panel. Once the VFD is powered on, it will stay 
on until one of the above conditions occurs.
Figure 8.8


---

## PDF Page 171

Chapter 8
171
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
The lathe control board provides a contact closure between wires 106 and 107 to cause power to 
be applied to the drive. It also provides a run command, a direction command, and a frequency 
command in the range of 0-10 kHz to wires J1-1 and J1-2 (COM) proportional to desired speed. 
The related spindle drive distribution component locations (in machine cabinet) are highlighted in 
Figure 8.9.
The display on the VFD provides valuable information for troubleshooting. The display on the VFD 
provides diagnostics which include:
•	 Motor speed, presented in motor RPMs
•	 Load percentage (load is proportional to the motor torque output)
•	 Status (ready, or rd, and inhibit, or ih) which occur when there is no connection between 
terminals B2 and B4 on the drive
•	 Fault information (tr, or trip) and a code for the fault
The drive can also provide parameter information. This is information from the Tormach program 
of the drive and is usually not important from an operator standpoint. If the drive is displaying this 
sort of information, which always has two-digit numbers displayed on the left side of the display, the 
operator must take action to allow the drive to display the diagnostic information.
Figure 8.9


---

## PDF Page 172

Chapter 8
172
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
If the right side digits are flashing, momentarily press and release the M button just below the 
display to cause the left side digits to flash. With the left side digits flashing, press and hold the M 
button for three seconds; the display changes to display diagnostics. If speed is displayed and it is 
desired to display load, or vice versa, press and hold the M button for three seconds.
NOTE: Do not attempt to change any parameter values in the VFD. There are no operator-settable 
parameters available.
8.4.5.3  Spindle Direction
To prevent unwanted motion and potential damage to lathe, check to ensure spindle rotates in the 
correct direction. For more information, refer to chapter 3, Operation.
Reversing Spindle Direction
 WARNING! Electrical Shock Hazard: Be sure to power off lathe before making any electrical 
modifications. Failure to do so may result in personal injury or death.
1.	 Power off the lathe following the power off/on procedure detailed in chapter 3, Operation.
2.	 Locate the VFD in the electrical cabinet (see Figure 8.10). Using a Phillips screwdriver, remove 
the VFD cover.
3.	 Identify motor wires #401 and #402, located at the bottom of the VFD (see Figure 8.11). 
Loosen the set screws above wires #401 and #402 and swap the wire connections (see Figure 
8.11). When complete, retighten the set screws.
4.	 Reinstall the VFD cover and close the electrical cabinet door.
5.	 Power on the lathe following the power off/on procedure detailed in chapter 3, Operation.
6.	 On the Main screen in the PathPilot interface, click Spindle FWD to start spindle rotation.
Figure 8.10 
Remove VFD 
Cover Screw
Figure 8.11 
Set Screws


---

## PDF Page 173

Chapter 8
173
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
7.	 Confirm the spindle is rotating in 
the correct forward direction (see 
Figure 8.12).
8.4.6  Home Switches
The X- and Z-axes each have one home 
switch which actuates at the end of travel 
in each direction (see Figure 8.13). These 
limit switches are used to stop an axis 
near its extreme travel position during a 
reference procedure. After referencing, 
PathPilot uses the referenced position as 
a soft limit, preventing motion beyond 
this position.
Sensors such as limit switches are usually 
the biggest source of problems on a 
machine. By necessity, they need to be 
mounted out on the machine where they 
are detecting events such as end of travel. 
This makes them vulnerable to damage. 
They can get fouled by coolant, chips, or 
physical contact. Sticking and wire damage 
are also a common problems. 
Both X and Z switches are wired normally 
closed. Therefore, a broken wire or bad 
connection results in the lathe control 
card detecting a limit switch is actuated. 
These switches are also wired in series, 
so if one switch is bad or a wire becomes 
disconnected the control board detects 
that both have been actuated. The Status 
screen shows the status of the switches.
Figure 8.13 
Figure 8.12 
Correct Forward Spindle Direction


---

## PDF Page 174

Chapter 8
174
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
8.5  Troubleshooting Subsystems
Use the following flowchart to decide which section to troubleshoot:
START
END
Proceed to the Control 
Power Subsystem
Can control power be 
turned on (machine LED 
light is on)?
Proceed to the Axes 
Drive Subsystem
Are X and Z axes
functioning properly?
Proceed to the Spindle 
Drive Subsystem
Is the spindle drive 
functioning properly?
Is there power to the 
machine, coolant pump, 
and/or controller?
Proceed to the Power 
Distribution Subsystem
Can controller LED be 
turned on?
Proceed to the Controller 
Communication Subsystem


---

## PDF Page 175

Chapter 8
175
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
8.5.1  Power Distribution Subsystem
Problem: GFI or circuit breaker for controller/coolant pump trips when main disconnect is 
turned to the On position
Possible Causes
Bad breaker or GFI; test by plugging another device (such as a drill) into the outlet. If the 
other device works, the outlet is OK.
Loose wires in the machine cabinet; power off the lathe following the power off/on 
procedure detailed in chapter 3, Operation, and check for loose wires. Using the two 
finger tug test, gently pull on all wires in the power distribution circuit.
Problem: Controller will not turn on when main disconnect is turned to the On position
Possible Causes
Controller power cord has come unplugged.
Auxiliary power cord from 115 VAC source to electrical cabinet has come unplugged.
Controller BIOS setting is not set to After Power Failure – Power On.
Problem: Control power circuit will not turn on when green Start button is pressed
Possible Causes
One or more E-stop buttons have been depressed. Ensure that both the E-stop buttons 
are twisted out into the released positions.
The 230 VAC supply to machine is unplugged or has no power. Check at 230 VAC outlet 
to make sure that lathe has power.
Main disconnect has been left in the Off position.
Fuse FU1 or FU2 blown. Check for 230 VAC across wires L1 and L2, then across wires L11 
and L21. If you have voltage across L1/L2 but not across L11/L21, the fuses have blown. 
A red LED on the fuse holder should also indicate a blown fuse.
Fuse FU3, FU5, or FU7 blown. These fuses are mounted to the machine tool control 
transformer. Remove the fuses and measure the resistance across them. If the fuse 
measures open circuit (high resistance) it is blown and should be replaced.
Transformer XFM1 bad. Measure voltage at the input, and ensure that fuses FU3, FU5, 
and FU7 are good. If you have voltage at the input, but you do not see 115 VAC at the 
output (wires 100/102) the transformer is bad.


---

## PDF Page 176

Chapter 8
176
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
8.5.2  Controller Communications Subsystem
Problem: Controller communication can not be established
(Controller LED on operator panel will not turn on)
Possible Causes
Controller is on and PathPilot is loaded, but Reset button is flashing. Controller/machine 
communications are established when the flashing Reset button is clicked. Only after 
this button is clicked does the Controller LED on the operator panel illuminate.
DB-25 cable between controller and lathe is unplugged, or plugged into the wrong port 
on the controller. Verify that both ends of the cable are securely connected, and that 
the controller end is plugged into the PCI-slot DB-25 connector, not into the controller’s 
native parallel port. 
Machine is not powered on. The machine tool must be powered on before the controller 
communication can be established.
J4 ribbon cable between DB-25 bulkhead and machine control board is unplugged or 
loose. Check connections and re-seat cable.
8.5.3  Axis Drivers Subsystem
Problem: None of the axes move when commanded
Possible 
Causes
Software not commanding the move or controller problem. Jog the axis and observe the 
machine coordinate display. If the displayed position changes but the machine does not 
move there is a controller communication problem. Try restarting the controller.
Control signals not reaching the electronic driver modules. This could be a problem with 
the 25 pin D- connector cable from controller to machine, a problem with the ribbon 
cable from the DB-25 bulkhead connector to the machine control board (J4), or a problem 
with the ribbon cable from the machine control board to the axes drives. Check and re-
seat all cables
Drivers have faulted. Check the LEDs on the X and Z driver modules. If the LED is red, the 
driver has faulted; power cycle the lathe following the power off/on procedure detailed 
in chapter 3, Operation. This can happen if the controller is started after the lathe is 
powered on.
No power to drivers. Check that the LEDs on the axes drivers are illuminated. If there are 
no green LEDs on the drivers, check the power from the DC bus to the drivers. For more 
information on troubleshooting the DC bus, refer to in the Power Distribution Subsystem 
section earlier in this chapter.


---

## PDF Page 177

Chapter 8
177
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
Problem: One axis either will not move or will move in only one direction, but other axes 
operate properly
Possible 
Causes
Driver has no power or has faulted. Check the driver for the axis that will not move to 
make sure that the green LED is illuminated. If there is no LED, check power to the driver. 
If there is a red LED, power cycle the lathe following the power off/on procedure detailed 
in chapter 3, Operation – the driver has faulted.
Control signal to driver is missing. Check ribbon cable connection between driver and 
machine control board. Try swapping the ribbon cables between the two drivers. If the 
axis that failed to move previously now moves, there is a bad control signal.
Stepper motor wire has come loose. The motors on the 15L Slant-PRO are three-phase 
stepper motors. They will not function properly with one phase disconnected. Visually 
inspect the connections. If connections appear OK, then use a multimeter to Ohm out 
the wires (check U to V, V to W, U to W). Power off the lathe following the power off/on 
procedure detailed in chapter 3, Operation, and unplug the motor from the driver before 
taking these measurements. All measurements should read 0.5–1.0 Ohms.
Problem: Can not reference axes 
(Error message: Cannot reference axis while home switch is active)
Possible 
Causes
Broken switch or disconnected wire to home switches. The limit switches are normally 
closed, meaning that a broken wire and an actuated switch look identical to the control 
software. Because the X and Z switches are wired in series, if there is a broken wire both 
switches will show as being actuated on diagnostic LEDs on the Status screen. Visually 
inspect the wiring to the switches inside the switch box as well as at the connection to the 
machine control board. Use an Ohm meter to check the function of both switches, and to 
trace back a possible break in a wire.
Bad machine control board. Make a small jumper wire and insert it between the J5-5 and 
J5-6 terminals on the control board. If the LED on the Status screen doesn’t change state 
when this jumper is inserted, the control board or the DB-25 connection between the 
control board and the controller is defective.
NOTE: There is a temporary work around for a malfunctioning home switch circuit. On the Settings screen 
in the PathPilot interface, check the Disable Home Switches check box. The Ref X and Ref Z buttons now set 
the machine home position to the machine position at the time the button was pressed.


---

## PDF Page 178

Chapter 8
178
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
Problem: Steps are lost on axis travel
Possible 
Causes
Improper use of tool offset or work offset (G54-59). By far the most common cause 
of a perceived loss of position or lost steps is operator error. You can quickly check to 
see if the machine has truly lost its position by jogging to the end of travel (near where 
the home switch engages). The machine has soft limits that are set to 0.010” from the 
point at which the home switch triggers. If you are able to jog passed the trigger point of 
the home switch, or you can not jog to within 10 thousandths of the home switch, the 
machine has lost position. If you can jog right up to the soft limit, look at the DRO and 
record the position read out on the DRO. Then reference that axis again – the new read 
out should be 0.010” less than the value you wrote down. If these numbers match (within 
the repeatability of the home switch, +/- 0.001”), the machine has not lost position.
Motor pulley or ball screw pulley loose or cracked. Visually inspect drive pulleys for wear 
or slippage.
Workpiece not firmly held in chuck or 5C collet. If the apparent position loss occurs in Z 
only, it may actually be that the workpiece is being pushed back into the spindle by the 
cutting forces. This is especially possible when using 5C collets. A 5C lever action closer 
can come out of adjustment over time, or the stock being used can vary in diameter such 
that holding power is reduced.
Obstruction or excessive friction (gibs not adjusted properly or poor lubrication). Binding 
in the system is usually easy to diagnose because you can hear the motor stalling. 
Mechanical issues most often result in losing a large number of steps. Typical mechanical 
issues include an increase in friction due to lack of oil at the way surfaces or ball screw 
and/or improperly adjusted gibs. For more information, refer to chapter 7, Maintenance.
High load in the mechanical system. This can frequently be the cause of position loss on 
the Z axis during drilling cycles, which can require thousands of pounds of thrust for larger 
diameter drills. Keep your drill sizes to less than 1/2”, and then step up in successive larger 
drill sizes or use a boring bar to make larger diameter holes.


---

## PDF Page 179

Chapter 8
179
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
8.5.4  Spindle Drive Subsystem
Problem: Spindle drive will not power on
Possible 
Causes
First check to make sure that the drive has power after a spindle speed command is given. 
If the spindle drive is powered on but the spindle isn’t running, refer to Spindle VFD Fault 
Conditions section later in this chapter.
Chuck guard or enclosure door is not closed. The chuck guard or enclosure door must be 
fully closed before the spindle powers on. 
Zero RPM is commanded in the spindle RPM DRO. The spindle will not start if given a zero 
RPM command.
RPM override slider is at 0 percent. If the RPM overrides are set to zero percent, the 
spindle gets a zero speed command and will not start. Verify that the RPM slider is at an 
appropriate level.
The machine is in constant surface speed mode, but the surface speed command and 
current X position of the lathe is such that the commanded RPM is less than the minimum.
Chuck guard or enclosure door switches are not functioning properly. There are two 
switches on the machine guard: one conducts 5VDC and communicates the state of the 
guarding to PathPilot; the other conducts 115 VAC and allows the contactor that powers 
the VFD to energize. Both switches must function properly for the spindle to turn on.
•	
A failure of the 5VDC switch should be obvious, as PathPilot tells you that the door 
must be closed before you can start the spindle. If you get these error messages even 
though the door is closed, examine the switch for loose wires, make sure the J10 
connector on the control board is connected, and Ohm out the switch.
•	
A failure of the 115 VAC switch is less obvious. PathPilot thinks the door is closed 
and tries to start the spindle, but the spindle drive will not receive power. If you can 
press the spindle FWD button in PathPilot, and you do not receive an error message, 
but the spindle does not turn on, you may have a fault in the 115 VAC switch circuit. 
Examine the switch for broken or disconnected wires, as well as the J7-3 and J7-4 
connections on the machine control board. If nothing is found, power off the lathe 
following the power off/on procedure detailed in chapter 3, Operation, and Ohm out 
the switch.


---

## PDF Page 180

Chapter 8
180
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
Problem: Spindle drive powers on, but spindle will not turn on
Possible 
Causes
Speed signal to VFD is not present – drive readout displays spd 00. Check wires J1-1 and 
J1-2 and ensure they are properly seated at both control board and at VFD inputs.
Enable signal is missing at drive – drive readout displays lh. Check wires J1-9 and J1-10 at 
both the control board and at the VFD inputs.
VFD is tripped – the display shows if the VFD has tripped, along with a trip code. Record 
the information from the display should the trip be happening frequently. VFD trips can 
be cleared by powering off the drive, which can be done by opening the chuck guard 
or enclosure door, or by power cycling the lathe following the power off/on procedure 
detailed in chapter 3, Operation.
Run and Direction Commands to Drive
Command 
From Card
Monitoring Points One Probe on 
each
Voltage Measured
Common Wire 
Number
Wire Number
Voltage when Control 
Board Command is on
Voltage 
when 
Control 
Board Command is not on
Run
J1-2
J1-3
20-28 VDC
0 VDC
Reverse
J1-2
J1-6
0 VDC
20-28 VDC
Spindle VFD Fault Conditions
Trip Code
Condition
Likely Cause
UU
DC Bus Under voltage
This happens when VFD is powered off.
OU
DC Bus Over voltage
Braking resistor failed open or wiring connection open 
between VFD and resistor. Resistance to measure 75 Ohms.
OI.AC
VFD output instantaneous 
over current
Phase to phase or phase to ground short on output of VFD to 
motor.
OI.br
Braking resistor 
instantaneous over current
Full or partial braking resistor, or short in wiring between VFD 
and resistor. Resistance should measure 75 Ohms.
It.br
I2t (power) on braking 
resistor
Frequent and severe deceleration cycles trigger excessive 
braking resistor energy, or AC supply voltage too high.
It.AC
I2t (power) on VFD output 
current (used to protect 
motor)
Spindle motor is over worked. Consider cooling down motor 
by running spindle with no load at half speed for 10 minutes.
(continued on next page...)


---

## PDF Page 181

Chapter 8
181
UM10225_15L_Slant-PRO_Manual_0626A
Troubleshooting
(...continued)
Spindle VFD Fault Conditions
O.ht1
VFD thermal trip – VFD 
stops to cool down power 
electronics and prevent 
failure.
Spindle motor is over worked. Stop running spindle but leave 
VFD power on and allow power electronics to cool down.
O.ht2
Heat sink temperature 
is too high because VFD 
is working too hard and 
needs to stop to cool power 
electronics down and 
prevent failure. Cabinet 
may also be too hot.
Spindle motor is over worked or room temperature is too 
high. Stop running spindle but leave VFD power on; let power 
electronics cool down. Check to see if fan on VFD is running 
and check filters on cabinet reduce room temperature.
Hf.29
Cooling fan not cooling
Failed drive.


---

## PDF Page 182

Chapter 9
182
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
9.  Diagrams and Parts Lists
9.1  Base Assembly (exploded view)


---

## PDF Page 183

Chapter 9
183
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
Base Assembly Parts List
ID
PN
Description
ID
PN
Description
1
34327
End Panel
28
34348
Wheel
2
34328
Screw, M5 x 6
29
34349
Washer, Flat M6
3
33226
Drive Belt1
30
34350
Washer, Lock M6
4
34330
Ring
31
34351
Screw, M6 x 10
5
34331
Set Screw M8 x 14, point
32
34352
Coolant Tank
6a
33208
Drive Pulley 80 mm
33
34353
Door, Front
6b
33229
Drive Pulley 110 mm
34
34354
Door Latch
7
33230
Spindle Motor
35
34355
Door Hinge
8
34332
Bolt, M8 x 30
36
34356
Base
9
34333
Washer Lock, M8
37
34357
Side Door
10
34334
Washer Flat, M8
38
34358
Screw, M6 x 20
11
34335
Nut, M16
39
34359
Nut, M6
12
34336
Motor Mount Stud
40
34360
Rear Cover
13
34337
Motor Mount Plate
41
34361
Pump Mount Plate
14
34338
Bolt, M10 x 40
42
32746
Coolant Pump
15
34339
Washer, M10
43
34362
Coolant Hose
16
34340
Motor Adjustment Plate
44
34363
Cover Plate
17
34341
Swarf Tray
45
34364
Cover Plate
18
34342
Foot Spacer
46
34365
Outlet Cover Plate
19
34343
Foot Pad, 15L Lathe Stand, 
M14 × 2 - 80 mm Threaded 
Stud
47
34366
Screw, M3 x 8
23
34344
Screw, M4 x 6
48
34367
Controller Tray
24
34345
Cover Plate
49
34368
Screw, M6 x 14
26
34346
Cover Plate
50
34369
Screw, M5 x 10
27
34347
Screw, M5 x 8
1Gates # 2/11M1950JB


---

## PDF Page 184

Chapter 9
184
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
9.2  Lathe Bed Z-axis Assembly (exploded view)


---

## PDF Page 185

Chapter 9
185
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
Lathe Bed Z-axis Parts List
ID
PN
Description
ID
PN
Description
1
34155
Bolt, M16 x 35
26
34180
Spacer, Z Pulley
2
34156
Washer, Lock M16
27
34181
Screw, M5 x 12
3
34157
Lifting Hanger RH
28
34182
Pulley, Z Ball Screw
4
34158
Screw, M8 x 8
29
34183
Pulley Mount Flange Z Screw
5
34159
Z Limit Switch Stop
30
34184
Belt, Z-axis Drive
6
34160
Washer, Flat M12
31
34185
Belt Cover, Z-axis
7
34161
Bolt, M12 x 55
32
34186
Screw, M8 x 30
8
34162
Washer, Lock M12
33
34187
Washer, Lock M8
9
34163
Pin, M10 x 45
34
34188
Washer, Flat M8
10
34164
Bed Casting
35
34189
Pulley, Z Motor
11
34165
Lifting Hanger LH
36
34190
Set Screw, M6 x 10
12
34166
Screw, M5 x 10
37
34191
Z Motor Mount
13
34167
Ballscrew Cover, Z-axis
38
33224
Ball Screw, Z-axis Lathe
14
34168
Screw, M5 x 20
39
34192
Motor Cover
15
34169
Washer, Lock M5
40
34193
Mount Pad, Z Carrier
16
34170
Bumper, Z-axis RH
41
34194
Carrier, Z Ballscrew
17
34171
Washer, Flat M5
42
33066
Z-axis Stepper Motor
18
34172
Seal, Z-axis Ballscrew
43
34195
Screw, M8 x 50
19
34173
Pin, M6 x 30
44
34196
Pin, M8 x 65
20
34174
Spacer, Z Screw bearing
45
34197
Spanner Nut, M15 x 1
21
34175
Screw, M6 x 25
46
34198
Bearing Cap
22
34176
Bearing Mount Block RH
47
34199
Felt Washer
23
34177
Bearing, Z Ballscrew Mount RH1
48
34200
Bearing, Z Ballscrew Mount LH2
24
34178
Bearing Cap
49
34201
Bearing Mount Block LH
25
34179
Spanner Nut, M17 x 1
50
34202
Bumper, Z-axis LH
1ABEC Identification: 7003B/DB/P5 (1 unit includes a bearing pair)
2ABEC Identification: 6003-22


---

## PDF Page 186

Chapter 9
186
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
9.3  Lathe Cross Slide Assembly (exploded view)


---

## PDF Page 187

Chapter 9
187
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
Lathe Cross Slide Parts List
ID
PN
Description
ID
PN
Description
1
34203
Screw, M4 x 12
28
34179
Spanner Nut, M17 x 1
2
34204
Cover Tray, X Lower
29
33228
Belt, X-axis
3
34205
Pin, M6 x 30
30
34232
Pulley, X-axis Ballscrew
4
34197
Spanner Nut, M15
31
34233
Locking Sleeve
5
34207
Screw, M6 x 25
32
34234
Pulley Mount Flange X Screw
6
34208
Mount Plate, X Ballscrew Lower
33
34235
Belt Cover, X-axis
7
34209
Spacer
34
34236
Screw, M5 x 8
8
34200
Bearing, X-axis Idler1
35
34237
Set Screw, M6 x 10
9
34211
Bumper, X-axis Lower
36
34238
Pulley, X-axis motor
10
34212
Gib Screw, X-axis
40
34242
Motor Mount Plate, X-axis
11
34213
Gib, X-axis
41
34243
Cross Slide
12
34214
Screw, M5 x 12
42
35452
Stepper Motor, X-axis Lathe
13
34215
Plate
43
34245
Carrier Block, X Ballnut
14
34216
Gib, Z-axis
44
34246
Washer, Flat M5
15
34217
Way Wiper
45
34247
Washer, Lock M5
16
34218
Gib Screw, Z-axis
46
34248
Screw, M5 x 20
17
34219
Screw, M5 x 12
47
32833
Coolant Nozzle (Blue Orange)
18
34220
Carriage Saddle
48
34244
Screw, M5 x 12
19
34221
Set Screw, M5 x 5 Flat Tip
49
34249
Screw, M6 x 20
20
34222
Bumper, X-axis Upper
50
31105
Coolant Coupling Mount
21
34223
Mount, X-axis
51
32832
Coolant Coupling
22
34200
Bearing, X-axis Upper2
52
34239
Limit Switch Cover
23
34225
Spacer, Bearing
53
34240
Coolant Mount Bracket
24
34226
Washer, Flat M8
54
34241
Limit Switch Ramp, X-axis
25
34227
Washer, Lock M8
55
34231
Motor Cover
26
34228
Screw, M8 x 25
56
33223
Ballscrew, X-axis
27
34229
Bearing Cap
1ABEC Identification: 6003-2Z
2ABEC Identification: 7003B/DB/P5 (1 unit includes a bearing pair)


---

## PDF Page 188

Chapter 9
188
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
9.4  Lathe Headstock Assembly (exploded view)


---

## PDF Page 189

Chapter 9
189
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
Lathe Headstock Parts List
ID
PN
Description
ID
PN
Description
1
—
5C Collet
30
34278
Closer Mount Bracket
2
33325
5C Insert
31
34279
Screw, M6 x 40
3
34251
5C Insert Pin
32
34280
Spanner Nut
4
34252
Spindle, Lathe
–
34306
Spanner Nut Kit4
5
34253
Screw, M8 x 20
33
34281
Set Screw, M8 x 12
6
34254
Spring, Cam Lock
34
34282
Brass Pad
7
34255
Cam Lock Pin
35
34283
Set Screw, M5 x 8 Cone Tip
8
34256
Cam Lock
36
34284
Spindle Pulley
–
34250
D1 Rebuild Kit1
37
34285
Spindle Lock Nut
9
34257
Key, M8 x 25
38
34286
Screw, M6 x 12
10
34258
O-ring Seal, Spindle Nose
39
34287
Retaining Clip
11
34259
Bearing, Spindle Nose2
40
34288
Encoder Pulley
12
34260
Spacer Sleeve, Spindle 
Bearing
41
34289
Encoder Ring Pulley
13
34261
Spacer Ring, Spindle
42
33227
Belt, Encoder
14
34262
Bearing, Spindle Tail3
43
34291
Spacer, Encoder Bearing
15
34263
Seal Sleeve
44
34292
Key, M5 x 10
16
34264
Screw, M8 x 35
45
34293
Encoder Shaft
17
34265
Nose Cap, Headstock
46
34294
Retaining Ring
18
34266
Logo Casting
47
34295
Bearing, Encoder
19
34267
Screw, M5 x 20
48
34296
Mount Spacer, Encoder
20
34268
Screw, M12 x 40
49
34297
Mount, Encoder
21
34269
Washer, Lock M12
50
34298
Washer, Flat M6
22
34270
Washer, Flat M12
51
34299
Washer, Lock M6
23
34271
Pin, M10 x 30
52
34300
Screw, M6 x 65
24
34272
Head Stock Casting
53
34301
Screw, M4 x 20
25
34273
Do not use
54
32560
Encoder
26
34274
Tail Cap, Head Stock
55
34303
Belt Guard Cover
27
34275
Screw, M5 x 8
56
34304
Guard Hole Cover
28
34276
Belt Cover Panel
57
34305
Guard Hole Cover
29
34277
Cover Bracket
1D1 Cam Lock Rebuild Kit (includes items #5, 6, 7, 8 = qty 3 each)
2ABEC Identification: 7013AC/DB (1 unit includes a bearing pair)
3ABEC Identification: 7012AC/DB (1 unit includes a bearing pair)
4Spanner Nut Kit (includes items #32, 33, 34)


---

## PDF Page 190

Chapter 9
190
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
9.5  Lathe Cabinet Hardware (exploded view)


---

## PDF Page 191

Chapter 9
191
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
Lathe Cabinet Hardware Parts List
ID
PN
Description
1
34135
Junction Box
2
34136
Top Hinge Mount
3
34137
Upper Hinge Collar
4
34138
Lower Hinge Collar
5
34139
Screw, M5 x 12
6
34140
Cabinet
7
34141
Hinge Body (welded)
8
34142
Hinge Pin (welded)
9
34143
Bottom Hinge Mount
10
34144
Screw, M8 x 16
11
34145
Washer, Lock M8
12
34146
Washer, Flat M8
13
34147
Screw, M6 x 16
14
34148
Washer, Lock M6
15
34149
Washer, Flat M6
16
34150
Wheel
17
34151
Wheel Point
18
34152
Nut, M16
19
34153
Cabinet Door
20
30467
Door Latch


---

## PDF Page 192

Chapter 9
192
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
9.6  Electrical Cabinet
RIGHT SIDE
(FRONT)
INSIDE BOX
Main Power 
Disconnect
32
42
GREEN
RED
103
102
104
RED
GREEN
VFD 
Drive
32292
STEPPER
DRIVER
32000
STEPPER
DRIVER
32000
X AXIS 
Z AXIS 
34
BRAKING RESISTOR
31049
LATHE MAIN 
CONTROL BOARD
32574
CAP
DC BUS
BOARD
32005
XFM2
(30459)
XFM1
31097
filter
C2
C1
30465
30465
fuse
fuse
fuse
33
9
FAN
21
25 (optional)
24 (optional)
5
13, 8
12, 8
1
Fuse FU11
Coolant
8amp
Fuse FU12
Collet closer
1 amp
16
7B
7
7A
6
15
22
31
5A
5B
5C
9
10
20
17
14
2,3
38
40
4
20B
36
35,23
37
30
20A
39
Closer/Aux.Controller
Coolant Monitor
Power Input
41
LEFT SIDE
(BACK)
Lathe Cabinet Layout
15L Slant-PRO
May, 2015


---

## PDF Page 193

Chapter 9
193
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
Electrical Cabinet Parts List
ID
PN
Description
ID
PN
Description
ID
PN
Description
1
32652
DC Power Supply 24 Volt
17
31039
Accessory/Probe Port
41
32858
J6 Ribbon Cable (axis drivers)
2
31657
Fuse FU1, FU21 20amp
20
31040
LED Assembly
42
30454
Disconnect Switch
2A
30510
Double Fuse Block
20A
31043
LED Mounting Clip
—
30627
Flex Conduit 16 mm OD
3
30456
Fuse FU62 6amp
20B
31044
LED Retaining Ring
—
30628
Connector for 16 mm Flex
3A
30511
Single Fuse Block
21
32292
VFD Motor Driver9
—
30722
Flex Conduit 12 mm OD
4
32861
DIN/LED Circuit Board
22
32005
DC Bus Board
—
30723
Connector for 12 mm Flex
5
31097
Transformer XFM13
22A
31655
DC Bus Fuse F1,310 8amp
—
33931
Flex Conduit 18 mm OD
5A
31119
Fuse FU34 .75amp
22B
32404
DC Bus Fuse F611 15amp
—
33932
Connector for 18 mm Flex
5B
31120
Fuse FU55 3amp
23
33063
Noise Suppressor
—
33371
Tormach Logo – cast
5C
31120
Fuse FU75 3amp
24
32785
Turret Control Board (optional)
5D
31213
Fuse Holder for FU7
25
32870
Turret Capacitor (optional)
6
30459
Transformer XFM26
30
33370
Operator Console Assembly
—
34071
Label, Machine Safety
7
32574
Lathe Control Board
31
32000
Stepper Driver
—
30224
Label, Dual Power Supply
7A
31655
Control Board Fuse FU117 8amp
32
30626
Fan, 115 VAC
—
30225
Label, Retain Voltage Safety
7B
33369
Control Board Fuse FU128 1amp
33A
34127
Terminal Block
—
30461
Door Switch (2 per lathe)
8
33062
Noise Suppressor
33B
34128
Terminal Block Jumper
—
30461
X and Z Lathe Limit Switch
9
30462
E-stop PB0, PB1
34
31049
Braking Resistor
—
32560
Spindle Encoder
10
30463
Push Button PB2
35
30177
AC Power Outlet
12
30466
Relay Contactor C1
36
32869
I/O Mount Plate
13
30466
Relay Contactor C2
37
30258
AC Power Inlet
14
30467
Cabinet Latch and Key
38
32878
J2 Cable (turret – optional)
15
30468
Capacitor
39
32859
J3 Cable (console)
16
32350
Filter
40
30684
J4 Cable (controller)
1Metric size is 10 x 38 mm, 20A. Use Bussmann KTK-20, Littlefuse KLK-20, or Ferraz ATM-20
2Metric size is 10 x 38 mm, 6A. Use Bussmann KTK-6, Littlefuse KLK-6, or Ferraz ATM-6
3Control Transformer is 230/115-100VA
4Metric size is 5 x 20 mm .75A. Use Bussmann GMD-750mA, Littlefuse 239.75P
5Metric size is 5 x 20 mm, 3A. Use Bussmann GMD-3A, Littlefuse 239003.P, or Ferraz GSC -3A
6Axis Power Transformer is 230/48-500VA
7Metric Size is 5 x 20 mm, 8A. Use Bussmann GMD-8A, Littlefuse 239008.P, or Ferraz GSC -8A
8Metric size is 5 x 20 mm, 1A. Use Bussmann GMD-1A, Littlefuse 239001.P, or Ferraz GSC-1A
9Pre-programmed with current version of PathPilot®
10Fuse for DC Bus Board, F1, 3. Use Bussmann GMD-8A, Littlefuse 239008.P, or Ferraz GSC-8A
11Fuse for DC Bus Board, F6. Use Bussmann GMD-15A, Littlefuse 239015.P, or Ferraz GSC-15A
12This 10 mm used for the X limit switch, 12 mm used for the Y limit switch, all axis motors and spindle motor use 16 m


---

## PDF Page 194

Chapter 9
194
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
9.7  Connections
2
elo
s
n
o
C
1
6
J
16
J5
15
1
26
2
1
16
25
15
2
61
58
J1-1
J1-9
J1-7
J1-6
J1-8
J1-5
J1-4
J1-3
J1-2
J1-1
J6
J4
J3
2
1
16
J5
15
1
26
2
1
25
2
59
60
1
-
5
J
2
-
5
J
3
-
5
J
4
-
5
J
5
-
5
J
6
-
5
J
J1-10
J1-9
J1-7
J1-6
J1-8
J1-5
J1-4
J1-3
J1-2
J1-1
PN 32574
TORMACH LATHE
CONTROL BOARD
4
J
1
16
15
2
1
2
J2
J9
J10
J7
J5
J9-1 (5V)
J9-2 (A+)
J9-4 (B+)
J9-5 (B-)
J9-3 (A-)
J9-6 (Z+)
J9-7 (Z-)
J9-8 (GND)
J9-9 (GND)
1
-
7
J
2
-
7
J
3
-
7
J
4
-
7
J
1
-
0
1
J
2
-
0
1
J
J1
STEPPER MOTORS
1
1
2
2
3
3
4
4
5
5
6
6
7
7
8
8
off
off
off
off
n
o
n
o
on
SWITCH SETTINGS FOR DRIVERS
Connector
P1
P2
P3
P4
P5
Function
PWR GND
VDC
U
V
W
n
o
n
o
n
o
n
o
on
n
o
n
o
ffo
ffo
X and Z Axis are Three Phase
Three Phase Schematic
X AXIS DRIVER
Z AXIS DRIVER
VFD WIRING DETAIL
35715
WIRE COLORS/GAUGE
WIRE 
NUMBER
COLOR
SIZE 
(AWG)
100
WHITE
14/16
101-199
RED
16
200
WHITE
16
201
GREEN/YELLOW
16
202-299*
BLACK
16
300-399
MULTI COLOR
16
400-499
BLACK
J1-1 - J1-10
BLUE
18
L00-L99
BROWN/BLUE
14
14
*See page 1 for detail, 2 wires connecting to the main control board,
 
202 and 208 are black, 18 ga.
32005 DC BUS
Lables and wire numbers
X+  302
X-  303
Z+  304
Z-   305
J2-48VAC  L15
J1-48VAC  L25
CAP- 300
CAP+  301
8 A
8 A
8 A
8 A
2 A
8 A
15 A
8 A
F1 = X AXIS
F3 = Z AXIS
F5 DC BRAKE
F6 = MAIN
(note: There are a number of
fuses not used as this board
is used on other Tormach
equipment.)
BRAKE RLY+ 328
BRK-  327
BRAKE RLY-  329
BRK+  326
 
Lathe Control Connections
15L Slant-PRO
March 2018
STEPPER MOTORS TO STEPPER DRIVER
MOTOR 
LEAD 
COLOR
WIRE 
NUMBER
DRIVER 
TERMINAL
DRIVER 
NAME
RED
308
P3
X DRIVE
X DRIVE
X DRIVE
Z DRIVE
Z DRIVE
Z DRIVE
P4
P5
P6
P7
P8
309
310
311
312
313
GRN
YEL
RED
GRN
YEL
1    2   4    5   7   9  10  11 12  13 14
41 42
L1 L2 L3   -    +  BR  U   V  W
GND
L26
L16
J1-1
J1-2
J1-3
J1-4
J1-6
401
400
402
J1-10
J1-5
J1-7
J1-8
J1-9
403
404


---

## PDF Page 195

Chapter 9
195
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
9.8  Operator Panel
Estop Button PB0
 
102
101
31039 Accessory/Probe 
Port Assembly
30463 Push Button PB2
30462 Estop Button PB1
31040 LED Assembly
(31043 LED Mounting Clip
31044 LED Retaining Ring)
GREEN
RED
103
102
104
RED
GREEN
33370 Operator Panel assy
(includes buttons, LED’s and
 DIN connector)
Lathe User Control Panel Detail
15L Slant-PRO
May, 2015
31040 LED Assembly
(31043 LED Mounting Clip
31044 LED Retaining Ring)


---

## PDF Page 196

Chapter 9
196
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
9.9  Ribbon Cable and Miscellaneous
IDC-26     30168
CABLE-26   30170
DB25 MALE  30166
OUTLET COOLANT (PN 30177)
OUTLET COMPUTER (PN 30177)
4 empty
I/O MOUNT PLATE - 32869
OUTLET COOLANT (PN 30177)
X-Axis
32858
J6 - STEPPER DRIVERS
30684
J4 - DB25 MALE
32859
J3 - CONNECTION BOARD
PIN 1 is next to the triangle
TRIANGLE
Example IDC-26, IDC-16, IDC-10
OUTLET COMPUTER (PN 30177)
DB25 MALE (PN 30166)
4-40 STANDOFF (PN 30211)
4-40 NUT (PN 30212)
POWER INLET (PN 30258)
Z-Axis
16 Pin IDC Connector
PIN 1
COLLET CLOSER (PN 30177)
Black Wire
202, 204, 208
30177 AC Outlet
Back View
White Wire 200
Green/Yellow Wire
Ground 201
Black Wire 206
30258 AC Inlet
Back View
White Wire 200
GRN/YEL Wire
Ground 201
32878
J2 - CONNECTION BOARD
Lathe Ribbon Cable & Misc
15L Slant-PRO
May, 2015


---

## PDF Page 197

Chapter 9
197
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
Tools and Related Items
PN
Description
34388
Lathe Controller
30409
Manual Oiler
31374
Automatic Oiler
31386
Machine Way Oil
30485
Spanner Wrench 25-28 mm DIN 1810 form A standard. Used for setting preload on ballscrew 
mount bearings – two wrenches are needed.
34397
Tormach 15L Slant-PRO Lathe Operator Manual. Replace old manual with the latest version, spiral 
bound. Manual PDF can also be downloaded from www.tormach.com
30572
Touch-up Paint – dark gray 2.5 oz matching the lower section of the stand. Original paint is 
oil-based; touch-up is latex.
30571
Touch-up Paint – light gray 2.5 oz matching the PCNC 1100 and the upper section of the stand. 
Original paint is oil-based; touch-up is latex. Cannot ship paint during colder weather.
NOTE: Valspar Tractor and Implement paint #5339-13 Ford Gray is also a close match.
30624
DIN Connector – 5 pin. This is a plug that will fit in the accessory port.
31366
Coolant Refractometer


---

## PDF Page 198

Chapter 9
198
UM10225_15L_Slant-PRO_Manual_0626A
Diagrams and Parts Lists
9.10  Lubrication System
Pump
(31302 or 31374)
X slideway 
left side
X ballnut
X dovetail - 
left
Z gib
X gib
X slideway 
right side
Z slideway 
- lower
Lower manifold (34708)
Upper manifold (34707)
P1
P2
P3
P4
P5
P6
P7
P8
P9
P10
P11
P12
Z ballnut
Z dovetail - 
upper
Z slideway 
- upper
Compression 
Fittings
Elbow M6
(31311)
Elbow M8
(35461)
Nut
(31310)
Ferrule
(31309)
Manifold 
oriﬁce
(31370)
Gib oriﬁce
(31408)
Nut and 
ferrule bundle 
(31409)
4 mm nylon 
tubing
(31304)
Protective 
metal sheath
(31306)


---

## PDF Page 199

1    2   4    5   7   9  10  11 12  13 14
41 42
L1 L2 L3   -    +  BR  U   V  W
GND
START
  E-STO P
(REMOTE)
C1
J6
OUTLET
X DRIVE
Z DRIVE
Tormach Lathe Control Board
PN 32574
J6-1 thru J6-6
XMF2
230 VAC LINE
MACHINE FRAME
BONDED TO EARTH GROUND
LABEL:
 
COOLANT POWER
230/48 PRIMARY/SECONDARY
DC BUS POWER
PB0
PB2
FU2 - 20 AMP
FU1 - 20 AMP
J6-7 thru J6-12
J1
J10
OUTLET
LABEL: MONITOR
POWER INLET
All control wires 18GA Wire (Blue)
14 to J1-1
1 to J1-2
12 to J1-3
41 to J1-4
7 to J1-5
13 to J1-6
42 to J1-7
10 to J1-8
9 to J1-9
11 to J1-10
OUTLET
LABEL: COMPUTER
J4
Ribbon cable connects J4 to DB25
connector on cabinet.  External
connection is made to computer
C1
C1
C2
C2
C2
FILTER
CAP - 15,000 u
F
DC BUS BOARD
48VAC
+CAP
-CAP
X+
X-
Y+
Y-
Z+
Z-
A+
A-
C2
L11
L21
L23
L13
103
104
106
107
L26
L16
L14
L24
L25
L15
200
201
204
300
301
305
304
303
302
311
312
313
310
309
308
J7-1
J7-2
J7-3
J7-4
J10-1
J10-2
J1-1
J1-2
J1-3
J1-4
J1-5
J1.6
J1-7
J1-8
J1-9
J1-10
Enclosure Door
Switch, Chuck Guard
F1, F3 - 8 AMP
F6 - 15 AMP
I/O MOUNT PLATE
32005
DB25  MALE
FU11- 8 AMP
coolant
DISCONNECT
FU6 - 6 AMP
202
202
202
202
PN 53488
L1
L2
L01
(Brown Wire)
L02
(Blue Wire)
207
206
1
2
3
4
5
6
FAN
P1
P1
PN 53488
P2
P2
P3
P3
P4
P4
P5
P5
Brake+
Brake-
Brake RLY+
Brake RLY+
100
100
J3
LED1
LED2
COMPUTER
MACHINE
VFD
35715
LED ASSY
P/N 31040
J1-1
J1-2
J1-3
J1-4
J1-6
C1
30465
ALL THICK LINES = 
14GA WIRE (BROWN/BLUE)
M1
401
400
402
DYNAMIC BRAKE
RESISTOR
38354
403
404
ALL THICK LINES = 14GA WIRE (BLACK)
J4 RIBBON CABLE
30684
J3 RIBBON CABLE
32859
J6 RIBBON 
CABLE
                          
NOTE: RESISTOR 
COMES PRE WIRED
J1-10
Motor
35452
Motor
33066
DB+
DB- ATC+ ATC-
LS1
J10-1
J10-  2
24 DC power 
supply
PN 32652
J5-1
J5-2
J5-3
J5-4
J5-5
J5-6
XFM1
CONTROL POWER TRANSFORMER
230/120  PRIMARY/SECONDARY
102
100
FU7 - 
2-3 AMP
NOTE: FU3, FU5 AND FU7 
MOUNTED TO TRANSFORMER
N
L
V-
24VDC V+
LABEL:
 
COLLET CLOSER
FU3 -0.75 AMP
J11
J12
FU12- 1 AMP
closer
104
104
107
J1-5
J1-7
J1-8
J1-9
106
104
OUTLET
208
32861
J2
J13 - ATC sensors
J14  - ATC Power
CAP - 15,000 uF
32870
J2 RIBBON 
CABLE 32878
OPTIONAL LATHE ATC BOARD
J14-5
J14-4
J14-3 - Turret W
J14-2 - Turret V
J14-1 - Turret U
L14
L11
L21
L24
L11
202
208
L51
L52
E-STOP
PB1
101
101
103
J9-1 (5V)
J9-2 (A+)
J9-4 (B+)
J9-5 (B-)
J9-3 (A-)
J9-6 (Z+)
J9-7 (Z-)
J9-8 (GND)
J9-9 (GND)
Encoder
32560
J9-1 (5V)
J9-2 (A+)
J9-4 (B+)
J9-5 (B-)
J9-3 (A-)
J9-6 (Z+)
J9-7 (Z-)
J9-8 (GND)
J9-9 (GND)
204
Suppressor
33063
Suppressor
33062
Suppressor
33062
J5-1
J5-2
18 GA BLACK
Operator installed wiring 
with Turret Package
206
LS2
FU5 - 2-3 AMP
Suppressor
33063
LS3
LS4
X LIMIT
Z LIMIT
J5-5
J5-6
J5-5A
326
327
C1
328
329
Brake Wires
DIN 
CONNECTOR
ASSEMBLY
31039
ELECTRICAL SCHEMATIC
15L Slant-PRO Lathe
March 2018
